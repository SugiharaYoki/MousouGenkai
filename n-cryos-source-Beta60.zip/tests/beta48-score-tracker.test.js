import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import * as rules from '../src/game/rules.js'

test('查分器数值规则覆盖里程碑、失效区间、增长加成与修复速度', () => {
  assert.equal(rules.scoreTrackerRules.playerThreshold, 2500)
  assert.equal(rules.scoreTrackerGrowthMultiplier({ hasScoreTracker: true, isBroken: false }), 1.01)
  assert.equal(rules.scoreTrackerGrowthMultiplier({ hasScoreTracker: true, isBroken: true }), 1)
  assert.equal(rules.scoreTrackerGrowthMultiplier({ hasScoreTracker: false, isBroken: false }), 1)
  assert.equal(rules.rollScoreTrackerFailureDelay(() => 0), 7)
  assert.equal(rules.rollScoreTrackerFailureDelay(() => 0.999999), 15)
  assert.equal(rules.scoreTrackerRepairGain(-10), 5)
  assert.equal(rules.scoreTrackerRepairGain(0), 5)
  assert.equal(rules.scoreTrackerRepairGain(10), 7.5)
  assert.equal(rules.scoreTrackerRepairGain(20), 10)
  assert.equal(rules.scoreTrackerRepairGain(100), 10)
})

test('游戏引擎保存隐藏状态并接入更新、每日事件、写程序和玩家增长', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')

  assert.match(legacy, /hasScoreTracker:false,scoreTrackerBroken:false,scoreTrackerRepairProgress:100,scoreTrackerFailureDays:\[\]/)
  assert.match(legacy, /社区开始制作《\$\{gameName\(\)\}》的查分器。/)
  assert.match(legacy, /社区的《\$\{gameName\(\)\}》查分器似乎失效了。你并不清楚自己该不该为此做点什么。/)
  assert.match(legacy, /社区的《\$\{gameName\(\)\}》查分器又能运作了。/)
  assert.match(legacy, /recalcPublic\(\);\s*scheduleScoreTrackerFailure\(p\);/)
  assert.match(legacy, /advanceProgramDevelopment\(\);\s*reduceScoreTrackerFailureChanceDuringBeta\(\);\s*advanceScoreTrackerRepair\(\);/)
  assert.match(legacy, /processMilestoneDailyRewards\(\);scoreTrackerDaily\(\);/)
  assert.match(legacy, /scoreTrackerGrowthMultiplier\(\{hasScoreTracker:state\.hasScoreTracker,isBroken:state\.scoreTrackerBroken\}\)/)
  assert.match(legacy, /version:"Beta60"/)
})

test('曲师日记链接位于经济卡片外部并采用新文案', async () => {
  const economy = await readFile(new URL('../src/components/EconomyPanel.vue', import.meta.url), 'utf8')
  const mobile = await readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8')

  assert.match(economy, /<\/section>\s*<p class="sub friend-project-link mobile-economy-link">/)
  assert.match(economy, /也试试<a [^>]+><strong>《曲师日记》模拟器<\/strong><\/a>！/)
  assert.doesNotMatch(economy, /这是我一个熟人做的模拟器|模拟器<\/a>吧：/)
  assert.match(mobile, /data-mobile-page='status'\] \.mobile-economy-link/)
})

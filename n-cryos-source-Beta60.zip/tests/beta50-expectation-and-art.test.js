import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import * as rules from '../src/game/rules.js'

test('期待值日历锁、月度上限、动态上限与300软上限采用统一规则', () => {
  assert.equal(rules.expectationRules.initialValue, 30)
  assert.equal(rules.expectationRules.fixedDays, 90)
  assert.equal(rules.expectationRules.absoluteMaximum, 300)
  assert.equal(rules.expectationRules.weeklyDecayMultiplier, 0.95)
  assert.equal(rules.expectationMonthCap({
    monthIndex: 3,
    snapshots: [{ month: 0, value: 30 }, { month: 2, value: 30 }],
  }), 42)
  assert.equal(rules.expectationMonthCap({
    monthIndex: 4,
    snapshots: [{ month: 1, value: 30 }, { month: 3, value: 42 }],
  }), 48)
  assert.equal(rules.dynamicExpectationGainLimit(0), 3)
  assert.equal(rules.dynamicExpectationGainLimit(3), 6)
  assert.equal(rules.dynamicExpectationGainLimit(7), 9)
  assert.ok(rules.expectationSoftGain(150, 100) < 100)
  assert.ok(rules.expectationSoftGain(290, 100) < rules.expectationSoftGain(150, 100))
  assert.equal(rules.expectationSoftGain(300, 100), 0)
})

test('歌曲数量满足度在3首为一倍、10首约为两倍且边际递减', () => {
  assert.equal(rules.packageSongCountSatisfactionMultiplier(3), 1)
  assert.ok(Math.abs(rules.packageSongCountSatisfactionMultiplier(10) - 2) < 1e-12)
  const from3To4 = rules.packageSongCountSatisfactionMultiplier(4) - rules.packageSongCountSatisfactionMultiplier(3)
  const from9To10 = rules.packageSongCountSatisfactionMultiplier(10) - rules.packageSongCountSatisfactionMultiplier(9)
  assert.ok(from9To10 < from3To4)
  assert.equal(rules.packageExpectationSatisfaction({ averagePlayableQuality: 80, songCount: 3 }), 80)
})

test('更新期待值增长按差值、年份、设计类型和上下限计算', () => {
  assert.equal(rules.releaseExpectationYearMultiplier(0), 0.4)
  assert.equal(rules.releaseExpectationYearMultiplier(1), 0.5)
  assert.equal(rules.releaseExpectationYearMultiplier(2), 0.6)
  assert.equal(rules.releaseExpectationYearMultiplier(3), 0.7)
  assert.equal(rules.releaseExpectationYearMultiplier(4), 0.8)
  assert.equal(rules.releaseExpectationYearMultiplier(20), 0.8)
  assert.equal(rules.releaseExpectationBaseGrowth({ satisfaction: 110, expectation: 100, yearIndex: 0 }), 1)
  assert.equal(rules.releaseExpectationBaseGrowth({ satisfaction: 120, expectation: 100, yearIndex: 0 }), 1.5)
  assert.equal(rules.releaseExpectationBaseGrowth({ satisfaction: 1000, expectation: 0, yearIndex: 20 }), 20)
  assert.equal(rules.expectationDesignGrowthMultiplier('创新'), 1)
  assert.equal(rules.expectationDesignGrowthMultiplier('缝合'), 0.95)
  assert.equal(rules.expectationDesignGrowthMultiplier('传统'), 0.9)
})

test('好评更新与第三年小额打赏概率边界正确', () => {
  assert.equal(rules.goodUpdateChance({ expectation: 149.9, satisfaction: 300 }), 0)
  assert.equal(rules.goodUpdateChance({ expectation: 150, satisfaction: 150 }), 0)
  assert.equal(rules.goodUpdateChance({ expectation: 150, satisfaction: 151 }), 0.05)
  assert.equal(rules.goodUpdateChance({ expectation: 300, satisfaction: 301 }), 0.8)
  assert.equal(rules.smallDonationBaseChance({ yearIndex: 1, players: 1_000_000 }), 0)
  assert.equal(rules.smallDonationBaseChance({ yearIndex: 2, players: 0 }), 0.0001)
  assert.equal(rules.smallDonationBaseChance({ yearIndex: 2, players: 5000 }), 0.0002)
  assert.equal(rules.smallDonationBaseChance({ yearIndex: 2, players: 1_000_000 }), 0.003)
})

test('Evendel测试入口、冥想、期待值事件和隐藏状态已接入引擎', async () => {
  const [legacy, debugPanel, operation, mobile] = await Promise.all([
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/DebugPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/OperationPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8'),
  ])

  assert.match(debugPanel, /id="debugAccessPanel"[^>]+hidden/)
  assert.match(legacy, /function testerMode\(\)\{return state\.designConceptConfirmed&&state\.gameName==="Evendel"\}/)
  assert.match(legacy, /function meditate\(\)[\s\S]*?state\.ap\+=50;[\s\S]*?state\.fatigue=Math\.max\(0,state\.fatigue-200\);[\s\S]*?state\.money\+=5000;/)
  assert.match(operation, /id="meditateBtn"[\s\S]*?<b>冥想<\/b>/)
  assert.match(mobile, /\.mobile-debug\[hidden\][\s\S]*?display:\s*none\s*!important/)
  assert.match(legacy, /state\.day<=GAME_RULES\.expectationRules\.fixedDays/)
  assert.match(legacy, /dynamicExpectationGainSinceUpdate/)
  assert.match(legacy, /玩家们对这次的更新相当满意，社区里都聊疯了。/)
  assert.match(legacy, /你收到了一笔玩家打赏，入账了\$\{amount\}！/)
  assert.match(legacy, /version:"Beta60"/)
})

test('三级以上美术可以合作，低级美术会收到指定提示', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')

  assert.match(legacy, /artMemberIds:\[\]/)
  assert.match(legacy, /artIds\.length&&\(m\.rarity<3\|\|artIds\.some\(id=>\(getMember\(id\)\?\.rarity\|\|0\)<3\)\)/)
  assert.match(legacy, /只有3级或以上的美术成员才能与其他美术成员合作。/)
  assert.match(legacy, /for\(const id of \[\.\.\.artIds\]\)/)
  assert.match(legacy, /assignedArts\.length\?assignedArts\.join\("、"\)/)
})

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import * as rules from '../src/game/rules.js'

test('查分器失效基础概率为20%，Beta写程序最低可降至10%', () => {
  assert.equal(rules.scoreTrackerRules.baseFailureChance, 0.2)
  assert.equal(rules.scoreTrackerRules.failureChanceReductionPerBetaProgramWrite, 0.005)
  assert.equal(rules.scoreTrackerRules.maximumFailureChanceReduction, 0.1)
  assert.equal(rules.scoreTrackerRules.minimumFailureChance, 0.1)

  assert.equal(rules.scoreTrackerFailureChance(0), 0.2)
  assert.equal(rules.scoreTrackerFailureChance(0.005), 0.195)
  assert.equal(rules.scoreTrackerFailureChance(0.05), 0.15)
  assert.equal(rules.scoreTrackerFailureChance(0.1), 0.1)
  assert.equal(rules.scoreTrackerFailureChance(1), 0.1)
  assert.equal(rules.nextScoreTrackerFailureReduction(0), 0.005)
  assert.equal(rules.nextScoreTrackerFailureReduction(0.095), 0.1)
  assert.equal(rules.nextScoreTrackerFailureReduction(0.1), 0.1)
})

test('Beta写程序减免按曲包保存，发布时才进行概率判定', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')

  assert.match(legacy, /p\.scoreTrackerFailureReduction=0;p\.leaked=false/)
  assert.match(legacy, /reduceScoreTrackerFailureChanceDuringBeta\(\);\s*advanceScoreTrackerRepair\(\);/)
  assert.match(legacy, /p\.status==="Beta测试"&&\(p\.type==="主线包"\|\|p\.type==="支线包"\)/)
  assert.match(legacy, /nextScoreTrackerFailureReduction\(p\.scoreTrackerFailureReduction\)/)
  assert.match(legacy, /chance\(GAME_RULES\.scoreTrackerFailureChance\(p\.scoreTrackerFailureReduction\)\)/)
  assert.match(legacy, /scheduleScoreTrackerFailure\(p\);/)
  assert.match(legacy, /version:"Beta59"/)
})

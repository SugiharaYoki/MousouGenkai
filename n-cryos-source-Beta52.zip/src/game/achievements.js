export const ACHIEVEMENT_STORAGE_KEY = 'noncommercial_music_game_simulator_achievements_v1'

export const ACHIEVEMENTS = Object.freeze([
  { id: 'new_dream', title: '新的梦想', description: '给自己的游戏起名。' },
  { id: 'first_night', title: '先睡一觉', description: '结束第1日。' },
  { id: 'first_year', title: '加速前进', description: '结束第1年。' },
  { id: 'core_complete', title: '只是个壳', description: '完成游戏本体程序的制作。' },
  { id: 'chart_editor', title: 'TXT大师', description: '完成制谱器的制作。' },
  { id: 'chart_editor_v2', title: '谱师救星', description: '完成制谱器V2的制作。' },
  { id: 'first_member', title: '初次见面', description: '招募第一位成员。' },
  { id: 'first_release', title: '奏响音符', description: '发布第一次更新。' },
  { id: 'program_study_10', title: '勤学苦练', description: '学习10次程序。' },
  { id: 'art_half', title: '我行我上', description: '学会美术。' },
  { id: 'art_complete', title: '我真的行', description: '彻底学会美术。' },
  { id: 'personal_production', title: '你们太慢', description: '亲自进行一次歌曲的内容制作。' },
  { id: 'derivative', title: '储备资源', description: '创作1张衍生图。', hidden: true },
  { id: 'takeout', title: '太好吃了', description: '点1次外卖。' },
  { id: 'stomachache', title: '肚子好痛', description: '点外卖吃坏肚子。' },
  { id: 'trendy_takeout', title: '不详包装', description: '点到国潮外卖。', hidden: true },
  { id: 'job_change', title: '规划改变', description: '“这份工作不适合我的长期规划。”\n更换1次主业。' },
  { id: 'ap_over_42', title: '预制精力', description: '“多有精力也没法在一天内做完所有事情。”\n拥有超过42点行动点。' },
  { id: 'group_rhythm', title: '联机模式', description: '打音游时匹配到同组成员。', hidden: true },
  { id: 'recruit_4', title: '还是大佬', description: '招募1位4级成员。' },
  { id: 'recruit_5', title: '可遇无求', description: '招募1位5级成员。' },
  { id: 'five_real_members', title: '梦见霖音', description: '同时拥有5位真实存在的5级成员。', hidden: true },
  { id: 'recruit_1', title: '真的会吗', description: '招募1位1级成员。' },
  { id: 'member_level_up', title: '这下会了', description: '目睹1位成员的等级增长。' },
  { id: 'chart_collaboration', title: '谱组合作', description: '给一首歌曲同时分配2位谱师。' },
  { id: 'collab_accept', title: '交流计划', description: '接下1次联动。' },
  { id: 'portfolio_song', title: '我喜欢听', description: '入手1首非原创曲。' },
  { id: 'commission_song', title: '曲子来了', description: '入手1首原创曲。' },
  { id: 'commission_failed', title: '石沉大海', description: '约稿失败。' },
  { id: 'formal_commission', title: '隆重合作', description: '发出一次“正式邀请”。' },
  { id: 'expedite', title: '你快点', description: '进行1次催稿。' },
  { id: 'expedite_breakdown', title: '心态爆炸', description: '“虽然不是每位曲师都这样……”\n曲师因为催稿而心态爆炸。', hidden: true },
  { id: 'portfolio_single', title: '先拖一拖', description: '发布1首非原创的单曲。' },
  { id: 'commission_single', title: '铺张浪费', description: '“是谁做非商独占发单曲？”\n发布1首原创的单曲。', hidden: true },
  { id: 'supplement_release', title: '拉高期待', description: '发布1个补充包。' },
  { id: 'announcement', title: '预热', description: '为游戏更新发一次公告。' },
  { id: 'review_delay', title: '我更新呢', description: '游戏更新被卡审核。', hidden: true },
  { id: 'announced_review_delay', title: '你更新呢', description: '“下次试试卡审核了再发公告。”\n在发布公告后，游戏更新被卡审核。', hidden: true },
  { id: 'bad_popularity', title: '劣质热度', description: '获得远高于游玩人数的讨论度。', hidden: true },
  { id: 'member_crazy', title: '组太小了', description: '“我得赶紧多找点人。”\n第一次遭遇成员发疯事件。' },
  { id: 'teammate_help', title: '友情顶班', description: '第一次有组员帮忙完成你的工作。' },
  { id: 'member_friend', title: '职场朋友', description: '“不推荐在职场交朋友。”\n1位成员的好感度到达“朋友”。' },
  { id: 'member_trust', title: '超越梦想', description: '1位成员的好感度到达“信任”。' },
  { id: 'four_trust', title: '结束团队', description: '“我是来结束这个团队的。”\n4位成员的好感度到达“信任”。', hidden: true },
  { id: 'ten_strangers', title: '进错组了', description: '同时有10位成员好感度为“陌生”。', hidden: true },
  { id: 'bad_influence', title: '不良影响', description: '“为什么不带上我？”\n目睹组员造成组内不良影响。', hidden: true },
  { id: 'idle_doubt', title: '闲出病来', description: '“给孩子安排点活干吧。”\n第一次使组员因空闲而“疑虑”。', hidden: true },
  { id: 'recover_member', title: '欢迎回家', description: '“只是个念想，但我需要它。”\n第一次找回退出制作组的组员。' },
  { id: 'fire_leaker', title: '谁是狼人', description: '开除内鬼。', hidden: true },
  { id: 'trust_leaker', title: '养猪', description: '“又或者说，是我在养猪？”\n内鬼的好感度达到“信任”。', hidden: true },
  { id: 'streamer', title: '满屏弹幕', description: '遇到主播直播游玩《游戏名称》。' },
  { id: 'sponsor_income', title: '为爱发电', description: '通过赞助平台获得资金。' },
  { id: 'small_donation', title: '意外之喜', description: '获得一次玩家打赏。' },
  { id: 'side_gig', title: '资金紧缺', description: '赚一次外快。' },
  { id: 'big_side_gig', title: '专业外包', description: '赚一次盆满钵满的外快。' },
  { id: 'money_100k', title: '十万富翁', description: '存款达到100000。' },
  { id: 'money_1m', title: '百万富翁', description: '存款达到1000000。' },
  { id: 'money_10m', title: '我没开挂', description: '存款达到10000000。', hidden: true },
  { id: 'players_1k', title: '第一步', description: '“因为这是美好的梦。”\n游玩人数达到1000。' },
  { id: 'players_10k', title: '梦的暗面', description: '“或许梦想并非如你所愿。”\n游玩人数达到10000。', hidden: true },
  { id: 'players_100k', title: '月光照耀', description: '“是虚构，还是现实之影？”\n游玩人数达到100000。', hidden: true },
  { id: 'players_1m', title: '逆雾之行', description: '“这条路或许已经走过头了。”\n游玩人数达到1000000。', hidden: true },
  { id: 'perfect_start', title: '完美开局', description: '发布第一次更新时，曲包的综合可玩质量达到75。' },
  { id: 'artist', title: '艺术家', description: '保持极高的艺术追求。' },
  { id: 'great_artist', title: '大艺术家', description: '长久保持极高的艺术追求。' },
  { id: 'style_dominance', title: '偏执爱好', description: '曲库中，某一风格的歌曲数量断档领先。' },
  { id: 'first_copywriter', title: '这啥效率', description: '“什么叫一天就写5个字？”\n招聘1位文案成员。' },
  { id: 'first_story', title: '补充设定', description: '“音游要啥剧情？”\n第一次为游戏内容添加剧情。' },
  { id: 'manual_save', title: '断点续播', description: '手动进行一次存档。' },
  { id: 'export_save', title: '刻录历史', description: '“我会在哪一天再次读取它？”\n导出一次存档。' },
  { id: 'gaokao', title: '高考加油', description: '祝制作组成员高考顺利。' },
].map(item => Object.freeze({ ...item, hidden: !!item.hidden })))

const ACHIEVEMENT_BY_ID = new Map(ACHIEVEMENTS.map(item => [item.id, item]))

function normalizeIds(ids) {
  return [...new Set((Array.isArray(ids) ? ids : []).filter(id => ACHIEVEMENT_BY_ID.has(id)))]
}

export function createAchievementManager({ storage, onUnlock = () => {}, now = Date.now }) {
  if (!storage) throw new Error('ACHIEVEMENT_STORAGE_REQUIRED')

  let unlocked = new Set()
  try {
    const stored = JSON.parse(storage.getItem(ACHIEVEMENT_STORAGE_KEY) || '{}')
    unlocked = new Set(normalizeIds(stored.unlocked))
  } catch {
    unlocked = new Set()
  }

  const persist = () => {
    try {
      storage.setItem(ACHIEVEMENT_STORAGE_KEY, JSON.stringify({
        version: 1,
        updatedAt: now(),
        unlocked: [...unlocked],
      }))
      return true
    } catch {
      // 浏览器禁用持久化时，成就在本次运行中仍然有效，不阻断游戏行动。
      return false
    }
  }

  const unlock = (id, { silent = false } = {}) => {
    const definition = ACHIEVEMENT_BY_ID.get(id)
    if (!definition || unlocked.has(id)) return false
    unlocked.add(id)
    persist()
    if (!silent) onUnlock(definition)
    return true
  }

  return Object.freeze({
    unlock,
    merge(ids, options = { silent: true }) {
      let changed = false
      for (const id of normalizeIds(ids)) changed = unlock(id, options) || changed
      return changed
    },
    isUnlocked(id) {
      return unlocked.has(id)
    },
    snapshot() {
      return [...unlocked]
    },
    entries() {
      return ACHIEVEMENTS
        .filter(item => !item.hidden || unlocked.has(item.id))
        .map(item => ({ ...item, unlocked: unlocked.has(item.id) }))
    },
    progress() {
      return { unlocked: unlocked.size, total: ACHIEVEMENTS.length }
    },
  })
}

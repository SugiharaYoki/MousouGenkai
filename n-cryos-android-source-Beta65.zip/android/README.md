# N-CRYOS Beta 65 Android 版

这是以网页 Beta65 为基础制作的完全离线安卓外壳。游戏 HTML、脚本和曲师数据全部打入 APK，应用本身不申请网络权限。

## 使用说明

- 支持 Android 11 及以上版本。
- 自动存档和三个手动存档保存在应用本地数据中；覆盖安装同签名的新版本时会保留。
- 卸载应用会清除本地存档，因此卸载前务必在“管理存档”中导出 TXT。
- 导入和导出使用安卓系统文件选择器，无需授予整个存储空间权限。
- 存档格式与网页版 Beta65 相同，可在网页版和安卓版本之间互相导入。
- 系统返回键会依次关闭当前弹窗、返回“今日”页、将应用退到后台。

## 重新构建

1. 在仓库根目录执行网页构建，将 `dist/index.html` 复制到 `android/app/src/main/assets/www/index.html`。
2. 准备 JDK 17、Android SDK Platform 35 和 Build Tools 35.0.0。
3. 使用 `android/scripts/build-apk.ps1`，传入 SDK、JDK、签名文件和签名密码。

`build.gradle` 可用于导入 Android Studio；本次交付的正式 APK 使用 `scripts/build-apk.ps1` 直接构建并签名。

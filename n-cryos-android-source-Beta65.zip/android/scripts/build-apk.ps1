param(
    [Parameter(Mandatory = $true)][string]$AndroidSdk,
    [Parameter(Mandatory = $true)][string]$JavaHome,
    [Parameter(Mandatory = $true)][string]$Keystore,
    [Parameter(Mandatory = $true)][string]$KeystorePassword
)

$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$buildRoot = Join-Path $projectRoot 'build'
$sourceRoot = Join-Path $projectRoot 'app\src\main'
$buildTools = Join-Path $AndroidSdk 'build-tools\35.0.0'
$androidJar = Join-Path $AndroidSdk 'platforms\android-35\android.jar'
$aapt2 = Join-Path $buildTools 'aapt2.exe'
$d8 = Join-Path $buildTools 'd8.bat'
$zipalign = Join-Path $buildTools 'zipalign.exe'
$apksigner = Join-Path $buildTools 'apksigner.bat'
$javac = Join-Path $JavaHome 'bin\javac.exe'
$jar = Join-Path $JavaHome 'bin\jar.exe'
$javaBin = Join-Path $JavaHome 'bin'

foreach ($required in @($androidJar, $aapt2, $d8, $zipalign, $apksigner, $javac, $jar, $Keystore)) {
    if (-not (Test-Path -LiteralPath $required)) { throw "缺少构建文件：$required" }
}

if (Test-Path -LiteralPath $buildRoot) {
    $resolvedBuild = (Resolve-Path -LiteralPath $buildRoot).Path
    if (-not $resolvedBuild.StartsWith($projectRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw '拒绝清理项目目录之外的构建路径。'
    }
    Remove-Item -LiteralPath $resolvedBuild -Recurse -Force
}

$compiled = Join-Path $buildRoot 'compiled-res.zip'
$unsigned = Join-Path $buildRoot 'unsigned.apk'
$aligned = Join-Path $buildRoot 'aligned.apk'
$classes = Join-Path $buildRoot 'classes'
$dex = Join-Path $buildRoot 'dex'
$appJar = Join-Path $buildRoot 'classes.jar'
$outputDir = Join-Path $buildRoot 'outputs'
$finalApk = Join-Path $outputDir 'n-cryos-Beta65-Android-universal.apk'

New-Item -ItemType Directory -Path $classes, $dex, $outputDir -Force | Out-Null

# Android 的批处理工具会读取 JAVA_HOME；明确固定为本次传入的 JDK，避免误用系统 Java 8。
$env:JAVA_HOME = $JavaHome
$env:Path = "$javaBin;$env:Path"

& $aapt2 compile --dir (Join-Path $sourceRoot 'res') -o $compiled
if ($LASTEXITCODE -ne 0) { throw 'Android 资源编译失败。' }

& $aapt2 link -o $unsigned -I $androidJar --manifest (Join-Path $sourceRoot 'AndroidManifest.xml') --auto-add-overlay $compiled
if ($LASTEXITCODE -ne 0) { throw 'Android 资源打包失败。' }

# aapt2 在 Windows 上会把 -A 中的子目录写成反斜杠；显式用 jar 写入标准 APK 路径。
& $jar --update --file $unsigned -C $sourceRoot 'assets/www/index.html'
if ($LASTEXITCODE -ne 0) { throw '离线网页写入 APK 失败。' }

& $javac -encoding UTF-8 -source 17 -target 17 -classpath $androidJar -d $classes (Join-Path $sourceRoot 'java\com\mousougenkai\ncryos\MainActivity.java')
if ($LASTEXITCODE -ne 0) { throw 'Java 编译失败。' }

& $jar --create --file $appJar -C $classes .
if ($LASTEXITCODE -ne 0) { throw 'Java 类打包失败。' }

& $d8 --lib $androidJar --min-api 30 --output $dex $appJar
if ($LASTEXITCODE -ne 0) { throw 'DEX 转换失败。' }

& $jar --update --file $unsigned -C $dex classes.dex
if ($LASTEXITCODE -ne 0) { throw 'DEX 写入 APK 失败。' }

& $zipalign -p -f 4 $unsigned $aligned
if ($LASTEXITCODE -ne 0) { throw 'APK 对齐失败。' }

& $apksigner sign --ks $Keystore --ks-key-alias ncryos --ks-pass "pass:$KeystorePassword" --key-pass "pass:$KeystorePassword" --out $finalApk $aligned
if ($LASTEXITCODE -ne 0) { throw 'APK 签名失败。' }

& $apksigner verify --verbose --print-certs $finalApk
if ($LASTEXITCODE -ne 0) { throw 'APK 签名校验失败。' }

Write-Output $finalApk

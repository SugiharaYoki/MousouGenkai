N-CRYOS Android 更新签名说明

别名：ncryos
密钥库密码：ncryos-beta65
密钥密码：ncryos-beta65

请把随交付文件提供的 n-cryos-android-release.keystore 单独备份，并且不要公开上传。
以后发布覆盖安装的安卓更新时，必须继续使用同一个密钥签名。若密钥丢失，已安装用户将无法直接覆盖升级，只能先导出存档、卸载旧版、安装新版，再导入存档。


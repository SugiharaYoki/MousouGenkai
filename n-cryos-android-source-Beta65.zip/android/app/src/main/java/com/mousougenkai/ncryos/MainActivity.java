package com.mousougenkai.ncryos;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String APP_URL = "https://" + APP_HOST + "/index.html";
    private static final int REQUEST_IMPORT_SAVE = 6501;
    private static final int REQUEST_EXPORT_SAVE = 6502;

    private WebView webView;
    private ValueCallback<Uri[]> importCallback;
    private String pendingExportContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(8, 13, 23));
        getWindow().setNavigationBarColor(Color.rgb(8, 13, 23));
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 13, 23));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        configureWebView(webView);
        setContentView(webView);

        if (savedInstanceState == null) webView.loadUrl(APP_URL);
        else webView.restoreState(savedInstanceState);
    }

    private void configureWebView(WebView view) {
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " NCRYOS-Android/1");

        WebView.setWebContentsDebuggingEnabled(false);
        view.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        view.setWebViewClient(new LocalAppWebViewClient());
        view.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> filePathCallback,
                FileChooserParams fileChooserParams
            ) {
                if (importCallback != null) importCallback.onReceiveValue(null);
                importCallback = filePathCallback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain", "application/octet-stream"});
                try {
                    startActivityForResult(intent, REQUEST_IMPORT_SAVE);
                    return true;
                } catch (ActivityNotFoundException error) {
                    importCallback = null;
                    Toast.makeText(MainActivity.this, "设备上没有可用的文件选择器。", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT_SAVE) {
            if (importCallback == null) return;
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            importCallback.onReceiveValue(result);
            importCallback = null;
            return;
        }
        if (requestCode == REQUEST_EXPORT_SAVE) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                pendingExportContent = null;
                notifyExportResult("cancelled");
                return;
            }
            Uri target = data.getData();
            try (OutputStream output = getContentResolver().openOutputStream(target, "wt");
                 OutputStreamWriter writer = output == null ? null : new OutputStreamWriter(output, StandardCharsets.UTF_8)) {
                if (writer == null) throw new IOException("Unable to open target document");
                writer.write(pendingExportContent == null ? "" : pendingExportContent);
                writer.flush();
                Toast.makeText(this, "存档已保存。", Toast.LENGTH_SHORT).show();
                notifyExportResult("saved");
            } catch (Exception error) {
                Toast.makeText(this, "存档保存失败，请重新选择位置。", Toast.LENGTH_LONG).show();
                notifyExportResult("failed");
            } finally {
                pendingExportContent = null;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
            "(() => window.__NCRYOS_ANDROID_BACK__ ? (window.__NCRYOS_ANDROID_BACK__() ? 'handled' : 'exit') : 'exit')()",
            result -> {
                if (!"\"handled\"".equals(result)) moveTaskToBack(true);
            }
        );
    }

    @Override
    protected void onDestroy() {
        if (importCallback != null) importCallback.onReceiveValue(null);
        importCallback = null;
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private void notifyExportResult(String status) {
        if (webView == null) return;
        String quoted = JSONObject.quote(status);
        webView.evaluateJavascript(
            "window.__NCRYOS_ANDROID_EXPORT_RESULT__ && window.__NCRYOS_ANDROID_EXPORT_RESULT__(" + quoted + ")",
            null
        );
    }

    private void openExternalUrl(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, "设备上没有可以打开此链接的应用。", Toast.LENGTH_SHORT).show();
        }
    }

    private WebResourceResponse localAssetResponse(Uri uri) {
        if (!APP_HOST.equalsIgnoreCase(uri.getHost())) return emptyResponse();
        String path = uri.getPath();
        if (path == null || path.equals("/")) path = "/index.html";
        if (path.contains("..")) return emptyResponse();
        String assetPath = "www" + path;
        try {
            InputStream input = getAssets().open(assetPath);
            return new WebResourceResponse(mimeType(path), "UTF-8", input);
        } catch (IOException error) {
            return emptyResponse();
        }
    }

    private static WebResourceResponse emptyResponse() {
        return new WebResourceResponse(
            "text/plain",
            "UTF-8",
            new ByteArrayInputStream(new byte[0])
        );
    }

    private static String mimeType(String path) {
        String lower = path.toLowerCase();
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".js")) return "application/javascript";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        return "application/octet-stream";
    }

    private final class LocalAppWebViewClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (APP_HOST.equalsIgnoreCase(uri.getHost())) return localAssetResponse(uri);
            return emptyResponse();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (APP_HOST.equalsIgnoreCase(uri.getHost())) return false;
            if (request.isForMainFrame()) openExternalUrl(uri);
            return true;
        }
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void saveTextFile(String suggestedName, String content) {
            runOnUiThread(() -> {
                if (pendingExportContent != null) {
                    notifyExportResult("failed");
                    return;
                }
                pendingExportContent = content == null ? "" : content;
                String safeName = suggestedName == null ? "n-cryos-save.txt" : suggestedName;
                safeName = safeName.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (!safeName.toLowerCase().endsWith(".txt")) safeName += ".txt";

                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                try {
                    startActivityForResult(intent, REQUEST_EXPORT_SAVE);
                } catch (ActivityNotFoundException error) {
                    pendingExportContent = null;
                    Toast.makeText(MainActivity.this, "设备上没有可用的文件保存器。", Toast.LENGTH_LONG).show();
                    notifyExportResult("failed");
                }
            });
        }
    }
}

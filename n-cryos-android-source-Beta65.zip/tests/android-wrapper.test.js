import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

test('Android 外壳完全离线且不申请网络与存储权限', async () => {
  const manifest = await readFile(new URL('../android/app/src/main/AndroidManifest.xml', import.meta.url), 'utf8')
  assert.doesNotMatch(manifest, /android\.permission\.INTERNET/)
  assert.doesNotMatch(manifest, /READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE|MANAGE_EXTERNAL_STORAGE/)
  assert.match(manifest, /android:minSdkVersion="30"/)
  assert.match(manifest, /android:usesCleartextTraffic="false"/)
})

test('Android 使用安全本地域名、原生文件选择器与返回键适配', async () => {
  const activity = await readFile(new URL('../android/app/src/main/java/com/mousougenkai/ncryos/MainActivity.java', import.meta.url), 'utf8')
  assert.match(activity, /https:\/\/" \+ APP_HOST \+ "\/index\.html/)
  assert.match(activity, /ACTION_OPEN_DOCUMENT/)
  assert.match(activity, /ACTION_CREATE_DOCUMENT/)
  assert.match(activity, /__NCRYOS_ANDROID_BACK__/)
  assert.match(activity, /addJavascriptInterface\(new AndroidBridge\(\), "AndroidBridge"\)/)
})

test('网页层为 Android 强制手机布局并接入原生导出回调', async () => {
  const [index, app, legacy, mobile] = await Promise.all([
    readFile(new URL('../index.html', import.meta.url), 'utf8'),
    readFile(new URL('../src/App.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8'),
  ])
  assert.match(index, /Beta 65 · Android/)
  assert.match(index, /Boolean\(window\.AndroidBridge\)/)
  assert.match(app, /__NCRYOS_ANDROID_BACK__/)
  assert.match(legacy, /AndroidBridge\.saveTextFile/)
  assert.match(legacy, /__NCRYOS_ANDROID_EXPORT_RESULT__/)
  assert.match(mobile, /html\.android-app \.device-switch-button/)
})

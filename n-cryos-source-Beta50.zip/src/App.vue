<script setup>
import { ref } from 'vue'
import DesignConceptPanel from './components/DesignConceptPanel.vue'
import AppHeader from './components/AppHeader.vue'
import OperationPanel from './components/OperationPanel.vue'
import ServicesPanel from './components/ServicesPanel.vue'
import TeamPanel from './components/TeamPanel.vue'
import EconomyPanel from './components/EconomyPanel.vue'
import InfoPanel from './components/InfoPanel.vue'
import ContentPanel from './components/ContentPanel.vue'
import DebugPanel from './components/DebugPanel.vue'
import EventPanel from './components/EventPanel.vue'
import EventToast from './components/EventToast.vue'
import { useLegacyActions } from './composables/useLegacyActions'

const { invoke } = useLegacyActions()

const mobilePage = ref('today')

const openMobilePage = (page) => {
  mobilePage.value = page
  window.scrollTo({ top: 0, behavior: 'smooth' })
}
</script>

<template>
  <EventToast />

  <button
    id="deviceSwitchButton"
    class="device-switch-button touch-control"
    type="button"
    title="切换电脑端/手机端显示"
    aria-label="切换电脑端、手机端或自动显示模式"
    @click="invoke('toggleDeviceMode')"
  >
    ↔
  </button>

  <div class="mobile-rotate-shell">
    <main class="app" :data-mobile-page="mobilePage">
      <DesignConceptPanel />
      <AppHeader />

      <div class="layout">
        <div class="col left-column">
          <OperationPanel />
          <ServicesPanel />
          <TeamPanel />
          <EconomyPanel />
        </div>

        <div class="col center-column">
          <InfoPanel />
          <ContentPanel />
          <DebugPanel />
        </div>

        <EventPanel />
      </div>
    </main>

    <nav class="mobile-navigation" aria-label="手机端主导航">
      <button
        class="mobile-nav-item"
        :class="{ active: mobilePage === 'today' }"
        type="button"
        :aria-current="mobilePage === 'today' ? 'page' : undefined"
        @click="openMobilePage('today')"
      >
        <span class="mobile-nav-icon" aria-hidden="true">今</span>
        <span>今日</span>
      </button>
      <button
        class="mobile-nav-item"
        :class="{ active: mobilePage === 'team' }"
        type="button"
        :aria-current="mobilePage === 'team' ? 'page' : undefined"
        @click="openMobilePage('team')"
      >
        <span class="mobile-nav-icon" aria-hidden="true">组</span>
        <span>团队</span>
      </button>
      <button
        class="mobile-nav-item"
        :class="{ active: mobilePage === 'content' }"
        type="button"
        :aria-current="mobilePage === 'content' ? 'page' : undefined"
        @click="openMobilePage('content')"
      >
        <span class="mobile-nav-icon" aria-hidden="true">曲</span>
        <span>内容</span>
      </button>
      <button
        class="mobile-nav-item"
        :class="{ active: mobilePage === 'status' }"
        type="button"
        :aria-current="mobilePage === 'status' ? 'page' : undefined"
        @click="openMobilePage('status')"
      >
        <span class="mobile-nav-icon" aria-hidden="true">数</span>
        <span>状态</span>
      </button>
      <button
        class="mobile-nav-item mobile-nav-events"
        :class="{ active: mobilePage === 'events' }"
        type="button"
        :aria-current="mobilePage === 'events' ? 'page' : undefined"
        @click="openMobilePage('events')"
      >
        <span class="mobile-nav-icon" aria-hidden="true">记<i></i></span>
        <span>事件</span>
      </button>
    </nav>
  </div>
</template>

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import * as rules from '../src/game/rules.js'

test('首更、断更与成员保护采用 Beta47 数值', async () => {
  assert.equal(rules.firstReleaseTier(49.9), 'bad')
  assert.equal(rules.firstReleaseTier(50), 'normal')
  assert.equal(rules.firstReleaseTier(73), 'normal')
  assert.equal(rules.firstReleaseTier(73.01), 'perfect')
  assert.equal(rules.memberProtectedFromInactivityDeparture({ currentDay: 189, actualJoinDay: 100 }), true)
  assert.equal(rules.memberProtectedFromInactivityDeparture({ currentDay: 190, actualJoinDay: 100 }), false)

  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  assert.match(legacy, /游戏已经很久没更新了，玩家已经注意到我们的长期断更。","red"/)
})

test('组内爆炸按人数限制作曲影响，并可被高好感成员化解', () => {
  assert.equal(rules.teamExplosionSongLimit(9), 1)
  assert.equal(rules.teamExplosionSongLimit(10), 2)
  assert.equal(rules.teamExplosionSongLimit(14), 2)
  assert.equal(rules.teamExplosionSongLimit(15), 3)
  assert.equal(rules.teamExplosionDefuseChance(0), 0)
  assert.equal(rules.teamExplosionDefuseChance(1), 0.15)
  assert.equal(rules.teamExplosionDefuseChance(20), 0.6)
})

test('未学完美术时亲自画图每次只降低0.7且不会由此跌破45', () => {
  assert.equal(rules.personalArtQualityAfterPenalty(90), 89.3)
  assert.equal(rules.personalArtQualityAfterPenalty(45.2), 45)
  assert.equal(rules.personalArtQualityAfterPenalty(40), 40)
})

test('联动从第二年开放，第700天有保底，歌曲名使用随机池标题前缀', () => {
  assert.equal(rules.collabAvailableFromYear(0), false)
  assert.equal(rules.collabAvailableFromYear(1), true)
  assert.equal(rules.shouldForceCollabOffer({ day: 699, everTriggered: false }), false)
  assert.equal(rules.shouldForceCollabOffer({ day: 700, everTriggered: false }), true)
  assert.equal(rules.shouldForceCollabOffer({ day: 700, everTriggered: true }), false)
  assert.equal(rules.formatCollabSongTitle('Arcade', 'Frozen Pulse'), '《Arcade》联动·Frozen Pulse')
})

test('涩图后续好感只对45以上成员生效，并封顶75', () => {
  assert.equal(rules.shouldScheduleLewdImageFollowup(45), false)
  assert.equal(rules.shouldScheduleLewdImageFollowup(45.01), true)
  assert.equal(rules.lewdImageFollowupAffection(74.5), 75)
  assert.equal(rules.lewdImageFollowupAffection(75), 75)
})

test('界面文案、剧情永久解锁、曲库筛选与手机事件浮窗已接入', async () => {
  const [operation, content, economy, app, legacy, mobileCss] = await Promise.all([
    readFile(new URL('../src/components/OperationPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/ContentPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/EconomyPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/App.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8'),
  ])

  assert.match(operation, /id="writeCopyLabel">写动态</)
  assert.match(operation, /save-box-arrow/)
  assert.match(content, /toggleInstalledSongsVisibility/)
  assert.match(economy, /曲师日记/)
  assert.match(app, /EventToast/)
  assert.match(mobileCss, /html\.mobile-ui \.event-toast\.show/)
  assert.match(legacy, /supportsStory&&state\.hasHadCopywriter/)
  assert.match(legacy, /if\(joined\.role==="copy"\)state\.hasHadCopywriter=true/)
  assert.match(legacy, /你的精彩动态文案吸引到了一些剧情写手/)
  assert.match(legacy, /找回成员\$\{name\}成功！制作组的大家或许其实很开心。/)
  assert.doesNotMatch(legacy, /找回成员xx成功/)
  assert.match(legacy, /没有接受约稿，下次再试试吧。/)
  assert.match(legacy, /memberProtectedFromInactivityDeparture\(\{currentDay:state\.day/)
  assert.match(legacy, /processLewdImageFollowups\(\);serviceMonthlyCost/)
  assert.match(legacy, /forceCollabOfferDaily\(\);if\(isMonthStart\(\)\)/)
  assert.match(legacy, /formatCollabSongTitle\(offer\.gameName,pickCommissionTitle\(style\)\)/)
})

test('新增58个成员名与三组风格专属曲名进入对应随机池', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  const memberMatch = legacy.match(/const ADDITIONAL_MEMBER_NAME_POOL=(\[[^\n]+\]);/)
  const styleMatch = legacy.match(/const STYLE_COMMISSION_TITLE_POOLS=(\{[\s\S]*?\n\});/)
  assert.ok(memberMatch)
  assert.ok(styleMatch)

  const memberNames = JSON.parse(memberMatch[1])
  const styleTitles = JSON.parse(styleMatch[1])
  assert.equal(memberNames.length, 58)
  assert.equal(new Set(memberNames).size, 58)
  assert.deepEqual(Object.keys(styleTitles).sort(), ['冷冽', '抒情', '灼热'].sort())
  assert.equal(styleTitles.抒情.length, 20)
  assert.equal(styleTitles.灼热.length, 20)
  assert.equal(styleTitles.冷冽.length, 20)
  assert.ok(styleTitles.抒情.includes('Melody of Memories'))
  assert.ok(styleTitles.灼热.includes('Hyperdrive Overload'))
  assert.ok(styleTitles.冷冽.includes('Frostbound'))
  assert.match(legacy, /function pickCommissionTitle\(style\)/)
  assert.match(legacy, /STYLE_COMMISSION_TITLE_POOLS\[style\]/)
  assert.match(legacy, /pickCommissionTitle\(x\.style\)/)
  assert.match(legacy, /pickCommissionTitle\(style\)/)
})

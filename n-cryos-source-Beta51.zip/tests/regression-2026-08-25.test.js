import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

test('导入存档按钮通过 Vue 模板引用打开隐藏文件输入', async () => {
  const operation = await readFile(new URL('../src/components/OperationPanel.vue', import.meta.url), 'utf8')

  assert.match(operation, /const importSaveFile = ref\(null\)/)
  assert.match(operation, /importSaveFile\.value\?\.click\(\)/)
  assert.match(operation, /@click="openImportSave"/)
  assert.match(operation, /ref="importSaveFile"/)
  assert.doesNotMatch(operation, /@click="document\.getElementById/)
})

test('手机端约稿类型预览获得较宽列，约稿按钮独占下一行', async () => {
  const css = await readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8')

  assert.match(css, /html\.mobile-ui \.commission-controls\s*\{[\s\S]*?grid-template-columns:\s*minmax\(0,\s*1\.45fr\) minmax\(0,\s*\.75fr\)\s*!important;/)
  assert.match(css, /html\.mobile-ui \.commission-btn\s*\{[\s\S]*?grid-column:\s*1\s*\/\s*-1\s*!important;/)
})

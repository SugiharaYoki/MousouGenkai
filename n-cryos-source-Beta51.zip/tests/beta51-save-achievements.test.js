import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import {
  createSaveSlotStore,
  LEGACY_SINGLE_SAVE_KEY,
  SAVE_SLOT_KEYS,
} from '../src/game/save-slots.js'
import {
  ACHIEVEMENTS,
  createAchievementManager,
} from '../src/game/achievements.js'

function createMemoryStorage(initial = {}) {
  const values = new Map(Object.entries(initial))
  return {
    getItem(key) { return values.has(key) ? values.get(key) : null },
    setItem(key, value) { values.set(key, String(value)) },
    removeItem(key) { values.delete(key) },
  }
}

test('旧单槽存档迁移到手动槽，自动与手动槽保持独立', () => {
  const legacy = { state: { day: 17 }, savedAt: 1 }
  const storage = createMemoryStorage({ [LEGACY_SINGLE_SAVE_KEY]: JSON.stringify(legacy) })
  const store = createSaveSlotStore({ storage })

  assert.deepEqual(store.read('manual'), legacy)
  assert.equal(store.read('auto'), null)

  store.write('auto', { state: { day: 18 }, savedAt: 2 })
  store.write('manual', { state: { day: 12 }, savedAt: 3 })
  assert.equal(store.read('auto').state.day, 18)
  assert.equal(store.read('manual').state.day, 12)
  assert.ok(storage.getItem(SAVE_SLOT_KEYS.auto))
  assert.ok(storage.getItem(SAVE_SLOT_KEYS.manual))
})

test('66项成就共用独立持久状态，隐藏成就解锁前不显示', () => {
  const storage = createMemoryStorage()
  const first = createAchievementManager({ storage, now: () => 1 })

  assert.equal(ACHIEVEMENTS.length, 66)
  assert.equal(first.entries().some(item => item.id === 'trendy_takeout'), false)
  assert.equal(first.entries().find(item => item.id === 'new_dream').unlocked, false)

  first.unlock('new_dream')
  first.unlock('trendy_takeout')
  const second = createAchievementManager({ storage, now: () => 2 })
  assert.equal(second.isUnlocked('new_dream'), true)
  assert.equal(second.entries().find(item => item.id === 'trendy_takeout').unlocked, true)
  assert.equal(second.progress().unlocked, 2)

  second.merge(['manual_save', 'not_a_real_achievement'])
  assert.deepEqual(new Set(second.snapshot()), new Set(['new_dream', 'trendy_takeout', 'manual_save']))
})

test('Beta51存档、成就入口与日结自动存档接入界面和引擎', async () => {
  const [legacy, app, operation, eventPanel, mobile, index] = await Promise.all([
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
    readFile(new URL('../src/App.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/OperationPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/EventPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8'),
    readFile(new URL('../index.html', import.meta.url), 'utf8'),
  ])

  assert.match(index, /Beta 51/)
  assert.match(operation, /管理存档/)
  assert.match(operation, /自动存档/)
  assert.match(operation, /玩家自主存档/)
  assert.match(operation, /开始新游戏/)
  assert.match(operation, /导入存档/)
  assert.match(legacy, /bankruptcyCheck\(\);render\(\);autosaveGame\(\)/)
  assert.match(legacy, /achievements:achievementManager\.snapshot\(\)/)
  assert.match(legacy, /song\.source!=="tutorial"&&song\.style===style/)
  assert.match(legacy, /firstUpdateDay\+180/)
  assert.match(legacy, /firstUpdateDay\+360/)
  assert.match(legacy, /if\(!free\)state\.fatigue\+=30/)
  assert.doesNotMatch(legacy, /state\.spirit/)
  assert.match(eventPanel, /achievement-trigger/)
  assert.match(app, /achievementListMobileMount/)
  assert.match(mobile, /data-mobile-page='status'.*achievement-mobile-slot/)
  assert.match(mobile, /resource-toast/)
})

test('成员晋级原地继承，常规4升5分支不存在，开除升级会使开除失败', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  const promote = legacy.match(/function promoteMember\(m,newRarity\)[\s\S]*?\n}/)?.[0] || ''
  const fire = legacy.match(/function fireMember\(id\)[\s\S]*?\n}/)?.[0] || ''

  assert.match(promote, /m\.rarity=after/)
  assert.doesNotMatch(promote, /createJoinedMember|state\.applications\.push/)
  assert.match(fire, /if\(m\.rarity<5&&chance\(\.05\)\)/)
  assert.match(fire, /promoteMember\(m,before\+1\)/)
  assert.match(fire, /这次开除失败了/)
  assert.doesNotMatch(legacy, /m\.rarity===4[\s\S]{0,160}promoteMember\(m,5\)/)
})

test('三首新增作品的数据和合作归属完全匹配需求', async () => {
  const portfolios = JSON.parse(await readFile(new URL('../src/data/portfolios.json', import.meta.url), 'utf8'))
  const byName = name => portfolios.find(item => item.name === name)

  assert.deepEqual(byName('Tears of Demon'), {
    id: 51006, name: 'Tears of Demon', price: 1200, quality: 2, abstract: 2,
    style: '冷冽', attention: 40, discussion: 20, good: 50, bought: false, note: '',
    composerLabel: '鱿羽鱼', collabComposerIds: [5], sharedPortfolioKey: '鱿羽鱼|Tears of Demon',
    ownerComposerId: 5, ownerComposerName: '鱿羽鱼',
  })
  assert.deepEqual(byName('温室花房第7作：flashback').collabComposerIds, [11, 31])
  assert.deepEqual(byName('温室花房第8作：magic').collabComposerIds, [11, 1003])
  assert.deepEqual(
    ['price', 'quality', 'abstract', 'style', 'attention', 'discussion', 'good'].map(key => byName('温室花房第7作：flashback')[key]),
    [4800, 5, 3, '冷冽', 40, 50, 80],
  )
  assert.deepEqual(
    ['price', 'quality', 'abstract', 'style', 'attention', 'discussion', 'good'].map(key => byName('温室花房第8作：magic')[key]),
    [4800, 4, 4, '灼热', 60, 50, 70],
  )
})

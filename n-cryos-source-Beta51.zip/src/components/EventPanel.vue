<script setup>
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke } = useLegacyActions()
</script>

<template>
  <aside class="event-col">
    <section class="panel">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">EVENT FEED</p>
          <h2 class="section-heading">事件记录</h2>
        </div>
        <div class="event-heading-tools">
          <button class="achievement-trigger" type="button" title="成就一览" aria-label="打开成就一览" @click="invoke('openAchievementDialog')">◆</button>
          <span class="live-indicator"><i></i> LIVE</span>
        </div>
      </div>
      <div class="event-resource">
        <div><span>行动点</span><b id="eventActionPoints">18</b></div>
        <div><span>精神</span><b id="eventSpirit">200</b></div>
        <div><span>余额</span><b id="eventBalance">10,000</b></div>
      </div>
      <div id="log" class="log" aria-live="polite"></div>
    </section>
  </aside>
</template>

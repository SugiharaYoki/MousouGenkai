<template>
  <header class="top">
    <div class="min-w-0">
      <p class="eyebrow">N-CRYOS CONSOLE</p>
      <h1 id="gameSimulatorTitle">非商业音乐游戏运营模拟器 · Beta 51</h1>
    </div>
    <div class="time" aria-label="游戏日期">
      <b id="timeMain"></b>
      <div id="dateSub" class="sub"></div>
    </div>
  </header>
</template>

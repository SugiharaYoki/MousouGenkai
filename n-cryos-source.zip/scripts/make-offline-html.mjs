import { readFile, writeFile } from 'node:fs/promises'

const outputUrl = new URL('../dist/index.html', import.meta.url)
const html = await readFile(outputUrl, 'utf8')
const moduleScripts = [...html.matchAll(/\s*<script\s+type="module"[^>]*>([\s\S]*?)<\/script>/g)]

if (moduleScripts.length !== 1) {
  throw new Error(`预期恰好一个内嵌模块脚本，实际找到 ${moduleScripts.length} 个。`)
}

const [moduleScript] = moduleScripts
const classicScript = `\n    <script>${moduleScript[1]}</script>\n  `
const offlineHtml = html
  .replace(moduleScript[0], '')
  .replace('</body>', () => `${classicScript}</body>`)

await writeFile(outputUrl, offlineHtml, 'utf8')
console.log('已将主脚本转换为可直接双击打开的离线脚本。')

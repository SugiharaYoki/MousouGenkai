import { defineConfig, presetUno } from 'unocss'

export default defineConfig({
  presets: [presetUno()],
  theme: {
    colors: {
      ink: '#eef4ff',
      muted: '#99a9c2',
      accent: '#78a0ff',
    },
  },
  shortcuts: {
    'section-heading': 'm-0 text-[15px] font-800 tracking-wide md:text-[17px]',
    'touch-control': 'min-h-11 touch-manipulation',
    'metric-grid': 'grid grid-cols-2 gap-2 sm:grid-cols-4',
  },
})

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  absoluteGameDay,
  betaLeakChance,
  hiddenMemberRules,
  memberStartsAsMinor,
  shouldBecomePotentialInsider,
} from '../src/game/rules.js'

test('成员年龄在入组时按等级概率固定', () => {
  assert.equal(memberStartsAsMinor(1, () => 0.7999), true)
  assert.equal(memberStartsAsMinor(1, () => 0.8), false)
  assert.equal(memberStartsAsMinor(3, () => 0.3999), true)
  assert.equal(memberStartsAsMinor(3, () => 0.4), false)
  assert.equal(memberStartsAsMinor(4, () => 0), false)
  assert.equal(memberStartsAsMinor(5, () => 0.4999), true)
  assert.equal(memberStartsAsMinor(5, () => 0.5), false)
})

test('3 级成员不会成为潜在内鬼', () => {
  assert.equal(shouldBecomePotentialInsider({ rarity: 3, isMinor: true, random: () => 0 }), false)
})

test('潜在内鬼使用成年 3%、未成年 6% 的边界', () => {
  assert.equal(shouldBecomePotentialInsider({ rarity: 4, isMinor: false, random: () => 0.0299 }), true)
  assert.equal(shouldBecomePotentialInsider({ rarity: 4, isMinor: false, random: () => 0.03 }), false)
  assert.equal(shouldBecomePotentialInsider({ rarity: 2, isMinor: true, random: () => 0.0599 }), true)
  assert.equal(shouldBecomePotentialInsider({ rarity: 2, isMinor: true, random: () => 0.06 }), false)
})

test('泄露概率按泄密者数量和曲包类型计算', () => {
  assert.ok(Math.abs(betaLeakChance('主线包', 2) - 0.0032) < Number.EPSILON)
  assert.ok(Math.abs(betaLeakChance('补充包', 2) - 0.0032) < Number.EPSILON)
  assert.ok(Math.abs(betaLeakChance('支线包', 2) - 0.0096) < Number.EPSILON)
  assert.ok(Math.abs(betaLeakChance('单曲', 2) - 0.0096) < Number.EPSILON)
})

test('高考日期使用每月 30 天的现有游戏日历', () => {
  assert.equal(absoluteGameDay(1, 1, 1), 366)
  assert.equal(absoluteGameDay(1, 2, 1), 396)
  assert.equal(absoluteGameDay(1, 6, 11), 526)
  assert.equal(hiddenMemberRules.adulthoodTransitionMinDays, 720)
  assert.equal(hiddenMemberRules.adulthoodTransitionMaxDays, 1080)
})

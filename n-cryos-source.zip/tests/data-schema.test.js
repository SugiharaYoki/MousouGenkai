import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

const loadJson = async (path) => JSON.parse(await readFile(new URL(path, import.meta.url), 'utf8'))

test('曲师数据保持稳定接口与唯一标识', async () => {
  const composers = await loadJson('../src/data/composers.json')
  const ids = new Set()
  const names = new Set()

  for (const composer of composers) {
    assert.equal(Number.isFinite(composer.id), true)
    assert.equal(typeof composer.name, 'string')
    assert.equal(ids.has(composer.id), false, `重复曲师 id：${composer.id}`)
    assert.equal(names.has(composer.name), false, `重复曲师名称：${composer.name}`)
    ids.add(composer.id)
    names.add(composer.name)
    for (const key of ['非商', '商业', '正式邀请']) assert.equal(Number.isFinite(composer.prices[key]), true)
    for (const key of ['灼热', '抒情', '冷冽']) assert.equal(Number.isFinite(composer.styles[key]), true)
  }
})

test('作品数据能稳定挂载到存在的曲师', async () => {
  const [composers, portfolios] = await Promise.all([
    loadJson('../src/data/composers.json'),
    loadJson('../src/data/portfolios.json'),
  ])
  const composerNames = new Set(composers.map((composer) => composer.name))

  for (const portfolio of portfolios) {
    assert.equal(Number.isFinite(portfolio.id), true)
    assert.equal(typeof portfolio.name, 'string')
    assert.ok(['灼热', '抒情', '冷冽'].includes(portfolio.style), `未知风格：${portfolio.style}`)
    for (const key of ['price', 'attention', 'discussion', 'good']) assert.equal(Number.isFinite(portfolio[key]), true)
    const owners = String(portfolio.ownerComposerName || '')
      .split(/[,，、|]/)
      .map((name) => name.trim())
      .filter(Boolean)
    assert.ok(owners.length > 0, `作品缺少曲师：${portfolio.name}`)
    for (const owner of owners) assert.ok(composerNames.has(owner), `作品 ${portfolio.name} 引用了不存在的曲师 ${owner}`)
  }
})

test('曲师与作品界面使用分层卡片结构', async () => {
  const source = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  for (const className of ['composer-header', 'commission-section', 'style-mastery', 'portfolio-section', 'portfolio-metrics']) {
    assert.match(source, new RegExp(`class=\\"[^\\"]*${className}`))
  }
})

import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

const html = await readFile(new URL('../dist/index.html', import.meta.url), 'utf8')
const body = html.match(/<body>([\s\S]*?)<\/body>/)?.[1] ?? ''
const scripts = [...html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)]
const mainScript = scripts.find((script) => script.index > html.indexOf('<body>'))

assert.ok(body.includes('id="app"'), '构建结果缺少 #app 容器')
assert.equal(scripts.length, 2, '构建结果应只包含初始化脚本和主脚本')
assert.equal(/<script[^>]+src=/.test(html), false, '构建结果仍有外部脚本')
assert.equal(/<link[^>]+rel=["']stylesheet/.test(html), false, '构建结果仍有外部样式')
assert.equal(/<script[^>]+type=["']module/.test(html), false, '本地文件不应保留模块脚本')
assert.ok(mainScript, '构建结果缺少主脚本')
assert.ok(mainScript[2].length > 100_000, '主脚本内容不完整')
assert.ok(html.indexOf('id="app"') < mainScript.index, '主脚本必须位于 #app 容器之后')
assert.doesNotThrow(() => new Function(mainScript[2]), '主脚本必须能作为普通脚本解析')

console.log(`单文件离线构建校验通过：${html.length} 字符，${scripts.length} 个内嵌脚本。`)

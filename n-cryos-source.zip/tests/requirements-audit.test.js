import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

import * as rules from '../src/game/rules.js'

test('开除成员固定消耗 3 行动点', () => {
  assert.equal(rules.FIRE_MEMBER_ACTION_COST, 3)
})

test('开除按钮使用二次确认文案', async () => {
  const source = await Promise.all([
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/TeamPanel.vue', import.meta.url), 'utf8'),
  ]).then((files) => files.join('\n'))
  assert.match(source, /确定开除成员.*吗？将会消耗3行动点/)
  assert.match(source, /狠心开除/)
  assert.match(source, /点错了/)
  assert.match(source, /onclick="openFireMemberDialog\(\$\{m\.id\}\)">开除<\/button>/)
})

test('制作组说明和年龄信息进入可见界面', async () => {
  const [teamPanel, legacy] = await Promise.all([
    readFile(new URL('../src/components/TeamPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
  ])
  assert.match(teamPanel, /1\/2\/3级成员随等级降低占用的成员管理协调值/)
  assert.match(teamPanel, /5级成员可遇不可求/)
  assert.match(legacy, /state\.candidate\.isMinor\?"未成年":"成人"/)
  assert.match(legacy, /m\.isMinor\?"未成年":"成人"/)
  assert.match(legacy, /成年了！/)
})

test('各等级成员的未成年概率符合产品规则', () => {
  assert.deepEqual([1, 2, 3, 4, 5].map(rules.getMinorRecruitChance), [0.8, 0.6, 0.4, 0, 0.5])
})

test('只有未成年触发学业事件，3/5 级使用原概率的 40%', () => {
  assert.equal(rules.getMinorEventRateMultiplier({ level: 1, isMinor: true }), 1)
  assert.equal(rules.getMinorEventRateMultiplier({ level: 2, isMinor: true }), 1)
  assert.equal(rules.getMinorEventRateMultiplier({ level: 3, isMinor: true }), 0.4)
  assert.equal(rules.getMinorEventRateMultiplier({ level: 5, isMinor: true }), 0.4)
  assert.equal(rules.getMinorEventRateMultiplier({ level: 2, isMinor: false }), 0)
})

test('未成年发疯概率是普通成员的 1.3 倍', () => {
  assert.equal(rules.getMadnessRateMultiplier({ isMinor: true }), 1.3)
  assert.equal(rules.getMadnessRateMultiplier({ isMinor: false }), 1)
})

test('成年倒计时是 720 至 1080 天的整数且包含边界', () => {
  assert.equal(rules.getAdultTransitionDays(() => 0), 720)
  assert.equal(rules.getAdultTransitionDays(() => 0.999999), 1080)
})

test('学习美术达到 100% 后隐藏进度条', () => {
  assert.equal(rules.shouldShowArtLearningProgress(99.9), true)
  assert.equal(rules.shouldShowArtLearningProgress(100), false)
  assert.equal(rules.shouldShowArtLearningProgress(120), false)
})

test('会员服务采用分区卡片并包含六项悬浮信息', async () => {
  const [panel, legacy] = await Promise.all([
    readFile(new URL('../src/components/ServicesPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
  ])
  assert.doesNotMatch(panel, /购买\/取消不消耗行动点/)
  assert.doesNotMatch(legacy.match(/function renderServices\(\)[\s\S]*?\n\}/)?.[0] ?? '', /｜/)
  for (const description of [
    '允许你主动联系国外的曲师',
    '增加与国外曲师合作的成功率',
    '让你能点外卖吃',
    '让你每个月可能收到玩家赞助',
    '降低学技能消耗的行动点',
    '增加每天的初始行动点',
  ]) assert.match(legacy, new RegExp(description))
  assert.match(legacy, /service-copy/)
  assert.match(legacy, /service-state/)
})

test('文案成员入口、剧情资源和曲包操作已接入界面', async () => {
  const [team, legacy] = await Promise.all([
    readFile(new URL('../src/components/TeamPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
  ])
  assert.match(team, /id="storyWords"/)
  assert.match(team, /id="storyWordCap"/)
  assert.match(team, /id="recruitCopyBtn"/)
  assert.match(legacy, /function copywriterDaily\(\)/)
  assert.match(legacy, /function addStoryToPackage\(pid\)/)
  assert.match(legacy, /function cancelPackageBuilding\(pid\)/)
  assert.match(legacy, /文案成员会自主工作，不需要手动分配任务/)
})

test('行动点与精神使用独立资源条配色', async () => {
  const [panel, styles] = await Promise.all([
    readFile(new URL('../src/components/OperationPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8'),
  ])
  assert.match(panel, /ap-fill/)
  assert.match(panel, /spirit-fill/)
  assert.match(styles, /\.resource-bar \.ap-fill/)
  assert.match(styles, /\.resource-bar \.spirit-fill/)
})

test('开局写文案会消耗 5 点精神且实际调用统一规则', async () => {
  assert.equal(rules.copyWritingSpiritCost(0), 5)
  assert.equal(rules.copyWritingSpiritCost(1), 10)
  assert.equal(rules.copyWritingSpiritCost(20), 60)
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  assert.match(legacy, /spiritCost=GAME_RULES\.copyWritingSpiritCost\(year\(\)\)/)
})

test('协调资源对玩家统一显示为成员管理协调值', async () => {
  const team = await readFile(new URL('../src/components/TeamPanel.vue', import.meta.url), 'utf8')
  assert.match(team, /成员管理协调值/)
  assert.doesNotMatch(team, />协调阈值</)
})

test('制作组资源采用统一排版，剧情字数在首次获得文案前隐藏', async () => {
  const [team, legacy] = await Promise.all([
    readFile(new URL('../src/components/TeamPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
  ])
  assert.equal((team.match(/class="team-metric-line"/g) ?? []).length, 3)
  assert.match(team, /id="storyWordLine"[^>]*style="display: none"/)
  assert.match(legacy, /storyWordLine\.style\.display=state\.hasHadCopywriter\?"":"none"/)
  assert.match(legacy, /hasHadCopywriter:true|hasHadCopywriter:false/)
})

test('候选标签、控制台标题和作品集隐藏规则使用新版文案', async () => {
  const [header, legacy] = await Promise.all([
    readFile(new URL('../src/components/AppHeader.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
  ])
  assert.match(header, />N-CRYOS CONSOLE</)
  assert.doesNotMatch(header, /MANAGEMENT CONSOLE/)
  assert.match(legacy, /candidate-kind">候选/)
  assert.match(legacy, /candidate-kind">申请/)
  assert.match(legacy, /c\.portfolio\.filter\(p=>!p\.bought\)/)
})

test('曲包剧情数量和增加按钮同行且期待系数不向玩家展示', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  const renderer = legacy.match(/function renderPackages\(\)[\s\S]*?\n\}/)?.[0] ?? ''
  assert.match(renderer, /package-story-row/)
  assert.match(renderer, /已分配剧情[\s\S]*增加剧情/)
  assert.doesNotMatch(renderer, /本包期待系数/)
})

test('文案成员个人累计字数、晋级和干劲期限进入存档逻辑', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  assert.match(legacy, /copyWordsWritten:0/)
  assert.match(legacy, /motivatedUntilDay:0/)
  assert.match(legacy, /function promoteCopywriterByWords\(m\)/)
  assert.match(legacy, /function expireCopywriterMotivation\(m\)/)
})

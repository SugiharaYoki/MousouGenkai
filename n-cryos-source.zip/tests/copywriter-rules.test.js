import assert from 'node:assert/strict'
import test from 'node:test'

import * as rules from '../src/game/rules.js'

test('文案招聘在写文案 10 次且成员超过 5 人后解锁', () => {
  assert.equal(rules.canUnlockCopywriterRecruitment(9, 6), false)
  assert.equal(rules.canUnlockCopywriterRecruitment(10, 5), false)
  assert.equal(rules.canUnlockCopywriterRecruitment(10, 6), true)
})

test('新入组的1级文案每天从5至10字起步，经验会提高日产能', () => {
  const beginner = { level: 1, tenureDays: 0, totalWords: 0 }
  const experienced = { level: 1, tenureDays: 720, totalWords: 5000 }
  assert.deepEqual(rules.copywriterDailyWordRange(beginner), [5, 10])
  assert.deepEqual(rules.copywriterDailyWordRange(experienced), [5, 100])
  assert.equal(rules.rollCopywriterDailyWords(beginner, () => 0), 5)
  assert.equal(rules.rollCopywriterDailyWords(beginner, () => 0.999999), 10)
  assert.deepEqual(rules.copywriterDailyWordRange({ level: 5, tenureDays: 720, totalWords: 50000 }), [30, 350])
})

test('文案等级按个人累计字数从1级升到3级', () => {
  assert.equal(rules.promotedCopywriterLevel(1, 4999), 1)
  assert.equal(rules.promotedCopywriterLevel(1, 5000), 2)
  assert.equal(rules.promotedCopywriterLevel(2, 9999), 2)
  assert.equal(rules.promotedCopywriterLevel(2, 10000), 3)
  assert.equal(rules.promotedCopywriterLevel(3, 99999), 3)
})

test('干劲满满按等级提供指定的7天文案产能倍率', () => {
  assert.deepEqual([1, 2, 3, 4, 5].map(rules.copywriterMotivationMultiplier), [1.5, 1.4, 1.3, 1.3, 1.3])
  assert.equal(rules.copywriterRules.motivationDays, 7)
  assert.deepEqual(
    rules.copywriterDailyWordRange({ level: 1, tenureDays: 0, totalWords: 0, motivated: true }),
    [8, 15],
  )
})

test('剧情上限增长符合来源范围且高质量更倾向高值', () => {
  assert.equal(rules.rollStoryCapacityGain('portfolio', 1, () => 0), 200)
  assert.equal(rules.rollStoryCapacityGain('portfolio', 5, () => 0.999999), 800)
  assert.equal(rules.rollStoryCapacityGain('commission', 1, () => 0), 1200)
  assert.equal(rules.rollStoryCapacityGain('commission', 5, () => 0.999999), 2500)
  assert.ok(rules.rollStoryCapacityGain('portfolio', 5, () => 0.5) > rules.rollStoryCapacityGain('portfolio', 1, () => 0.5))
})

test('曲包剧情容量每首 2000 字且最高 20000 字', () => {
  assert.equal(rules.packageStoryCapacity(0), 0)
  assert.equal(rules.packageStoryCapacity(3), 6000)
  assert.equal(rules.packageStoryCapacity(12), 20000)
})

test('剧情上限已在分配时同步扣除，不重复扣除已分配字数', () => {
  assert.equal(rules.remainingStoryWritingCapacity({ cap: 4000, availableWords: 2500, allocatedWords: 1000 }), 1500)
  assert.equal(rules.remainingStoryWritingCapacity({ cap: 4000, availableWords: 4000, allocatedWords: 1000 }), 0)
})

test('疑虑恢复进度工作时增长、再次空闲时每天损失20', () => {
  assert.deepEqual(rules.updateCopywriterDoubtProgress({ current: 480, written: 20, isIdle: false }), { progress: 500, recovered: true })
  assert.deepEqual(rules.updateCopywriterDoubtProgress({ current: 10, written: 0, isIdle: true }), { progress: 0, recovered: false })
})

test('高级文案成员提供概率加成', () => {
  assert.equal(rules.seniorCopywriterCommissionBonus(3), 0.003)
  assert.equal(rules.seniorCopywriterExpediteBonus(3), 0.0045)
  assert.equal(rules.copyActionEventChance(0.2, true), 0.26)
  assert.equal(rules.copyActionEventChance(0.2, false), 0.2)
})

import { createApp } from 'vue'
import 'virtual:uno.css'
import './styles/legacy.css'
import './styles/mobile.css'
import App from './App.vue'
import composers from './data/composers.json'
import portfolios from './data/portfolios.json'
import legacySource from './game/legacy.js?raw'
import * as gameplayRules from './game/rules.js'

window.__NCRYOS_DATA__ = { composers, portfolios }
window.__NCRYOS_RULES__ = gameplayRules

createApp(App).mount('#app')

// The established simulation engine stays a classic script so its public
// handlers remain compatible with dynamically rendered legacy controls.
const legacyScript = document.createElement('script')
legacyScript.dataset.ncryosEngine = 'true'
legacyScript.textContent = legacySource
document.body.appendChild(legacyScript)

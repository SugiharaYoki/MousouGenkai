<script setup>
import DesignConceptPanel from './components/DesignConceptPanel.vue'
import AppHeader from './components/AppHeader.vue'
import OperationPanel from './components/OperationPanel.vue'
import ServicesPanel from './components/ServicesPanel.vue'
import TeamPanel from './components/TeamPanel.vue'
import EconomyPanel from './components/EconomyPanel.vue'
import InfoPanel from './components/InfoPanel.vue'
import ContentPanel from './components/ContentPanel.vue'
import DebugPanel from './components/DebugPanel.vue'
import EventPanel from './components/EventPanel.vue'
import { useLegacyActions } from './composables/useLegacyActions'

const { invoke } = useLegacyActions()
</script>

<template>
  <button
    id="deviceSwitchButton"
    class="device-switch-button touch-control"
    type="button"
    title="切换电脑端/手机端显示"
    aria-label="切换电脑端、手机端或自动显示模式"
    @click="invoke('toggleDeviceMode')"
  >
    ↔
  </button>

  <div class="mobile-rotate-shell">
    <main class="app">
      <DesignConceptPanel />
      <AppHeader />

      <div class="layout">
        <div class="col left-column">
          <OperationPanel />
          <ServicesPanel />
          <TeamPanel />
          <EconomyPanel />
        </div>

        <div class="col center-column">
          <InfoPanel />
          <ContentPanel />
          <DebugPanel />
        </div>

        <EventPanel />
      </div>
    </main>
  </div>
</template>

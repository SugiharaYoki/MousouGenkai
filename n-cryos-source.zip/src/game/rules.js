export const hiddenMemberRules = Object.freeze({
  minorRecruitChanceByLevel: Object.freeze({
    1: 0.8,
    2: 0.6,
    3: 0.4,
    4: 0,
    5: 0.5,
  }),
  adulthoodTransitionMinDays: 720,
  adulthoodTransitionMaxDays: 1080,
  potentialInsiderChance: 0.03,
  minorPotentialInsiderChance: 0.06,
  potentialInsiderMaturityDays: 180,
  protectedRarity: 3,
})

export const betaLeakRules = Object.freeze({
  baseDailyChance: 0.0012,
  perLeakerDailyChance: 0.001,
  sideAndSingleMultiplier: 3,
  cooldownDays: 30,
  discussionBuffMultiplier: 1.2,
  discussionBuffDays: 30,
  releaseDiscussionMultiplier: 0.8,
  nextBetaDelayMin: 1,
  nextBetaDelayMax: 3,
})

export const lewdImageRules = Object.freeze({
  alternateCopyChance: 0.5,
})

export const FIRE_MEMBER_ACTION_COST = 3

export function copyWritingSpiritCost(yearIndex) {
  return Math.min(60, 5 * (Math.max(0, Math.floor(Number(yearIndex) || 0)) + 1))
}

export const copywriterRules = Object.freeze({
  unlockCopyActions: 10,
  unlockMemberCountExclusive: 5,
  initialStoryWordCap: 5000,
  doubtIdleDaysMultiplier: 3,
  doubtRecoveryWords: 500,
  doubtIdleProgressLoss: 20,
  promotionWordsByLevel: Object.freeze({ 1: 5000, 2: 10000 }),
  motivationDays: 7,
  motivationMultiplierByLevel: Object.freeze({ 1: 1.5, 2: 1.4, 3: 1.3, 4: 1.3, 5: 1.3 }),
  fullTenureGrowthDays: 720,
  packageStoryStep: 1000,
  packageStoryPerSong: 2000,
  packageStoryMax: 20000,
  packageExpectationMultiplier: 0.98,
  seniorEventChanceMultiplier: 1.3,
  seniorEventPreferredChance: 0.8,
  seniorCommissionBonus: 0.001,
  seniorExpediteBonus: 0.0015,
})

export function canUnlockCopywriterRecruitment(copyActionCount, memberCount) {
  return Number(copyActionCount) >= copywriterRules.unlockCopyActions
    && Number(memberCount) > copywriterRules.unlockMemberCountExclusive
}

export function copywriterMotivationMultiplier(level) {
  const normalizedLevel = Math.min(5, Math.max(1, Math.round(Number(level) || 1)))
  return copywriterRules.motivationMultiplierByLevel[normalizedLevel]
}

export function copywriterDailyWordRange(input) {
  const options = typeof input === 'object' && input !== null ? input : { level: input }
  const level = Math.min(5, Math.max(1, Math.round(Number(options.level) || 1)))
  const tenureDays = Math.max(0, Number(options.tenureDays) || 0)
  const totalWords = Math.max(0, Number(options.totalWords) || 0)
  const matureMin = Math.round(5 + (30 - 5) * ((level - 1) / 4))
  const matureMax = Math.round(100 + (350 - 100) * ((level - 1) / 4))
  const noviceMax = [0, 10, 40, 80, 120, 160][level]
  const wordTarget = [0, 5000, 10000, 20000, 35000, 50000][level]
  const tenureGrowth = Math.min(1, tenureDays / copywriterRules.fullTenureGrowthDays)
  const writingGrowth = Math.min(1, totalWords / wordTarget)
  const experience = Math.min(1, tenureGrowth * 0.35 + writingGrowth * 0.65)
  const multiplier = options.motivated ? copywriterMotivationMultiplier(level) : 1
  return [
    Math.max(1, Math.round(matureMin * multiplier)),
    Math.max(1, Math.round((noviceMax + (matureMax - noviceMax) * experience) * multiplier)),
  ]
}

export function rollCopywriterDailyWords(input, random = Math.random) {
  const [min, max] = copywriterDailyWordRange(input)
  return randomIntegerInclusive(min, max, random)
}

export function promotedCopywriterLevel(level, totalWords) {
  const normalizedLevel = Math.min(5, Math.max(1, Math.round(Number(level) || 1)))
  const threshold = copywriterRules.promotionWordsByLevel[normalizedLevel]
  return threshold !== undefined && Number(totalWords) >= threshold ? normalizedLevel + 1 : normalizedLevel
}

export function rollStoryCapacityGain(source, quality, random = Math.random) {
  const range = source === 'portfolio'
    ? [200, 800]
    : source === 'commission'
      ? [1200, 2500]
      : null
  if (!range) return 0
  const normalizedQuality = (Math.min(5, Math.max(1, Number(quality) || 1)) - 1) / 4
  const rawRoll = Math.min(0.999999999999, Math.max(0, Number(random()) || 0))
  const qualityBiasedRoll = Math.pow(rawRoll, 1.6 - normalizedQuality * 1.2)
  return Math.floor(qualityBiasedRoll * (range[1] - range[0] + 1)) + range[0]
}

export function packageStoryCapacity(songCount) {
  return Math.min(
    copywriterRules.packageStoryMax,
    Math.max(0, Math.floor(Number(songCount) || 0)) * copywriterRules.packageStoryPerSong,
  )
}

export function remainingStoryWritingCapacity({ cap, availableWords, allocatedWords }) {
  return Math.max(0, (Number(cap) || 0) - (Number(availableWords) || 0) - (Number(allocatedWords) || 0))
}

export function updateCopywriterDoubtProgress({ current, written, isIdle }) {
  const progress = isIdle
    ? Math.max(0, (Number(current) || 0) - copywriterRules.doubtIdleProgressLoss)
    : Math.min(copywriterRules.doubtRecoveryWords, (Number(current) || 0) + Math.max(0, Number(written) || 0))
  return { progress, recovered: progress >= copywriterRules.doubtRecoveryWords }
}

export function seniorCopywriterCommissionBonus(count) {
  return Math.round(Math.max(0, Number(count) || 0) * copywriterRules.seniorCommissionBonus * 1_000_000) / 1_000_000
}

export function seniorCopywriterExpediteBonus(count) {
  return Math.round(Math.max(0, Number(count) || 0) * copywriterRules.seniorExpediteBonus * 1_000_000) / 1_000_000
}

export function copyActionEventChance(baseChance, hasSeniorCopywriter) {
  return Math.min(1, Math.max(0, Number(baseChance) || 0) * (hasSeniorCopywriter ? copywriterRules.seniorEventChanceMultiplier : 1))
}

export function getMinorRecruitChance(level) {
  return hiddenMemberRules.minorRecruitChanceByLevel[Number(level)] ?? 0
}

export function memberStartsAsMinor(level, random = Math.random) {
  return random() < getMinorRecruitChance(level)
}

export function getAdultTransitionDays(random = Math.random) {
  return randomIntegerInclusive(
    hiddenMemberRules.adulthoodTransitionMinDays,
    hiddenMemberRules.adulthoodTransitionMaxDays,
    random,
  )
}

export function getMinorEventRateMultiplier({ level, isMinor }) {
  if (!isMinor) return 0
  return Number(level) === 3 || Number(level) === 5 ? 0.4 : 1
}

export function getMadnessRateMultiplier({ isMinor }) {
  return isMinor ? 1.3 : 1
}

export function shouldShowArtLearningProgress(progress) {
  return Number(progress) < 100
}

export function shouldBecomePotentialInsider({ rarity, isMinor, random = Math.random }) {
  if (Number(rarity) === hiddenMemberRules.protectedRarity) return false
  const probability = isMinor
    ? hiddenMemberRules.minorPotentialInsiderChance
    : hiddenMemberRules.potentialInsiderChance
  return random() < probability
}

export function betaLeakChance(packageType, activeLeakerCount) {
  const base = betaLeakRules.baseDailyChance
    + betaLeakRules.perLeakerDailyChance * Math.max(0, Number(activeLeakerCount) || 0)
  const multiplier = packageType === '支线包' || packageType === '单曲'
    ? betaLeakRules.sideAndSingleMultiplier
    : 1
  return Math.min(1, base * multiplier)
}

export function randomIntegerInclusive(min, max, random = Math.random) {
  const low = Math.ceil(min)
  const high = Math.floor(max)
  const roll = Math.min(0.999999999999, Math.max(0, Number(random()) || 0))
  return Math.floor(roll * (high - low + 1)) + low
}

export function absoluteGameDay(yearIndex, month, day) {
  return Number(yearIndex) * 365 + (Number(month) - 1) * 30 + Number(day)
}

<template>
  <section class="panel mobile-services">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">SUBSCRIPTIONS</p>
        <h2 class="section-heading">会员服务</h2>
      </div>
      <span class="panel-index">02</span>
    </div>
    <div id="services" class="service-grid"></div>
  </section>
</template>

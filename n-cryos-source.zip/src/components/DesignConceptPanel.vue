<script setup>
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke } = useLegacyActions()
</script>

<template>
  <section id="designConceptPanel" class="panel design-concept-panel">
    <div class="between">
      <div>
        <p class="eyebrow">PROJECT BRIEF</p>
        <h2 class="section-heading">游戏设计理念</h2>
        <div class="sub">完成全部问题后才能开始核心制作、招募成员或主动约曲。确定后不可修改。</div>
      </div>
    </div>

    <div class="design-question-grid">
      <label class="design-question">
        <b>一、你打算做什么样的音乐游戏？</b>
        <select id="designStyleSelect" class="touch-control">
          <option value="传统" selected>传统</option>
          <option value="创新">创新</option>
          <option value="缝合">缝合</option>
        </select>
      </label>
      <label class="design-question">
        <b>二、你打算上线电脑端吗？</b>
        <select id="designPCSelect" class="touch-control">
          <option value="否" selected>否</option>
          <option value="是">是</option>
        </select>
      </label>
      <label class="design-question design-question-name">
        <b>三、你将为游戏起什么名字？</b>
        <input
          id="designGameNameInput"
          class="touch-control"
          type="text"
          maxlength="40"
          placeholder="请输入游戏名称"
        />
      </label>
    </div>
    <div class="design-confirm-row">
      <button class="primary touch-control" type="button" @click="invoke('confirmDesignConcept')">确定企划</button>
    </div>
  </section>
</template>

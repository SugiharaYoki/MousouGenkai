<script setup>
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke } = useLegacyActions()
</script>

<template>
  <section class="panel mobile-debug">
    <div class="between">
      <h2 class="section-heading">测试数值（隐藏信息）</h2>
      <button class="touch-control" type="button" @click="invoke('toggleDebug')">展开 / 收起</button>
    </div>
    <div id="debugPanel" class="hidden-test">
      <div class="cards metric-grid">
        <div class="card"><div class="k">期待值</div><div id="expectation" class="v"></div></div>
        <div class="card"><div class="k">玩家粘性</div><div id="stickiness" class="v"></div></div>
        <div class="card"><div class="k">下次更新 Bug 概率</div><div id="bugChance" class="v"></div></div>
        <div class="card"><div class="k">程序水平（隐藏）</div><div id="tech" class="v"></div></div>
      </div>
      <div id="debugMore" class="sub"></div>
      <div id="composerDebug" class="debug-composers"></div>
    </div>
  </section>
</template>

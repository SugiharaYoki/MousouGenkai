<script setup>
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke, valueOf } = useLegacyActions()

const importSave = (event) => {
  invoke('importSaveTxt', event.target.files?.[0])
  event.target.value = ''
}
</script>

<template>
  <section class="panel mobile-operation">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">DAILY LOOP</p>
        <h2 class="section-heading">操作面板</h2>
      </div>
      <span class="panel-index">01</span>
    </div>

    <div class="two">
      <div class="card">
        <div class="k">主业</div>
        <div id="jobName" class="v job-value"></div>
      </div>
      <div class="card money-card">
        <div class="k">存款</div>
        <div id="money" class="v"></div>
        <button class="money-sidegig touch-control" type="button" @click="invoke('sideGig')">
          <b>赚外快</b><span id="sideGigCostHint">8行动点 / +40疲劳</span>
        </button>
      </div>
    </div>

    <div class="row job-row">
      <select id="jobSelect" class="touch-control" @change="invoke('setJob', valueOf($event))">
        <option value="home">家里蹲</option>
        <option value="easy">简单</option>
        <option value="normal">普通</option>
        <option value="hard">困难</option>
      </select>
      <span id="jobLockText" class="sub"></span>
    </div>

    <div class="barbox resource-bar ap-resource">
      <div class="barhead"><b>行动点</b><span id="apText"></span></div>
      <div class="bar resource-track"><div id="apBar" class="fill ap-fill"></div></div>
    </div>
    <div class="barbox resource-bar spirit-resource">
      <div class="barhead"><b>精神</b><span id="fatigueText"></span></div>
      <div class="bar resource-track"><div id="fatigueBar" class="fill spirit-fill"></div></div>
    </div>
    <div id="fatigueWarning">⚠ 精神过低：当前精神低于100，部分行动可能触发疲劳效果。</div>
    <div id="developmentBars"></div>
    <div id="doubleCostText" class="statusline"></div>

    <div class="action-grid">
      <button id="writeCopyBtn" class="action work-orange touch-control" type="button" @click="invoke('writeCopy')">
        <b id="writeCopyLabel">写文案</b><span id="writeCopyCostHint">2行动点 / +5疲劳</span>
      </button>
      <button
        id="derivativeAnnouncementBtn"
        class="action work-orange touch-control"
        type="button"
        style="display: none"
        @click="invoke('publishDerivativeAnnouncement')"
      >
        <b>发公告·带衍生图</b><span>2行动点 / +5疲劳</span>
      </button>
      <button id="writeProgramBtn" class="action work-orange touch-control" type="button" @click="invoke('writeProgram')">
        <b>写程序</b><span id="programCostHint"></span>
      </button>
      <button id="studyProgramBtn" class="action learn-purple touch-control" type="button" @click="invoke('studyProgram')">
        <b>学程序</b><span id="studyProgramCostHint">5行动点 / +30疲劳</span>
      </button>
      <button id="studyArtBtn" class="action learn-purple touch-control" type="button" @click="invoke('studyArt')">
        <b>学美术</b><span id="studyArtCostHint">10行动点 / +50疲劳</span>
      </button>
      <button
        id="createDerivativeBtn"
        class="action learn-purple touch-control"
        type="button"
        style="display: none"
        @click="invoke('createDerivative')"
      >
        <b>创作衍生图</b><span>8行动点 / -30精神</span>
      </button>
      <button class="action stress-down touch-control" type="button" @click="invoke('playRhythm')">
        <b>打音游</b><span id="rhythmCostHint">2行动点 / -40疲劳</span>
      </button>
      <button id="takeoutBtn" class="action stress-down touch-control" type="button" @click="invoke('takeout')">
        <b>点外卖</b><span id="takeoutCostHint">1行动点 / -25疲劳</span>
      </button>
    </div>

    <button class="big touch-control" type="button" @click="invoke('endDay')">结束今天</button>

    <div class="save-card">
      <div class="between"><b>存档</b><span id="saveStatus" class="sub">未检测到存档</span></div>
      <div class="row save-actions">
        <button class="good touch-control" type="button" @click="invoke('saveGame')">保存存档</button>
        <button class="touch-control" type="button" @click="invoke('loadGame')">读取存档</button>
        <button class="bad touch-control" type="button" @click="invoke('deleteSave')">删除存档</button>
        <button class="portable-save-icon touch-control" type="button" title="导出加密存档" aria-label="导出加密存档" @click="invoke('exportSaveTxt')">↥</button>
        <button class="portable-save-icon touch-control" type="button" title="导入加密存档" aria-label="导入加密存档" @click="document.getElementById('importSaveFile').click()">↧</button>
        <input id="importSaveFile" type="file" accept=".txt,text/plain" hidden @change="importSave" />
      </div>
      <div class="sub">存档保存在当前浏览器中，也可以导出为加密文本。</div>
    </div>
  </section>
</template>

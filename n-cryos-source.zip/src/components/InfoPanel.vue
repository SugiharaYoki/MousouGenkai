<template>
  <section class="panel mobile-info">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">LIVE METRICS</p>
        <h2 class="section-heading">信息视窗</h2>
      </div>
      <span class="panel-index">05</span>
    </div>
    <div class="cards metric-grid">
      <div class="card"><div class="k">关注人数</div><div id="fans" class="v"></div></div>
      <div class="card"><div class="k">社区讨论度</div><div id="discussion" class="v"></div></div>
      <div class="card"><div class="k">游玩人数</div><div id="players" class="v"></div></div>
      <div class="card"><div class="k">游戏好评度</div><div id="rating" class="v"></div></div>
    </div>
    <div class="two secondary-metrics">
      <div class="card"><div class="k">艺术追求</div><div id="artPursuit" class="v"></div><div id="styleBuff" class="sub"></div></div>
      <div class="card"><div class="k">本月赞助</div><div id="sponsor" class="v"></div><div id="sponsorInfo" class="sub"></div></div>
    </div>
  </section>
</template>

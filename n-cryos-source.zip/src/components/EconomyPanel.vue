<template>
  <section class="panel mobile-economy">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">CASHFLOW</p>
        <h2 class="section-heading">经济状态</h2>
      </div>
      <span class="panel-index">04</span>
    </div>
    <div id="economyText"></div>
    <div class="sub project-meta">
      最后更新日期：2026年08月25日 12:13:58<br />
      反馈与提议：邮箱 yukidare2766@gmail.com
    </div>
  </section>
</template>

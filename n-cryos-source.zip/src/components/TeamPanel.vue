<script setup>
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke, valueOf } = useLegacyActions()
</script>

<template>
  <section class="panel mobile-team">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">PRODUCTION CREW</p>
        <h2 class="section-heading">制作组</h2>
      </div>
      <div class="team-heading-actions">
        <details class="team-help">
          <summary aria-label="查看制作组成员等级说明">?</summary>
          <div class="team-help-copy" role="tooltip">
            <p>1/2/3级成员随等级降低占用的成员管理协调值，且增加工作效率与质量。</p>
            <p>4级成员是社区著名的顶尖大佬，被特殊事务占用的概率下降，但是管理时占用更多成员管理协调值。他们更有自己的想法，可能会做出一些你管控之外的事情。</p>
            <p>5级成员可遇不可求，是最宝贵的人力资源。但他们往往只专精自己擅长的工作，对其他琐碎的杂活并不拿手。</p>
            <p>善用人才，积累一定数量的3/4/5级成员，或许才能构成最健康的制作组！</p>
          </div>
        </details>
        <span class="panel-index">03</span>
      </div>
    </div>
    <div class="between team-summary">
      <div class="team-metrics">
        <div class="team-metric-line"><span>成员管理协调值</span><b><span id="coord"></span> / <span id="coordCapDisplay"></span></b></div>
        <div id="storyWordLine" class="team-metric-line" style="display: none"><span>可分配剧情字数</span><b><span id="storyWords">0</span> / <span id="storyWordCap">5,000</span></b></div>
        <div id="derivativeCountLine" class="team-metric-line" style="display: none"><span>可用衍生图数量</span><b id="derivativeCount"></b></div>
      </div>
      <span id="teamCapText" class="sub"></span>
    </div>
    <div class="row sort-row">
      <span class="sub">成员排序</span>
      <select id="memberSortSelect" class="touch-control" @change="invoke('setMemberSortMode', valueOf($event))">
        <option value="acquired" selected>获取顺序</option>
        <option value="level">等级</option>
      </select>
    </div>
    <div id="recruitTools" class="recruit-tools">
      <button id="recruitChartBtn" class="recruit-btn touch-control" type="button" @click="invoke('searchMember', 'chart')">
        <span class="recruit-icon">谱</span>
        <span class="recruit-copy"><b>寻找谱师</b><span id="recruitChartCostHint">1 行动点</span></span>
      </button>
      <button id="recruitArtBtn" class="recruit-btn touch-control" type="button" @click="invoke('searchMember', 'art')">
        <span class="recruit-icon">画</span>
        <span class="recruit-copy"><b>寻找美术</b><span id="recruitArtCostHint">1 行动点</span></span>
      </button>
      <button id="recruitCopyBtn" class="recruit-btn touch-control" type="button" style="display: none" @click="invoke('searchMember', 'copy')">
        <span class="recruit-icon">文</span>
        <span class="recruit-copy"><b>寻找文案</b><span id="recruitCopyCostHint">1 行动点</span></span>
      </button>
    </div>
    <div id="candidateBox"></div>
    <div id="members" class="list"></div>

    <dialog id="fireMemberDialog" class="confirm-dialog" @cancel.prevent="invoke('closeFireMemberDialog')">
      <p class="eyebrow">MEMBER MANAGEMENT</p>
      <h3>开除成员</h3>
      <p id="fireMemberConfirmText" class="confirm-dialog-copy"></p>
      <div class="confirm-dialog-actions">
        <button class="bad touch-control" type="button" @click="invoke('confirmFireMember')">狠心开除</button>
        <button class="touch-control" type="button" @click="invoke('closeFireMemberDialog')">点错了</button>
      </div>
    </dialog>
  </section>
</template>

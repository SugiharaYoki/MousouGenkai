export function useLegacyActions() {
  const invoke = (name, ...args) => {
    const handler = window[name]
    if (typeof handler !== 'function') {
      console.warn(`游戏逻辑尚未就绪：${name}`)
      return undefined
    }
    return handler(...args)
  }

  const valueOf = (event) => event.currentTarget?.value ?? event.target?.value

  return { invoke, valueOf }
}

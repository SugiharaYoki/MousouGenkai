import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import {
  memberAffectionLabel,
  memberDoubtDepartureDays,
  memberRecoveryChanceBonus,
  memberShouldConfessLeak,
  memberSongQualityAffectionGain,
  memberWorkPlayableBonus,
  nextMemberAffection,
  takeoutSpiritRecovery,
} from '../src/game/rules.js'

test('管理曲库在电脑和手机端都使用加长的专用窗口', async () => {
  const [legacyCss, mobileCss] = await Promise.all([
    readFile(new URL('../src/styles/legacy.css', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8'),
  ])
  assert.match(legacyCss, /#libraryView \.list\s*\{\s*height:\s*650px;max-height:\s*650px/)
  assert.match(mobileCss, /html\.mobile-ui #libraryView \.list\s*\{[\s\S]*?height:\s*clamp\(360px,\s*65dvh,\s*620px\)\s*!important;[\s\S]*?max-height:\s*clamp\(360px,\s*65dvh,\s*620px\)\s*!important/)
})

test('成员好感显示只暴露关系阶段', () => {
  assert.equal(memberAffectionLabel(19.9), '陌生')
  assert.equal(memberAffectionLabel(20), '普通')
  assert.equal(memberAffectionLabel(50), '朋友')
  assert.equal(memberAffectionLabel(80), '信任')
})

test('自然衰减具有80点信任保护，其他负面变化会打破保护', () => {
  assert.deepEqual(
    nextMemberAffection({ affection: 80.4, trustLocked: true }, -1, { natural: true }),
    { affection: 80, trustLocked: true },
  )
  assert.deepEqual(
    nextMemberAffection({ affection: 80, trustLocked: true }, -0.2),
    { affection: 79.8, trustLocked: false },
  )
  assert.deepEqual(
    nextMemberAffection({ affection: 99.5, trustLocked: false }, 2),
    { affection: 100, trustLocked: true },
  )
})

test('好感影响疑虑退组、找回与成员负责工作的可玩质量', () => {
  assert.equal(memberDoubtDepartureDays(50), 15)
  assert.equal(memberDoubtDepartureDays(50.1), 45)
  assert.equal(memberRecoveryChanceBonus(39.9), 0)
  assert.equal(memberRecoveryChanceBonus(40), 0.01)
  assert.equal(memberRecoveryChanceBonus(100), 0.07)
  assert.equal(memberWorkPlayableBonus(52.9), 0)
  assert.equal(memberWorkPlayableBonus(53), 0.1)
  assert.equal(memberWorkPlayableBonus(80), 1)
})

test('完成高质量歌曲按4/5/6级分别增加1/2/2.5好感', () => {
  assert.equal(memberSongQualityAffectionGain(3), 0)
  assert.equal(memberSongQualityAffectionGain(4), 1)
  assert.equal(memberSongQualityAffectionGain(5), 2)
  assert.equal(memberSongQualityAffectionGain(6), 2.5)
})

test('国潮外卖少恢复5点精神', () => {
  assert.equal(takeoutSpiritRecovery(false), 25)
  assert.equal(takeoutSpiritRecovery(true), 20)
})

test('泄密者仅在好感超过80且尚未坦白时触发坦白', () => {
  assert.equal(memberShouldConfessLeak({ affection: 80, leaker: true }), false)
  assert.equal(memberShouldConfessLeak({ affection: 80.01, leaker: true }), true)
  assert.equal(memberShouldConfessLeak({ affection: 100, leaker: false }), false)
  assert.equal(memberShouldConfessLeak({ affection: 100, leaker: true, confessedLeak: true }), false)
})

test('招聘不再消耗精神，所有玩家可见消耗统一写成精神', async () => {
  const [legacy, team, operation] = await Promise.all([
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/TeamPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/OperationPanel.vue', import.meta.url), 'utf8'),
  ])
  const searchBody = legacy.match(/function searchMember\(role\)\{([\s\S]*?)\n\}/)?.[1] ?? ''
  assert.doesNotMatch(searchBody, /state\.fatigue\s*\+=/)
  assert.match(team, /id="recruitChartCostHint">1 行动点<\/span>/)
  assert.match(team, /id="recruitArtCostHint">1 行动点<\/span>/)
  assert.match(team, /id="recruitCopyCostHint">1 行动点<\/span>/)
  assert.doesNotMatch(`${legacy}\n${team}\n${operation}`, /[+-](?:\$\{[^}]+\}|\d+(?:\.\d+)?)疲劳/)
  assert.match(operation, /短期零工/)
  assert.match(operation, /中期工作/)
  assert.match(operation, /长期合同/)
  assert.match(operation, /当前精神低于100，部分行动可能受到影响。/)
})

test('关键成员好感事件已经接入游戏循环', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  assert.match(legacy, /吃到国潮外卖了，心情很差。/)
  assert.match(legacy, /打音游的时候在多人模式匹配到了同制作组的\$\{m\.name\}/)
  assert.match(legacy, /memberAffectionDaily\(\)/)
  assert.match(legacy, /applyRandomMemberAffection\([^\n]*m=>m\.affection<80[^\n]*3,-3/)
  assert.match(legacy, /applyRandomMemberAffection\([^\n]*m=>m\.affection<50[^\n]*3,-1/)
  assert.match(legacy, /fulfillMemberSongWishes\(s\)/)
  assert.match(legacy, /他曾经泄露过《\$\{state\.gameName\|\|"未命名游戏"\}》的更新内容/)
  assert.match(legacy, /let hasLeakHistory=!!\(m\.leaker\|\|m\.confessedLeak\)/)
})

test('游戏内版本号与最后更新日期已同步', async () => {
  const [index, header, economy, legacy] = await Promise.all([
    readFile(new URL('../index.html', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/AppHeader.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/EconomyPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
  ])
  assert.match(index, /Beta 56/)
  assert.match(header, /Beta 56/)
  assert.match(economy, /最后更新日期：2026年08月26日/)
  assert.match(legacy, /version:"Beta56"/)
  assert.doesNotMatch(`${index}\n${header}\n${legacy}`, /Beta ?4[3-9]/)
})

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import {
  LEVEL5_COPY_REAL_NAMES,
  applyStoryAllocation,
  expectationReleaseOutcome,
  isGuaranteedAdultMember,
  refundStoryAllocation,
  rollCollabOffer,
} from '../src/game/rules.js'

test('手机端事件记录使用独立全宽页，不再挤压主内容', async () => {
  const [app, legacyCss, mobileCss] = await Promise.all([
    readFile(new URL('../src/App.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/legacy.css', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8'),
  ])

  assert.match(app, /mobilePage === 'events'/)
  assert.match(app, /openMobilePage\('events'\)/)
  assert.match(mobileCss, /data-mobile-page='events'.*\.event-col/)
  assert.match(mobileCss, /html\.mobile-ui \.event-col\s*\{[\s\S]*?position:\s*static\s*!important;[\s\S]*?width:\s*100%\s*!important;/)
  assert.doesNotMatch(legacyCss, /html\.mobile-ui \.event-col\s*\{[\s\S]*?position:fixed!important/)
  assert.match(mobileCss, /\.mobile-navigation\s*\{[\s\S]*?position:\s*fixed;[\s\S]*?bottom:\s*0;/)
})

test('手动或自动设备模式即时切换响应式布局', async () => {
  const [index, legacy] = await Promise.all([
    readFile(new URL('../index.html', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
  ])
  assert.match(index, /classList\.toggle\('mobile-ui', mobile\)/)
  assert.match(index, /window\.innerWidth <= 900/)
  assert.match(legacy, /\(window\.innerWidth\|\|9999\)<=900/)
  assert.match(legacy, /function detectMobileDevice\(\)/)
  assert.match(legacy, /document\.documentElement\.classList\.toggle\("mobile-ui",mobile\)/)
  assert.match(legacy, /function startNewGame\(\)[\s\S]*?location\.reload\(\)/)
  assert.doesNotMatch(legacy, /buildMobileLayout/)
  assert.doesNotMatch(legacy, /\.onclick\s*=\s*toggleDeviceMode/)
})

test('5级文案真人彩蛋与普通候选等权且必定成人', () => {
  assert.deepEqual(LEVEL5_COPY_REAL_NAMES, ['杂合子', 'Kozak'])
  assert.equal(isGuaranteedAdultMember({ name: '杂合子', role: 'copy', rarity: 5 }), true)
  assert.equal(isGuaranteedAdultMember({ name: 'Kozak', role: 'copy', rarity: 5 }), true)
  assert.equal(isGuaranteedAdultMember({ name: '杂合子', role: 'copy', rarity: 4 }), false)
})

test('高质量更新提高期待，未达期待时触发负面倍率', () => {
  const outstanding = expectationReleaseOutcome({ actual: 140, expected: 100 })
  assert.equal(outstanding.tier, 'outstanding')
  assert.equal(outstanding.expectationMultiplier, 1.05)

  const severeMiss = expectationReleaseOutcome({ actual: 40, expected: 100 })
  assert.equal(severeMiss.tier, 'severe-miss')
  assert.deepEqual(severeMiss.releaseMultipliers, {
    attention: 0.7,
    play: 0.65,
    good: 0.7,
    discussion: 1.5,
  })

  assert.equal(expectationReleaseOutcome({ actual: 70, expected: 50 }).tier, 'outstanding')
  assert.equal(expectationReleaseOutcome({ actual: 70, expected: 100 }).tier, 'miss')
})

test('剧情分配同时扣减可用字数和上限，取消时成对归还', () => {
  assert.deepEqual(
    applyStoryAllocation({ availableWords: 4000, wordCap: 5000 }, 1000),
    { availableWords: 3000, wordCap: 4000 },
  )
  assert.deepEqual(
    applyStoryAllocation({ availableWords: 1000, wordCap: 500 }, 1000),
    { availableWords: 0, wordCap: 0 },
  )
  assert.deepEqual(
    refundStoryAllocation({ availableWords: 3000, wordCap: 4000 }, 1000),
    { availableWords: 4000, wordCap: 5000 },
  )
})

test('联动池生成并保存对方名称、歌曲数和强制截止日', () => {
  const common = rollCollabOffer(800, () => 0)
  assert.equal(common.tier, 'common')
  assert.equal(common.gameName, 'Arcade')
  assert.equal(common.songCount, 2)
  assert.equal(common.forcedDeadline, 980)

  const rare = rollCollabOffer(800, () => 0.999999)
  assert.equal(rare.tier, 'rare')
  assert.equal(rare.gameName, '极限DJ')
  assert.equal(rare.songCount, 5)
  assert.equal(rare.forcedDeadline, 1340)
})

test('文案解锁后三个招聘按钮使用同一行', async () => {
  const [team, styles, legacy] = await Promise.all([
    readFile(new URL('../src/components/TeamPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/mobile.css', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
  ])
  assert.match(team, /id="recruitTools"/)
  assert.match(styles, /\.recruit-tools\.copy-unlocked\s*\{[\s\S]*?repeat\(3,/)
  assert.match(legacy, /recruitTools\.classList\.toggle\("copy-unlocked",state\.copyRecruitUnlocked\)/)
})

test('联动邀请与确认界面展示实际需求但不展示惩罚', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  assert.match(legacy, /向我们的游戏发送了联动邀请！他们提议授权我们.*首歌曲/)
  assert.match(legacy, /要求在第.*天前上线.*首歌曲/)
  assert.doesNotMatch(legacy, /renderCollabs[\s\S]*?惩罚/)
})

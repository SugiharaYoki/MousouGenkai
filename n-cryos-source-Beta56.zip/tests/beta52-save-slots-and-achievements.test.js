import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import { ACHIEVEMENTS } from '../src/game/achievements.js'
import { SAVE_SLOT_IDS, SAVE_SLOT_KEYS } from '../src/game/save-slots.js'

const indexOf = id => ACHIEVEMENTS.findIndex(item => item.id === id)

test('Beta52提供自动存档与A/B/C三个独立手动槽', () => {
  assert.deepEqual(SAVE_SLOT_IDS, ['auto', 'manualA', 'manualB', 'manualC'])
  assert.equal(SAVE_SLOT_KEYS.manualA, 'noncommercial_music_game_simulator_manual_save_v1')
  assert.notEqual(SAVE_SLOT_KEYS.manualB, SAVE_SLOT_KEYS.manualC)
})

test('五个新成就按需求排序并保留隐藏属性', () => {
  assert.equal(indexOf('chart_collaboration'), indexOf('member_level_up') + 1)
  assert.equal(indexOf('collab_accept'), indexOf('chart_collaboration') + 1)
  assert.equal(indexOf('job_change'), indexOf('trendy_takeout') + 1)
  assert.equal(indexOf('ap_over_42'), indexOf('job_change') + 1)
  assert.equal(indexOf('bad_popularity'), indexOf('announced_review_delay') + 1)
  assert.equal(ACHIEVEMENTS[indexOf('bad_popularity')].hidden, true)
})

test('三槽界面、详细元数据、布局及提示文案均已接入', async () => {
  const [operation, eventPanel, legacy, css] = await Promise.all([
    readFile(new URL('../src/components/OperationPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/EventPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/legacy.css', import.meta.url), 'utf8'),
  ])
  assert.match(operation, /\['A', 'B', 'C'\]/)
  assert.match(operation, /invoke\('saveGame', `manual\$\{slot\}`\)/)
  assert.match(operation, /invoke\('loadSaveSlot', `manual\$\{slot\}`\)/)
  assert.match(operation, /openImportSave\(`manual\$\{slot\}`\)/)
  assert.match(operation, /invoke\('exportSaveSlot', `manual\$\{slot\}`\)/)
  assert.match(operation, /结束今日后自动存档。/)
  assert.match(operation, /保留成就列表/)
  assert.match(legacy, /余额 \$\{money\}｜成员 \$\{members\}｜曲库 \$\{songs\} 首/)
  assert.match(legacy, /存档也支持导出与导入哟！/)
  assert.match(eventPanel, /event-panel[\s\S]*achievement-trigger[\s\S]*event-resource[\s\S]*event-live-row/)
  assert.match(css, /\.event-panel>\.achievement-trigger\{position:absolute;top:12px;right:12px/)
})

test('谱师并行限制与四类新成就触发已接入引擎', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  assert.match(legacy, /m\.rarity<=2&&assignedChartMembers\.some\(member=>member\.rarity<=2\)/)
  assert.match(legacy, /m\.rarity===3&&assignedChartMembers\.filter\(member=>member\.rarity===3\)\.length>=3/)
  assert.match(legacy, /s\.chartMemberIds\.length>=2\)unlockAchievement\("chart_collaboration"\)/)
  assert.match(legacy, /unlockAchievement\("collab_accept"\)/)
  assert.match(legacy, /state\.jobChangeCount>=2\)unlockAchievement\("job_change"\)/)
  assert.match(legacy, /Number\(state\.ap\)>42\)unlockAchievement\("ap_over_42"\)/)
  assert.match(legacy, /Number\(state\.discussion\)>=Number\(state\.players\)\*10\)unlockAchievement\("bad_popularity"\)/)
})

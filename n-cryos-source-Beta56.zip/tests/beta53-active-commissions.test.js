import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import { ACHIEVEMENTS } from '../src/game/achievements.js'

const indexOf = id => ACHIEVEMENTS.findIndex(item => item.id === id)

test('多线施工与隐藏成就能买就买紧跟在你快点之后', () => {
  assert.equal(indexOf('multi_commission'), indexOf('expedite') + 1)
  assert.equal(indexOf('ten_commissions'), indexOf('multi_commission') + 1)
  assert.equal(ACHIEVEMENTS[indexOf('ten_commissions')].hidden, true)
})

test('活跃原创委托区按十段进度渲染，无委托时隐藏', async () => {
  const [content, legacy, css] = await Promise.all([
    readFile(new URL('../src/components/ContentPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
    readFile(new URL('../src/styles/legacy.css', import.meta.url), 'utf8'),
  ])
  assert.match(content, /id="activeComposerCommissions"[\s\S]*hidden/)
  assert.match(content, /当前正在创作委托的曲师/)
  assert.match(legacy, /activeSection\.hidden=!activeCommissions\.length/)
  assert.match(legacy, /Array\.from\(\{length:10\}/)
  assert.match(legacy, /Math\.floor\(progress\*10\+1e-9\)/)
  assert.match(legacy, /role="progressbar"/)
  assert.match(css, /\.ten-segment-progress\{display:grid;grid-template-columns:repeat\(10/)
})

test('成就按同时委托的不同曲师数量触发', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  assert.match(legacy, /new Set\(activeOriginalCommissions\(\)\.map\(x=>x\.composerId\)\)\.size/)
  assert.match(legacy, /activeComposerCount>=3\)unlockAchievement\("multi_commission"\)/)
  assert.match(legacy, /activeComposerCount>=10\)unlockAchievement\("ten_commissions"\)/)
})

test('疑虑提醒合并所有成员姓名且不带等级职位', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  const reminder = legacy.match(/function remindDoubtingMembers\(\)[\s\S]*?\n}/)?.[0] || ''
  assert.match(reminder, /member=>member\.status==="疑虑"/)
  assert.match(reminder, /member=>member\.name/)
  assert.match(reminder, /成员状态：\$\{names\.join\("、"\)\} 正处于“疑虑”状态。/)
  assert.doesNotMatch(reminder, /memberName|rarity|role/)
})

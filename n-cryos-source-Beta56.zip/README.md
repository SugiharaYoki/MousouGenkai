# N-Cryos 音乐游戏运营模拟器

这是从单文件原型整理出的 Vue 3 + Vite + UnoCSS 项目。游戏逻辑、页面组件、样式和数据现在分开维护；正式构建仍然会生成一个可离线打开的 HTML 文件。

## 开发

```bash
npm install
npm run dev
```

## 构建

```bash
npm run build
```

构建结果位于 `dist/index.html`，其中已经内嵌脚本、样式、曲师数据与作品集数据，不需要旁边再放 JSON 文件。

## 响应式界面

- 自动模式会根据视口与触控设备特征选择电脑或手机界面。
- 右上角设备按钮可在“电脑端 → 手机端 → 自动”之间即时切换。
- 手机端使用“今日、团队、内容、状态、事件”五页底部导航；事件记录不会再占用主界面宽度。
- 720px 及以上的手机/平板横屏会自动使用双列布局，电脑模式继续保留三栏控制台。

## 目录

- `src/components/`：Vue 页面组件
- `src/data/`：曲师和作品集 JSON
- `src/game/legacy.js`：原有模拟器核心逻辑（作为兼容层保留）
- `src/styles/legacy.css`：原有样式基线
- `src/styles/mobile.css`：新版视觉与移动端覆盖
- `src/composables/useLegacyActions.js`：Vue 与核心逻辑之间的调用桥
- `docs/`：现行产品需求、实现决定和历史设计参考

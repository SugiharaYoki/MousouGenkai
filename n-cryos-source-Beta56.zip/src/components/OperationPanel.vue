<script setup>
import { ref } from 'vue'
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke, valueOf } = useLegacyActions()
const importSaveA = ref(null)
const importSaveB = ref(null)
const importSaveC = ref(null)

const importInputs = { manualA: importSaveA, manualB: importSaveB, manualC: importSaveC }

const openImportSave = (slot) => {
  importInputs[slot]?.value?.click()
}

const importSave = (event, slot) => {
  invoke('importSaveTxt', event.target.files?.[0], slot)
  event.target.value = ''
}
</script>

<template>
  <section class="panel mobile-operation">
    <div class="panel-heading">
      <div>
        <p class="eyebrow">DAILY LOOP</p>
        <h2 class="section-heading">操作面板</h2>
      </div>
      <span class="panel-index">01</span>
    </div>

    <div class="two">
      <div class="card job-card">
        <div class="k">主业</div>
        <div id="jobName" class="v job-value"></div>
        <button id="jobEditButton" class="money-sidegig job-edit-button touch-control" type="button" @click="invoke('toggleJobEditor')">
          <b>修改主业</b><span id="jobEditHint">可修改主业</span>
        </button>
      </div>
      <div class="card money-card">
        <div class="k">存款</div>
        <div id="money" class="v"></div>
        <button class="money-sidegig touch-control" type="button" @click="invoke('sideGig')">
          <b>赚外快</b><span id="sideGigCostHint">8行动点 / -40精神</span>
        </button>
      </div>
    </div>

    <div id="jobEditorRow" class="row job-row" hidden>
      <select id="jobSelect" class="touch-control" @change="invoke('setJob', valueOf($event))">
        <option value="home">家里蹲</option>
        <option value="easy">短期零工</option>
        <option value="normal">中期工作</option>
        <option value="hard">长期合同</option>
      </select>
      <span id="jobLockText" class="sub"></span>
    </div>

    <div class="barbox resource-bar ap-resource">
      <div class="barhead"><b>行动点</b><span id="apText"></span></div>
      <div class="bar resource-track"><div id="apBar" class="fill ap-fill"></div></div>
    </div>
    <div class="barbox resource-bar spirit-resource">
      <div class="barhead"><b>精神</b><span id="fatigueText"></span></div>
      <div class="bar resource-track"><div id="fatigueBar" class="fill spirit-fill"></div></div>
    </div>
    <div id="fatigueWarning">⚠ 当前精神低于100，部分行动可能受到影响。</div>
    <div id="developmentBars"></div>
    <div id="doubleCostText" class="statusline"></div>

    <div class="action-grid">
      <button id="writeCopyBtn" class="action work-orange touch-control" type="button" @click="invoke('writeCopy')">
        <b id="writeCopyLabel">写动态</b><span id="writeCopyCostHint">2行动点 / -5精神</span>
      </button>
      <button
        id="derivativeAnnouncementBtn"
        class="action work-orange touch-control"
        type="button"
        style="display: none"
        @click="invoke('publishDerivativeAnnouncement')"
      >
        <b>发公告·带衍生图</b><span>2行动点 / -5精神</span>
      </button>
      <button id="writeProgramBtn" class="action work-orange touch-control" type="button" @click="invoke('writeProgram')">
        <b>写程序</b><span id="programCostHint"></span>
      </button>
      <button id="studyProgramBtn" class="action learn-purple touch-control" type="button" @click="invoke('studyProgram')">
        <b>学程序</b><span id="studyProgramCostHint">5行动点 / -30精神</span>
      </button>
      <button id="studyArtBtn" class="action learn-purple touch-control" type="button" @click="invoke('studyArt')">
        <b>学美术</b><span id="studyArtCostHint">10行动点 / -50精神</span>
      </button>
      <button
        id="createDerivativeBtn"
        class="action work-orange touch-control"
        type="button"
        style="display: none"
        @click="invoke('createDerivative')"
      >
        <b>创作衍生图</b><span>8行动点 / -30精神</span>
      </button>
      <button class="action stress-down touch-control" type="button" @click="invoke('playRhythm')">
        <b>打音游</b><span id="rhythmCostHint">2行动点 / +40精神</span>
      </button>
      <button id="takeoutBtn" class="action stress-down touch-control" type="button" @click="invoke('takeout')">
        <b>点外卖</b><span id="takeoutCostHint">1行动点 / +25精神</span>
      </button>
      <button id="meditateBtn" class="action tester-meditate touch-control" type="button" style="display: none" @click="invoke('meditate')">
        <b>冥想</b><span>+50行动点 / +200精神 / +5000存款</span>
      </button>
    </div>

    <button class="big touch-control" type="button" @click="invoke('endDay')">结束今天</button>

    <div class="save-card">
      <div class="between"><b>存档</b><span id="saveStatus" class="sub">未检测到存档</span></div>
      <div class="row save-actions">
        <button class="touch-control" type="button" @click="invoke('openSaveManager')">管理存档</button>
      </div>
      <div class="sub">结束今日后自动存档。</div>
    </div>

    <dialog id="saveManagerDialog" class="save-manager-dialog" @cancel.prevent="invoke('closeSaveManager')">
      <header class="save-manager-heading">
        <div><p class="eyebrow">SAVE MANAGER</p><h2>存档管理</h2></div>
        <button type="button" aria-label="关闭存档管理" @click="invoke('closeSaveManager')">×</button>
      </header>
      <div class="save-manager-grid">
        <div class="save-slots-grid">
          <section class="save-slot-card save-slot-auto">
            <span class="save-slot-kicker">AUTOSAVE</span>
            <h3>自动存档</h3>
            <p id="autoSaveMeta" class="sub">未检测到存档</p>
            <div class="save-slot-actions">
              <button id="loadAutoSaveButton" class="good" type="button" @click="invoke('loadSaveSlot', 'auto')">读取</button>
              <button id="exportAutoSaveButton" type="button" @click="invoke('exportSaveSlot', 'auto')">导出存档</button>
              <button id="deleteAutoSaveButton" class="bad" type="button" @click="invoke('deleteSaveSlot', 'auto')">删除</button>
            </div>
          </section>
          <section v-for="slot in ['A', 'B', 'C']" :key="slot" class="save-slot-card save-slot-manual">
            <span class="save-slot-kicker">MANUAL SAVE {{ slot }}</span>
            <h3>存档{{ slot }}</h3>
            <p :id="`manual${slot}SaveMeta`" class="sub">未检测到存档</p>
            <div class="save-slot-actions manual-slot-actions">
              <button :id="`saveManual${slot}SaveButton`" class="good" type="button" @click="invoke('saveGame', `manual${slot}`)">保存</button>
              <button :id="`loadManual${slot}SaveButton`" type="button" @click="invoke('loadSaveSlot', `manual${slot}`)">读取</button>
              <button :id="`importManual${slot}SaveButton`" type="button" @click="openImportSave(`manual${slot}`)">导入</button>
              <button :id="`exportManual${slot}SaveButton`" type="button" @click="invoke('exportSaveSlot', `manual${slot}`)">导出</button>
              <button :id="`deleteManual${slot}SaveButton`" class="bad" type="button" @click="invoke('deleteSaveSlot', `manual${slot}`)">删除</button>
            </div>
          </section>
          <input id="importSaveA" ref="importSaveA" type="file" accept=".txt,text/plain" hidden @change="importSave($event, 'manualA')" />
          <input id="importSaveB" ref="importSaveB" type="file" accept=".txt,text/plain" hidden @change="importSave($event, 'manualB')" />
          <input id="importSaveC" ref="importSaveC" type="file" accept=".txt,text/plain" hidden @change="importSave($event, 'manualC')" />
        </div>
        <aside class="save-manager-tools">
          <button class="save-manager-new" type="button" @click="invoke('startNewGame')"><b>开始新游戏</b><span>保留成就列表</span></button>
        </aside>
      </div>
    </dialog>
  </section>
</template>

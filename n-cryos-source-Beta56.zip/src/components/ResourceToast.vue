<template>
  <div id="resourceToast" class="resource-toast" role="status" aria-live="polite">
    <span class="resource-toast-ap"><small>剩余行动点</small><b id="resourceToastAP">0</b></span>
    <span class="resource-toast-spirit"><small>剩余精神</small><b id="resourceToastSpirit">200</b></span>
  </div>
</template>

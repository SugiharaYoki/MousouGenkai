<script setup>
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke } = useLegacyActions()
</script>

<template>
  <dialog id="achievementDialog" class="achievement-dialog" @cancel.prevent="invoke('closeAchievementDialog')">
    <header class="achievement-dialog-heading">
      <div>
        <p class="eyebrow">ACHIEVEMENTS</p>
        <h2>成就一览</h2>
        <p id="achievementProgressDesktop" class="sub"></p>
      </div>
      <button type="button" aria-label="关闭成就一览" @click="invoke('closeAchievementDialog')">×</button>
    </header>
    <div id="achievementListDesktop" class="achievement-grid achievement-grid-desktop"></div>
  </dialog>
</template>

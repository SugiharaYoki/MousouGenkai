<script setup>
const dismiss = () => {
  document.getElementById('eventToast')?.classList.remove('show')
}
</script>

<template>
  <button
    id="eventToast"
    class="event-toast"
    type="button"
    aria-live="polite"
    aria-label="最新事件，点击关闭"
    @click="dismiss"
  >
    <span id="eventToastContent"></span>
    <small>点击关闭</small>
  </button>
</template>

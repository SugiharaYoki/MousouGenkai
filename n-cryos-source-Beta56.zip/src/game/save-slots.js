export const SAVE_SLOT_IDS = Object.freeze(['auto', 'manualA', 'manualB', 'manualC'])

export const SAVE_SLOT_KEYS = Object.freeze({
  auto: 'noncommercial_music_game_simulator_autosave_v1',
  // manualA 复用 Beta51 的手动存档键，现有玩家无需额外搬运即可继续读取。
  manualA: 'noncommercial_music_game_simulator_manual_save_v1',
  manualB: 'noncommercial_music_game_simulator_manual_save_b_v1',
  manualC: 'noncommercial_music_game_simulator_manual_save_c_v1',
})

export const LEGACY_SINGLE_SAVE_KEY = 'noncommercial_music_game_simulator_single_save_v1'

function assertSlot(slot) {
  if (!SAVE_SLOT_IDS.includes(slot)) throw new Error(`UNKNOWN_SAVE_SLOT:${slot}`)
}

function parsePayload(raw) {
  if (!raw) return null
  const payload = JSON.parse(raw)
  if (!payload?.state) throw new Error('INVALID_SAVE_PAYLOAD')
  return payload
}

export function createSaveSlotStore({ storage }) {
  if (!storage) throw new Error('SAVE_STORAGE_REQUIRED')

  const migrateLegacySave = () => {
    if (storage.getItem(SAVE_SLOT_KEYS.manualA)) return false
    const legacy = storage.getItem(LEGACY_SINGLE_SAVE_KEY)
    if (!legacy) return false
    parsePayload(legacy)
    storage.setItem(SAVE_SLOT_KEYS.manualA, legacy)
    return true
  }

  migrateLegacySave()

  return Object.freeze({
    read(slot) {
      assertSlot(slot)
      return parsePayload(storage.getItem(SAVE_SLOT_KEYS[slot]))
    },
    write(slot, payload) {
      assertSlot(slot)
      if (!payload?.state) throw new Error('INVALID_SAVE_PAYLOAD')
      storage.setItem(SAVE_SLOT_KEYS[slot], JSON.stringify(payload))
      return payload
    },
    remove(slot) {
      assertSlot(slot)
      storage.removeItem(SAVE_SLOT_KEYS[slot])
    },
    list() {
      return Object.fromEntries(SAVE_SLOT_IDS.map(slot => [slot, this.read(slot)]))
    },
    migrateLegacySave,
  })
}

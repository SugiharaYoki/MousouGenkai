import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import * as rules from '../src/game/rules.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')

test('同一游戏的纯联动曲包无视最低曲数，混入普通歌曲后仍需至少三首', () => {
  const collabSong = (game, name) => ({ name, source: 'collab', collabGameName: game })
  assert.equal(rules.packageHasMinimumSongs({
    type: '支线包',
    songs: [collabSong('星海节奏', '联动曲A')],
  }), true)
  assert.equal(rules.packageHasMinimumSongs({
    type: '支线包',
    songs: [collabSong('星海节奏', '联动曲A'), collabSong('另一游戏', '联动曲B')],
  }), false)
  assert.equal(rules.packageHasMinimumSongs({
    type: '支线包',
    songs: [collabSong('星海节奏', '联动曲A'), { name: '普通曲', source: 'commission' }],
  }), false)
})

test('已经完成 Alpha 的旧存档歌曲不会被异常谱面或美术数值挡住 Beta', () => {
  assert.equal(rules.songContentReadyForBeta({
    chartProgress: 100,
    artProgress: 98.7,
    alpha: true,
    alphaStatus: 'completed',
  }), true)
  assert.equal(rules.songContentReadyForBeta({
    chartProgress: 100,
    artProgress: 98.7,
    alpha: false,
    alphaStatus: 'idle',
  }), false)
})

test('事务占用成员统一排除出随机成员池', () => {
  assert.equal(rules.memberAvailableForRandomPool({ occupiedUntil: 11 }, 10), false)
  assert.equal(rules.memberAvailableForRandomPool({ occupiedUntil: 10 }, 10), true)
  assert.equal(rules.memberAvailableForRandomPool(null, 10), false)
})

test('Ariayaka 只在调停判断中临时按100好感加入公共随机池', () => {
  const ariayaka = { id: 1, name: 'Ariayaka', affection: 5, occupiedUntil: 0 }
  const friend = { id: 2, name: '朋友', affection: 81, occupiedUntil: 0 }
  const occupied = { id: 3, name: 'Ariayaka', affection: 90, occupiedUntil: 20 }
  const pool = rules.teamArgumentPeacemakerCandidates([ariayaka, friend, occupied], 10)
  assert.deepEqual(pool.map(member => member.id), [1, 2])
  assert.equal(ariayaka.affection, 5)
  assert.equal(rules.teamExplosionDefuseChance(pool.length), 0.2)
})

test('随机成员事件通过统一可用成员入口筛选', async () => {
  const legacy = await load('../src/game/legacy.js')
  assert.match(legacy, /function availableMemberPool\(/)
  assert.match(legacy.match(/function tryQueueSuperWorkbookHelp\(\)[\s\S]*?\n}/)?.[0] ?? '', /availableMemberPool/)
  assert.match(legacy.match(/function weeklySpecialMemberEligible\([\s\S]*?\n}/)?.[0] ?? '', /memberAvailableForRandomPool/)
  assert.match(legacy.match(/function tryDefuseTeamArgument\(\)[\s\S]*?\n}/)?.[0] ?? '', /teamArgumentPeacemakerCandidates/)
  assert.match(legacy.match(/function recommendationCommissionDaily\(\)[\s\S]*?\n}/)?.[0] ?? '', /availableMemberPool/)
})

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import { monthlySponsorshipIncome } from '../src/game/rules.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')

test('粘性比例不再是赞助收入的硬门槛', () => {
  assert.equal(monthlySponsorshipIncome({
    platformEnabled: true,
    players: 1000,
    stickiness: 0,
    artPursuit: 50,
    rating: 30,
  }), 1.4)

  assert.equal(monthlySponsorshipIncome({
    platformEnabled: false,
    players: 1000,
    stickiness: 0,
    artPursuit: 50,
    rating: 30,
  }), 0)
})

test('赞助金额依次计算粘性人数、粘性比例、艺术追求、好评度和普通玩家', () => {
  const actual = monthlySponsorshipIncome({
    platformEnabled: true,
    players: 1200,
    stickiness: 10,
    artPursuit: 60,
    rating: 35,
  })

  // 粘性玩家 120 人：10 档 × 0.3，再受 10% 粘性比例的 16% 加成。
  // 艺术追求 60：单独加 0.01；好评度 35：前两项合计再乘 1.03。
  // 普通玩家 1080 人：最后加入 2 档 × 0.7，不受任何倍率影响。
  assert.ok(Math.abs(actual - 4.9947) < 1e-9)
})

test('不足一个完整档位的数值不会提前获得赞助加值', () => {
  assert.equal(monthlySponsorshipIncome({
    platformEnabled: true,
    players: 511,
    stickiness: 2.34,
    artPursuit: 59.99,
    rating: 34.99,
  }), 0.7)
})

test('十万玩家在低粘性比例下也能获得赞助', () => {
  const income = monthlySponsorshipIncome({
    platformEnabled: true,
    players: 100000,
    stickiness: 10,
    artPursuit: 100,
    rating: 80,
  })
  assert.ok(Math.abs(income - 502.9142) < 1e-9)
})

test('Beta63 版本信息同步', async () => {
  const [index, header, legacy] = await Promise.all([
    load('../index.html'),
    load('../src/components/AppHeader.vue'),
    load('../src/game/legacy.js'),
  ])
  assert.match(index, /Beta 63/)
  assert.match(header, /Beta 63/)
  assert.match(legacy, /version:"Beta63"/)
  const settlement = legacy.match(/function sponsorship\(\)[\s\S]*?\nfunction bankruptcyCheck/)?.[0] ?? ''
  assert.match(settlement, /rating:state\.rating/)
  assert.doesNotMatch(settlement, /artMods|designSponsorMultiplier/)
})

<script setup>
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke, valueOf } = useLegacyActions()
</script>

<template>
  <section class="panel mobile-content">
    <div class="tabs" role="tablist" aria-label="内容管理">
      <button class="tab active touch-control" type="button" data-view="composerView" role="tab" @click="invoke('showTab', $event.currentTarget)">联系曲师</button>
      <button class="tab touch-control" type="button" data-view="libraryView" role="tab" @click="invoke('showTab', $event.currentTarget)">管理曲库</button>
      <button class="tab touch-control" type="button" data-view="packageView" role="tab" @click="invoke('showTab', $event.currentTarget)">规划与更新</button>
      <button class="tab touch-control" type="button" data-view="collabView" role="tab" @click="invoke('showTab', $event.currentTarget)">联动</button>
    </div>
    <div id="composerView" class="view active">
      <div class="content-view-heading composer-view-heading">
        <div><h2 class="section-heading">曲师与作品</h2><p class="sub">先选择委托类型与风格，再查看曲师擅长领域和可收录作品。</p></div>
        <label class="composer-sort-control">曲师排序
          <select id="composerSortSelect" class="touch-control" @change="invoke('setComposerSortMode', valueOf($event))">
            <option value="name">曲师名称</option>
            <option value="collabs">约稿次数</option>
            <option value="noncommercialPrice">非商价格</option>
            <option value="commercialPrice">商业价格</option>
            <option value="formalPrice">正式邀请价格</option>
            <option value="hotStyle">灼热风格</option>
            <option value="lyricalStyle">抒情风格</option>
            <option value="coldStyle">冷冽风格</option>
            <option value="popularity">人气</option>
            <option value="quality">技术</option>
            <option value="efficiency">效率</option>
          </select>
        </label>
      </div>
      <section id="activeComposerCommissions" class="active-composer-commissions" hidden>
        <div class="active-commission-heading">
          <div><span class="active-commission-kicker">IN PRODUCTION</span><h3>当前正在创作委托的曲师</h3></div>
          <span id="activeCommissionCount" class="active-commission-count"></span>
        </div>
        <div id="activeCommissionList" class="active-commission-list"></div>
      </section>
      <div id="composers" class="list composer-list"></div>
    </div>
    <div id="libraryView" class="view">
      <div class="content-view-heading library-heading">
        <h2 class="section-heading">曲库</h2>
        <div class="library-filter-group">
          <button id="toggleShelvedSongsButton" class="touch-control library-shelf-toggle" type="button" aria-pressed="false" title="查看雪藏曲目" aria-label="查看雪藏曲目" hidden @click="invoke('toggleShelvedSongsVisibility')"><span id="shelvedToggleIcon" aria-hidden="true">▣</span><small id="shelvedToggleCount">0</small></button>
          <button id="toggleInstalledSongsButton" class="touch-control library-filter-button" type="button" aria-pressed="false" @click="invoke('toggleInstalledSongsVisibility')">已更新内容：显示</button>
        </div>
      </div>
      <div class="sub content-note">谱面完成后会显示一次性的 Alpha 入口；仍需谱面与美术都完成才能开始测试。Alpha 非发布前置。</div>
      <div id="library" class="list"></div>
    </div>
    <div id="packageView" class="view">
      <div class="content-view-heading package-view-heading">
        <h2 class="section-heading">曲包与更新</h2>
        <div class="library-filter-group">
          <button id="toggleReleasedPackagesButton" class="touch-control library-filter-button" type="button" aria-pressed="true" @click="invoke('toggleReleasedPackagesVisibility')">已更新内容：隐藏</button>
        </div>
      </div>
      <div class="row package-toolbar">
        <select id="packageType" class="touch-control"><option>主线包</option><option>支线包</option><option>补充包</option><option>单曲</option></select>
        <button class="touch-control" type="button" @click="invoke('createPackage')">新建曲包</button>
      </div>
      <div id="packages"></div>
    </div>
    <div id="collabView" class="view"><h2 class="section-heading">联动</h2><div id="collabs"></div></div>
  </section>
</template>

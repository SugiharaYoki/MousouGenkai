<script setup>
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke } = useLegacyActions()
</script>

<template>
  <section id="exhibitionInvitePanel" class="panel exhibition-invite-panel" hidden>
    <div class="exhibition-invite-heading">
      <div>
        <p class="eyebrow">EVENT INVITATION</p>
        <h2><span id="exhibitionOrganizerName"></span> · 参展邀请</h2>
        <p id="exhibitionDateDescription" class="sub"></p>
      </div>
      <strong id="exhibitionResponseDays" class="exhibition-response-days">剩余回应日数 15</strong>
    </div>

    <p class="exhibition-instruction">
      你需要派遣2/3/5级的制作组成员前去展会坐镇。他们将在展会开始之日起进入为期5天的事务占用状态。
    </p>

    <div id="exhibitionMemberChoices" class="exhibition-member-choices"></div>

    <section id="exhibitionMerchandiseSection" class="exhibition-merchandise-section" hidden>
      <div class="between">
        <div>
          <h3>周边售卖</h3>
          <p class="sub">每款周边预留1张衍生图；同类型最多3款，合计最多8款。确认参展时才正式扣除。</p>
        </div>
        <span id="exhibitionDerivativeAvailability" class="tag"></span>
      </div>
      <div class="exhibition-merchandise-add row">
        <select id="exhibitionMerchandiseTypeSelect" class="touch-control">
          <option value="立牌">立牌｜售价28｜人气2｜口碑1</option>
          <option value="徽章">徽章｜售价18｜人气3｜口碑2</option>
          <option value="明信片">明信片｜售价8｜人气5｜口碑1</option>
          <option value="镭射票">镭射票｜售价12｜人气4｜口碑2</option>
          <option value="文具">文具｜售价28｜人气3｜口碑3</option>
          <option value="帆布袋">帆布袋｜售价58｜人气1｜口碑2</option>
        </select>
        <button type="button" @click="invoke('addExhibitionMerchandise')">增加周边</button>
      </div>
      <div id="exhibitionMerchandiseList" class="exhibition-merchandise-list"></div>
    </section>

    <div class="exhibition-settlement">
      <div>
        <span>参展结算</span>
        <b id="exhibitionCostTotal">¥0</b>
      </div>
      <p id="exhibitionCostBreakdown" class="sub"></p>
    </div>
    <p id="exhibitionValidationMessage" class="exhibition-validation-message" aria-live="polite"></p>
    <div class="exhibition-confirm-row">
      <button class="primary touch-control" type="button" @click="invoke('acceptExhibitionInvite')">同意邀请</button>
    </div>
  </section>
</template>

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

const composersUrl = new URL('../src/data/composers.json', import.meta.url)
const indexUrl = new URL('../index.html', import.meta.url)
const headerUrl = new URL('../src/components/AppHeader.vue', import.meta.url)
const legacyUrl = new URL('../src/game/legacy.js', import.meta.url)

test('Beta65 修正四位日本曲师的国籍与姓名', async () => {
  const composers = JSON.parse(await readFile(composersUrl, 'utf8'))
  const byName = name => composers.find(composer => composer.name === name)

  for (const name of ['Kalvin', 'kemomi2r', 'saikuro', '豹景。']) {
    assert.equal(byName(name)?.country, '日本')
  }
  assert.equal(byName('景虎'), undefined)
})

test('当前版本号已同步到页面与存档', async () => {
  const [index, header, legacy] = await Promise.all([
    readFile(indexUrl, 'utf8'),
    readFile(headerUrl, 'utf8'),
    readFile(legacyUrl, 'utf8'),
  ])

  assert.match(index, /Beta 66/)
  assert.match(header, /Beta 66/)
  assert.match(legacy, /version:"Beta66"/)
  assert.match(legacy, /运营模拟器 · Beta 66/)
})

test('旧存档中的景虎姓名与歌曲署名会迁移为豹景。', async () => {
  const legacy = await readFile(legacyUrl, 'utf8')
  assert.match(legacy, /base\.name==="豹景。"\?oldByName\.get\("景虎"\)/)
  assert.match(legacy, /replace\(\/景虎\/g,"豹景。"\)/)
})

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import {
  canReceiveCollabOffer,
  portfolioReleaseProgressDay,
} from '../src/game/rules.js'

const loadJson = async path => JSON.parse(await readFile(new URL(path, import.meta.url), 'utf8'))

test('职业锁定日期统一显示为游戏年与年内日', async () => {
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  assert.match(legacy, /最早可在\$\{GAME_RULES\.formatGameDate\(state\.jobLockedUntil\)\}修改/)
  assert.match(legacy, /jobUnlockDate=GAME_RULES\.formatGameDate\(state\.jobLockedUntil\|\|1\)/)
  assert.match(legacy, /主业锁定至\$\{jobUnlockDate\}/)
  assert.match(legacy, /锁定至\$\{jobUnlockDate\}/)
})

test('联动邀请要求至少三首已经上线的原创委托曲', async () => {
  assert.equal(canReceiveCollabOffer(0), false)
  assert.equal(canReceiveCollabOffer(2), false)
  assert.equal(canReceiveCollabOffer(3), true)
  const legacy = await readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8')
  assert.match(legacy, /installedSongs\(\)\.filter\(song=>song\.source==="commission"\)\.length/)
  assert.match(legacy, /createCollabOffer\(\)[\s\S]*?canReceiveCollabOffer/)
  assert.match(legacy, /collabMonthly\(\)[\s\S]*?canReceiveCollabOffer/)
})

test('作品发布计时在第100日后暂停，并在首次更新后续计', () => {
  assert.equal(portfolioReleaseProgressDay({ currentDay: 80, firstUpdateDay: null }), 80)
  assert.equal(portfolioReleaseProgressDay({ currentDay: 300, firstUpdateDay: null }), 100)
  assert.equal(portfolioReleaseProgressDay({ currentDay: 300, firstUpdateDay: 50 }), 300)
  assert.equal(portfolioReleaseProgressDay({ currentDay: 200, firstUpdateDay: 200 }), 100)
  assert.equal(portfolioReleaseProgressDay({ currentDay: 250, firstUpdateDay: 200 }), 150)
})

test('三位新增曲师的数值与双向羁绊准确', async () => {
  const composers = await loadJson('../src/data/composers.json')
  const byName = name => composers.find(composer => composer.name === name)
  const expected = {
    '持月怜久': ['日本', 2, 40, 4, 80, 60, 3000, 9000, 18000, 2.9],
    weekly: ['中国', 4, 50, 4, 50, 50, 3000, 9000, 24000, 2.9],
    Eutopia: ['日本', 2, 70, 2, 50, 40, 6000, 12000, 28000, 3.5],
  }
  for (const [name, values] of Object.entries(expected)) {
    const composer = byName(name)
    assert.ok(composer, `缺少曲师 ${name}`)
    assert.deepEqual([
      composer.country, composer.abstract, composer.popularity, composer.efficiency,
      composer.mental, composer.affDifficulty, composer.prices.非商,
      composer.prices.商业, composer.prices.正式邀请, composer.avgQuality,
    ], values)
  }

  const bondedPairs = [
    ['持月怜久', 'Half'], ['持月怜久', 'weekly'], ['weekly', 'USAGI'],
    ['Eutopia', 'KuROWhite'], ['Eutopia', 'whiteball'],
  ]
  for (const [left, right] of bondedPairs) {
    assert.ok(byName(left).bond.includes(byName(right).id), `${left} 缺少对 ${right} 的羁绊`)
    assert.ok(byName(right).bond.includes(byName(left).id), `${right} 缺少对 ${left} 的羁绊`)
  }
})

test('22首新增作品数据完整并挂载到所有合作曲师', async () => {
  const portfolios = await loadJson('../src/data/portfolios.json')
  const additions = portfolios.filter(item => item.id >= 52038 && item.id <= 52059)
  const byName = name => additions.find(item => item.name === name)
  assert.equal(additions.length, 22)

  const expectedNames = [
    'Prophet', '揺火', '祸津', '寒灯秋水', '温室花房第10作：walzer',
    '温室花房第11作：ratio', '温室花房第12作：crystal', '月读', '辉夜',
    'Nymphs', '月煌', 'Nova', 'Twinkling Glimmer', 'FiniTE -Electricity-',
    "it's bed time", '天蝎座', '水塔', 'Garden', 'Road to Salvation',
    'Devastation', 'Light and Darkness', '温室花房第13作：hope',
  ]
  assert.deepEqual(additions.map(item => item.name), expectedNames)
  assert.deepEqual(byName('Prophet').collabComposerIds, [1, 7])
  assert.deepEqual(byName('Light and Darkness').collabComposerIds, [1015, 1002, 26])
  assert.deepEqual(byName('温室花房第13作：hope').collabComposerIds, [1013, 11])
  assert.deepEqual([
    byName('温室花房第13作：hope').price,
    byName('温室花房第13作：hope').quality,
    byName('温室花房第13作：hope').releaseMinDay,
    byName('温室花房第13作：hope').releaseMaxDay,
  ], [2400, 4, 600, 700])
})

test('Beta66版本号与最后更新日期同步', async () => {
  const [index, header, economy, legacy] = await Promise.all([
    readFile(new URL('../index.html', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/AppHeader.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/components/EconomyPanel.vue', import.meta.url), 'utf8'),
    readFile(new URL('../src/game/legacy.js', import.meta.url), 'utf8'),
  ])
  assert.match(index, /Beta 66/)
  assert.match(header, /Beta 66/)
  assert.match(economy, /最后更新日期：2026年08月29日/)
  assert.match(legacy, /version:"Beta66"/)
})

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import * as rules from '../src/game/rules.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')

test('高完成度工种在无人负责时仍可重新分配', () => {
  assert.equal(rules.canModifyRoleAssignment({
    role: 'chart', progress: 90, assignedCount: 0, installed: false, shelved: false,
  }), true)
  assert.equal(rules.canModifyRoleAssignment({
    role: 'art', progress: 90, assignedCount: 0, installed: false, shelved: false,
  }), true)
})

test('高完成度工种已有负责人时继续锁定，未上架与未雪藏前置不变', () => {
  assert.equal(rules.canModifyRoleAssignment({
    role: 'chart', progress: 90, assignedCount: 1, installed: false, shelved: false,
  }), false)
  assert.equal(rules.canModifyRoleAssignment({
    role: 'art', progress: 90, assignedCount: 1, installed: false, shelved: false,
  }), false)
  assert.equal(rules.canModifyRoleAssignment({
    role: 'chart', progress: 90, assignedCount: 0, installed: true, shelved: false,
  }), false)
  assert.equal(rules.canModifyRoleAssignment({
    role: 'art', progress: 90, assignedCount: 0, installed: false, shelved: true,
  }), false)
})

test('只由玩家亲自制作的高进度内容可以继续做到完成', () => {
  assert.equal(rules.canPersonallyWorkOnRole({
    role: 'chart', progress: 90, assignedCount: 0, averageAffection: 0,
  }), true)
  assert.equal(rules.canPersonallyWorkOnRole({
    role: 'art', progress: 90, assignedCount: 0, averageAffection: 0,
  }), true)
  assert.equal(rules.canPersonallyWorkOnRole({
    role: 'chart', progress: 100, assignedCount: 0, averageAffection: 0,
  }), false)
})

test('已有组员负责时，亲自支援仍需要原有平均好感门槛', () => {
  assert.equal(rules.canPersonallyWorkOnRole({
    role: 'chart', progress: 90, assignedCount: 1, averageAffection: 50,
  }), false)
  assert.equal(rules.canPersonallyWorkOnRole({
    role: 'chart', progress: 90, assignedCount: 1, averageAffection: 50.01,
  }), true)
  assert.equal(rules.canPersonallyWorkOnRole({
    role: 'art', progress: 90, assignedCount: 1, averageAffection: 80,
  }), false)
  assert.equal(rules.canPersonallyWorkOnRole({
    role: 'art', progress: 90, assignedCount: 1, averageAffection: 80.01,
  }), true)
})

test('游戏引擎把当前工种负责人数量传给统一分配规则', async () => {
  const legacy = await load('../src/game/legacy.js')
  assert.match(legacy, /GAME_RULES\.canModifyRoleAssignment\(\{[\s\S]*assignedCount:assignedRoleMemberIds\(s,role\)\.length[\s\S]*\}\)/)
  assert.match(legacy, /GAME_RULES\.canPersonallyWorkOnRole\(\{[\s\S]*assignedCount:assignedIds\.length[\s\S]*\}\)/)
})

test('Beta64版本号与更新日期同步', async () => {
  const [index, header, legacy, economy] = await Promise.all([
    load('../index.html'), load('../src/components/AppHeader.vue'),
    load('../src/game/legacy.js'), load('../src/components/EconomyPanel.vue'),
  ])
  assert.match(index, /Beta 66/)
  assert.match(header, /Beta 66/)
  assert.match(legacy, /version:"Beta66"/)
  assert.match(economy, /最后更新日期：2026年08月29日/)
})

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')

test('创作欲望高每天判定、持续时间与金色状态完整接入日结', async () => {
  const [legacy, css] = await Promise.all([
    load('../src/game/legacy.js'),
    load('../src/styles/mobile.css'),
  ])
  assert.match(legacy, /function creativeDesireDaily\(\)/)
  assert.match(legacy, /Object\.values\(state\.lastIncomingOfferDayByComposer\|\|\{\}\)\.some\(day=>Number\(day\)===state\.day\)/)
  assert.match(legacy, /year\(\)<2\|\|hadIncomingToday\|\|!chance\(\.007\)/)
  assert.match(legacy, /creativeDesireUntil=state\.day\+Math\.floor\(rnd\(7,16\)\)/)
  assert.match(legacy, /最近很想要为音乐游戏创作歌曲/)
  assert.match(legacy, /composerMonthly\(\);collabMonthly\(\)\}creativeDesireDaily\(\)/)
  assert.match(legacy, /creativeDesireActive\(c\)\?"创作欲望高":"可联系"/)
  assert.match(css, /status-创作欲望高/)
})

test('创作欲望高约稿获得双倍成功率、20%工期加速与指定质量直升概率', async () => {
  const legacy = await load('../src/game/legacy.js')
  assert.match(legacy, /if\(creativeDesireActive\(c\)\)p\*=2/)
  assert.match(legacy, /let desireCommission=creativeDesireActive\(c\)/)
  assert.match(legacy, /if\(desireCommission\)days\*=\.80/)
  assert.match(legacy, /creativeDesireCommission:desireCommission/)
  assert.match(legacy, /3:\[\.10,\.20,\.30,\.40,\.50,1\]/)
  assert.match(legacy, /4:\[\.05,\.10,\.15,\.25,\.40,\.80\]/)
  assert.match(legacy, /5:\[\.01,\.03,\.05,\.08,\.12,\.30\]/)
  assert.match(legacy, /creativeDesireQualityUpgrade\(x\.q,c,x\.creativeDesireCommission\)/)
})

test('低于20%可取消约稿并按好感档位退款和扣减好感', async () => {
  const [legacy, css] = await Promise.all([
    load('../src/game/legacy.js'),
    load('../src/styles/legacy.css'),
  ])
  const cancellation = legacy.match(/function cancelCommission\(id\)[\s\S]*?\n}/)?.[0] || ''
  assert.match(cancellation, /commissionProgress\(commission\)>=\.20/)
  assert.match(cancellation, /refundRate=affection<20\?\.80:affection<=50\?\.90:1/)
  assert.match(cancellation, /affectionLossRate=affection<20\?\.20:affection<=50\?\.10:\.01/)
  assert.match(cancellation, /确定要取消约稿吗？将会返还\$\{Math\.round\(refundRate\*100\)\}%的约稿费用。/)
  assert.match(cancellation, /取消了\$\{composer\.name\}正在创作的委托。返还了 ¥\$\{fmt\(refund\)\}。/)
  assert.match(legacy, /progress<\.20\?`<button class="active-commission-cancel"/)
  assert.match(legacy, /pricePaid:price/)
  assert.match(css, /\.active-commission-cancel/)
})

test('曲师排序含全部11项并按指定方向计算', async () => {
  const [content, legacy] = await Promise.all([
    load('../src/components/ContentPanel.vue'),
    load('../src/game/legacy.js'),
  ])
  for (const value of ['name','collabs','noncommercialPrice','commercialPrice','formalPrice','hotStyle','lyricalStyle','coldStyle','popularity','quality','efficiency']) {
    assert.match(content, new RegExp(`value="${value}"`))
  }
  assert.match(legacy, /ascending=\["noncommercialPrice","commercialPrice","formalPrice"\]\.includes\(mode\)/)
  assert.match(legacy, /difference=ascending\?value\(a,mode\)-value\(b,mode\):value\(b,mode\)-value\(a,mode\)/)
  assert.match(legacy, /composerSortSelect\.value=state\.composerSortMode/)
})

test('修改主业入口位于主业卡片内并服从锁定状态', async () => {
  const [operation, legacy, css] = await Promise.all([
    load('../src/components/OperationPanel.vue'),
    load('../src/game/legacy.js'),
    load('../src/styles/legacy.css'),
  ])
  assert.match(operation, /class="card job-card"[\s\S]*id="jobEditButton"[\s\S]*修改主业/)
  assert.match(operation, /id="jobEditorRow"[\s\S]*hidden/)
  assert.match(legacy, /function toggleJobEditor\(\)/)
  assert.match(legacy, /jobEditButton\.disabled=jobLocked/)
  assert.match(css, /\.job-row\[hidden\]\{display:none!important\}/)
})

test('当前版本号和更新日期已同步', async () => {
  const [index, header, legacy, economy] = await Promise.all([
    load('../index.html'),
    load('../src/components/AppHeader.vue'),
    load('../src/game/legacy.js'),
    load('../src/components/EconomyPanel.vue'),
  ])
  assert.match(index, /Beta 66/)
  assert.match(header, /Beta 66/)
  assert.match(legacy, /version:"Beta66"/)
  assert.match(economy, /最后更新日期：2026年08月29日/)
})

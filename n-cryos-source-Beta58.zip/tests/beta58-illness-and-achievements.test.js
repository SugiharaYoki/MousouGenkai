import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import { ACHIEVEMENTS } from '../src/game/achievements.js'
import * as rules from '../src/game/rules.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')
const achievement = id => ACHIEVEMENTS.find(item => item.id === id)

test('PICKUPNEAR的温室花房作品集按7、8、9排序', async () => {
  const portfolios = JSON.parse(await load('../src/data/portfolios.json'))
  const pickupNames = portfolios
    .filter(item => String(item.ownerComposerName).split(',').includes('PICKUPNEAR'))
    .map(item => item.name)
  assert.ok(pickupNames.indexOf('温室花房第7作：flashback') < pickupNames.indexOf('温室花房第8作：magic'))
  assert.ok(pickupNames.indexOf('温室花房第8作：magic') < pickupNames.indexOf('温室花房第9作：recitation'))
})

test('藏起夜空与注意休息成就已注册', () => {
  assert.deepEqual(achievement('shelve_song'), {
    id: 'shelve_song',
    title: '藏起夜空',
    description: '“每首歌必定都有用武之地……或许是如此。”\n雪藏1首歌曲。',
    hidden: false,
  })
  assert.deepEqual(achievement('rest_while_sick'), {
    id: 'rest_while_sick',
    title: '注意休息',
    description: '在生病时什么都不干，直接结束一天。',
    hidden: false,
  })
})

test('成员生病季节、病弱与流感倍率符合规则', () => {
  assert.equal(rules.shouldHaveWeakConstitution(() => 0.099), true)
  assert.equal(rules.shouldHaveWeakConstitution(() => 0.1), false)
  assert.equal(rules.memberIllnessChance({ month: 3, weak: false, fluActive: false }), 0.01)
  assert.equal(rules.memberIllnessChance({ month: 5, weak: true, fluActive: false }), 0.04)
  assert.equal(rules.memberIllnessChance({ month: 3, weak: false, fluActive: true }), 0.03)
  assert.equal(rules.memberIllnessChance({ month: 10, weak: true, fluActive: true }), 0.12)
  assert.equal(rules.memberIllnessChance({ month: 8, weak: false, fluActive: false }), 0)
  assert.equal(rules.memberIllnessChance({ month: 8, weak: true, fluActive: false }), 0.001)
  assert.equal(rules.memberIllnessDailyLimit(false), 2)
  assert.equal(rules.memberIllnessDailyLimit(true), 4)
  assert.equal(rules.memberIllnessRules.cooldownDays, 120)
  assert.equal(rules.memberIllnessRules.memberDurationDays, 7)
  assert.equal(rules.memberIllnessRules.productionMultiplier, 0.5)
})

test('流感与玩家生病使用指定概率、周期和资源上限', () => {
  assert.equal(rules.shouldTriggerFluMonth(3, () => 0.099), true)
  assert.equal(rules.shouldTriggerFluMonth(10, () => 0.1), false)
  assert.equal(rules.shouldTriggerFluMonth(5, () => 0), false)
  assert.equal(rules.rollPlayerIllnessDuration(() => 0), 6)
  assert.equal(rules.rollPlayerIllnessDuration(() => 0.999999), 8)
  assert.equal(rules.canShortenPlayerIllnessByRest({ originalDurationDays: 8, restReductionDays: 3 }), true)
  assert.equal(rules.canShortenPlayerIllnessByRest({ originalDurationDays: 8, restReductionDays: 4 }), false)
  assert.equal(rules.memberIllnessRules.fluDurationDays, 30)
  assert.equal(rules.memberIllnessRules.playerCheckIntervalDays, 7)
  assert.equal(rules.memberIllnessRules.playerDailyChance, 0.1)
  assert.equal(rules.memberIllnessRules.playerRestRecoveryChance, 0.8)
  assert.equal(rules.memberIllnessRules.playerActionPointCap, 10)
  assert.equal(rules.memberIllnessRules.playerSpiritCap, 150)
})

test('加入、日结算、半效率和玩家卧床状态均接入引擎', async () => {
  const legacy = await load('../src/game/legacy.js')
  assert.match(legacy, /weakConstitution:GAME_RULES\.shouldHaveWeakConstitution\(\)/)
  assert.match(legacy, /function memberIllnessDaily\(\)/)
  assert.match(legacy, /memberOccupied\(m\).*memberSick\(m\)/s)
  assert.match(legacy, /memberIllnessDaily\(\);specialMemberDaily\(\);productionDaily\(\);copywriterDaily\(\)/)
  assert.match(legacy, /function productionEfficiency\(m\).*memberSick\(m\).*productionMultiplier/s)
  assert.match(legacy, /rollCopywriterDailyWords[\s\S]*memberIllnessEfficiencyMultiplier/)
  assert.match(legacy, /新闻说最近流感肆虐，一定要当心了。/)
  assert.match(legacy, /我好像生病了……/)
  assert.match(legacy, /playerSick\(\)\?"卧床在家"/)
  assert.match(legacy, /unlockAchievement\("rest_while_sick"\)/)
  assert.match(legacy, /unlockAchievement\("shelve_song"\)/)
})

test('成人不显示年龄标签，未成年仍正常显示', async () => {
  const legacy = await load('../src/game/legacy.js')
  assert.match(legacy, /function ageTagHtml\(person\).*person\?\.isMinor.*未成年/s)
  assert.doesNotMatch(legacy, /isMinor\?"未成年":"成人"/)
  assert.match(legacy, /ageTagHtml\(state\.candidate\)/)
  assert.match(legacy, /ageTagHtml\(a\)/)
  assert.match(legacy, /ageTagHtml\(m\)/)
})

test('Beta58版本号与更新日期同步', async () => {
  const [index, header, legacy, economy] = await Promise.all([
    load('../index.html'), load('../src/components/AppHeader.vue'),
    load('../src/game/legacy.js'), load('../src/components/EconomyPanel.vue'),
  ])
  assert.match(index, /Beta 58/)
  assert.match(header, /Beta 58/)
  assert.match(legacy, /version:"Beta58"/)
  assert.match(economy, /最后更新日期：2026年08月26日/)
})

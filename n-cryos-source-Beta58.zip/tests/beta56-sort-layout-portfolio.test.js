import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')

test('姓名排序固定侧睡第一、shcad第二，其余使用名称排序', async () => {
  const legacy = await load('../src/game/legacy.js')
  const sorting = legacy.match(/function composerDisplayOrder\(\)[\s\S]*?\n}/)?.[0] || ''
  assert.match(sorting, /composer\.name==="侧睡"\?0:composer\.name==="shcad"\?1:2/)
  assert.match(sorting, /return pinnedRank\(a\)-pinnedRank\(b\)\|\|nameOrder\(a,b\)/)
})

test('主业与外快按钮保持紧凑、同尺寸并靠右', async () => {
  const [legacyCss, mobileCss] = await Promise.all([
    load('../src/styles/legacy.css'), load('../src/styles/mobile.css'),
  ])
  assert.match(legacyCss, /\.money-sidegig\{display:block;width:68%;min-height:42px;margin:auto 0 0 auto/)
  assert.match(mobileCss, /html\.mobile-ui \.money-sidegig \{[\s\S]*width: 74% !important;[\s\S]*min-height: 46px;[\s\S]*margin: 10px 0 0 auto !important;/)
})

test('温室花房第9作同时挂载到PICKUPNEAR和纵连大师', async () => {
  const portfolios = JSON.parse(await load('../src/data/portfolios.json'))
  const song = portfolios.find(item => item.name === '温室花房第9作：recitation')
  assert.deepEqual(song.collabComposerIds, [11,1005])
  assert.equal(song.ownerComposerId, 11)
  assert.equal(song.ownerComposerName, 'PICKUPNEAR,纵连大师')
})

test('Beta58版本号与日期同步', async () => {
  const [index, header, legacy, economy] = await Promise.all([
    load('../index.html'), load('../src/components/AppHeader.vue'),
    load('../src/game/legacy.js'), load('../src/components/EconomyPanel.vue'),
  ])
  assert.match(index, /Beta 58/)
  assert.match(header, /Beta 58/)
  assert.match(legacy, /version:"Beta58"/)
  assert.match(economy, /最后更新日期：2026年08月26日/)
})

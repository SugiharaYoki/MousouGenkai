import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import { ACHIEVEMENTS } from '../src/game/achievements.js'
import * as rules from '../src/game/rules.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')
const loadJson = async path => JSON.parse(await load(path))
const achievement = id => ACHIEVEMENTS.find(item => item.id === id)

test('六个既有成就升级为金色且保留原隐藏属性', () => {
  const expected = {
    five_real_members: true,
    four_trust: true,
    money_1m: false,
    money_10m: true,
    players_100k: true,
    players_1m: true,
  }
  for (const [id, hidden] of Object.entries(expected)) {
    assert.equal(achievement(id)?.gold, true, id)
    assert.equal(achievement(id)?.hidden, hidden, id)
  }
})

test('七个新增成就的金色与隐藏属性准确', () => {
  assert.deepEqual(
    ['solo_operator','boss_song_release','composer_collector_20','composer_collector_40','noncommercial_quality_5','formal_quality_5','library_100']
      .map(id => [id, achievement(id)?.title, achievement(id)?.hidden, achievement(id)?.gold]),
    [
      ['solo_operator','一言堂',true,true],
      ['boss_song_release','制造爆点',false,false],
      ['composer_collector_20','收集癖',false,false],
      ['composer_collector_40','集邮狂魔',true,true],
      ['noncommercial_quality_5','惊喜出金',true,false],
      ['formal_quality_5','理所应当',true,false],
      ['library_100','百曲斩',false,true],
    ],
  )
})

test('总天数使用游戏主界面的年与年内日格式', () => {
  assert.equal(rules.formatGameDate(1), '第 1 年 · 第 1 天')
  assert.equal(rules.formatGameDate(365), '第 1 年 · 第 365 天')
  assert.equal(rules.formatGameDate(366), '第 2 年 · 第 1 天')
  assert.equal(rules.formatGameDate(400), '第 2 年 · 第 35 天')
})

test('曲师平均质量只使用商业质量概率池的数学期望', () => {
  assert.equal(rules.commercialAverageQuality([0.05, 0.40, 0.45, 0.10, 0]), 2.6)
  assert.equal(rules.commercialAverageQuality([0, 0.10, 0.65, 0.25, 0]), 3.15)
  assert.equal(rules.commercialAverageQuality([0, 0, 0, 0, 0]), 3)
})

test('合作约稿在30%只判定一次并采用3/5/8概率', () => {
  assert.equal(rules.shouldTriggerCommissionCollaboration({ progress: 0.299, nature: '正式邀请', checked: false }, () => 0), false)
  assert.equal(rules.shouldTriggerCommissionCollaboration({ progress: 0.30, nature: '非商', checked: false }, () => 0.0299), true)
  assert.equal(rules.shouldTriggerCommissionCollaboration({ progress: 0.30, nature: '非商', checked: false }, () => 0.03), false)
  assert.equal(rules.shouldTriggerCommissionCollaboration({ progress: 0.30, nature: '商业', checked: false }, () => 0.0499), true)
  assert.equal(rules.shouldTriggerCommissionCollaboration({ progress: 0.30, nature: '正式邀请', checked: false }, () => 0.0799), true)
  assert.equal(rules.shouldTriggerCommissionCollaboration({ progress: 0.80, nature: '正式邀请', checked: true }, () => 0), false)
  assert.equal(rules.shouldTriggerCommissionCollaboration({ progress: 0.30, nature: '非商', checked: false, forced: true }, () => 0.99), true)
})

test('合作对象要求目标风格高于70且90%优先羁绊曲师', () => {
  const primary = { id: 1, bond: [2] }
  const candidates = [
    { id: 2, name: '羁绊', styles: { 灼热: 71 }, reachable: true, busy: false },
    { id: 3, name: '普通', styles: { 灼热: 90 }, reachable: true, busy: false },
    { id: 4, name: '刚好70', styles: { 灼热: 70 }, reachable: true, busy: false },
  ]
  assert.equal(rules.chooseCommissionCollaborator({ primary, candidates, style: '灼热' }, () => 0)?.id, 2)
  const values = [0.95, 0]
  assert.equal(rules.chooseCommissionCollaborator({ primary, candidates, style: '灼热' }, () => values.shift())?.id, 3)
})

test('四位新增曲师、羁绊和商业平均质量准确', async () => {
  const composers = await loadJson('../src/data/composers.json')
  const byName = name => composers.find(item => item.name === name)
  const expected = {
    Kalvin: [60,3,3,70,40,4000,8000,16000,2.6],
    kemomi2r: [60,4,4,60,70,7000,14000,31000,3.15],
    saikuro: [50,3,5,70,40,4000,8000,18000,2.7],
    "豹景。": [70,2,5,50,50,3000,8000,15000,2.9],
  }
  for (const [name, values] of Object.entries(expected)) {
    const c = byName(name)
    assert.ok(c, name)
    assert.deepEqual([
      c.popularity,c.abstract,c.efficiency,c.mental,c.affDifficulty,
      c.prices.非商,c.prices.商业,c.prices.正式邀请,
      rules.commercialAverageQuality(c.qualityProbs.商业),
    ], values)
  }
  assert.ok(byName('大二').bond.includes(byName('Kalvin').id))
  assert.ok(byName('ξ').bond.includes(byName('kemomi2r').id))
  assert.deepEqual(byName('Kalvin').bond, [byName('大二').id])
  assert.deepEqual(byName('kemomi2r').bond, [byName('ξ').id, byName('saikuro').id])
  assert.deepEqual(byName('saikuro').bond, [byName('kemomi2r').id])
})

test('sentinel已更名为sentry且作品归属同步', async () => {
  const [composers, portfolios] = await Promise.all([
    loadJson('../src/data/composers.json'),
    loadJson('../src/data/portfolios.json'),
  ])
  assert.equal(composers.some(item => item.name === 'sentinel'), false)
  assert.equal(composers.find(item => item.name === 'sentry')?.id, 29)
  assert.equal(portfolios.some(item => String(item.ownerComposerName).includes('sentinel')), false)
  assert.equal(portfolios.filter(item => item.collabComposerIds?.includes(29)).every(item => String(item.composerLabel).includes('sentry')), true)
})

test('37首新增作品完整，后期作品保存随机解禁区间', async () => {
  const portfolios = await loadJson('../src/data/portfolios.json')
  const names = [
    'Last Culture','Stargazer and the Moirai','End Seeker and the Moirai','F-yours','探し人','封闭的空间','Birth','乐章的开篇','Mother Planet','Fast Loading','超级恐龙时代','Fanatic Shrine','History Downloader','Space Fantasy','Bass Kick','Ultra Bass Kick','Place 2 B','Nightshift','Decoder','Everlasting Calm','-Frozen Rain-','天理','幻境迷宫','狂喜乱舞','Heart','The Rain Falls','Hallway of Reflections','Shuffling through the Wind','nerve','bomb','Butterfly','Augustus','Simulation','Librarian','Freeze the Gravity','No Way Street','Cyber Eve',
  ]
  for (const name of names) assert.ok(portfolios.find(item => item.name === name), name)
  assert.deepEqual(
    ['releaseMinDay','releaseMaxDay'].map(key => portfolios.find(item => item.name === 'Simulation')[key]),
    [1000,1100],
  )
  assert.deepEqual(portfolios.find(item => item.name === 'Last Culture').collabComposerIds, [3,1009])
  assert.equal(rules.rollPortfolioReleaseDay(500, 600, () => 0), 500)
  assert.equal(rules.rollPortfolioReleaseDay(500, 600, () => 0.999999), 600)
})

test('曲师收集按普通曲师去重并排除教程、联动和雪藏歌曲', () => {
  const ids = rules.collectedComposerIds([
    { source: 'commission', composerId: 1 },
    { source: 'portfolio', composerIds: [1, 2] },
    { source: 'tutorial', composerId: 3 },
    { source: 'collab', composerId: 4 },
    { source: 'commission', composerId: 5, shelved: true },
    { source: 'commission', composerId: 999 },
  ], [1, 2, 3, 4, 5])
  assert.deepEqual([...ids].sort((a, b) => a - b), [1, 2])
})

test('Beta64引擎接入金色成就、作品集解禁、合作决策与合作作者', async () => {
  const [legacy, css] = await Promise.all([
    load('../src/game/legacy.js'),
    load('../src/styles/legacy.css'),
  ])
  assert.match(legacy, /achievement\.gold\?"gold":"purple"/)
  assert.match(legacy, /function portfolioReleaseDaily\(/)
  assert.match(legacy, /有新的作品发布了！`,"pink"/)
  assert.match(legacy, /这首作品尚未正式发布。/)
  assert.match(legacy, /function acceptCommissionCollaboration\(/)
  assert.match(legacy, /function rejectCommissionCollaboration\(/)
  assert.match(legacy, /composerLabel=`\$\{c\.name\} vs\. \$\{collaborator\.name\}`/)
  assert.match(legacy, /gameNameRaw\(\)==="Evendel"&&commission\.commissionSequence===3/)
  assert.match(legacy, /unlockAchievement\("boss_song_release"\)/)
  assert.match(legacy, /unlockAchievement\("noncommercial_quality_5"\)/)
  assert.match(legacy, /unlockAchievement\("formal_quality_5"\)/)
  assert.match(legacy, /version:"Beta65"/)
  assert.match(css, /\.achievement-card\.gold\.unlocked/)
  assert.match(css, /\.log div\.event-pink/)
})

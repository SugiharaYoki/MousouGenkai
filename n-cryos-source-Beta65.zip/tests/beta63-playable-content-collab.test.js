import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import * as rules from '../src/game/rules.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')

test('联动歌曲无论评分多高都不能雪藏', () => {
  assert.equal(rules.canShelveSong({ rating: 80, installed: false, source: 'commission' }), true)
  assert.equal(rules.canShelveSong({ rating: 80, installed: false, source: 'collab' }), false)
})

test('联动失败只删除该次联动歌曲，不误删混入专属包的普通歌曲', () => {
  const library = [
    { id: 11, source: 'collab', collabGameName: '星环' },
    { id: 12, source: 'collab', collabGameName: '星环' },
    { id: 13, source: 'commission' },
  ]
  assert.deepEqual(rules.collabSongIdsForRemoval({
    collab: { gameName: '星环', songIds: [11, 12] },
    packageItem: { songIds: [11, 12, 13] },
    library,
  }), [11, 12])
})

test('旧存档没有联动歌曲编号时，可从专属包恢复需要删除的联动歌曲', () => {
  const library = [
    { id: 21, source: 'collab', collabGameName: '旧梦' },
    { id: 22, source: 'portfolio' },
  ]
  assert.deepEqual(rules.collabSongIdsForRemoval({
    collab: { gameName: '旧梦' },
    packageItem: { songIds: [21, 22] },
    library,
  }), [21])
})

test('Beta63界面只保留合并删除按钮，作品集隐藏封面完成度，曲包筛选显示当前状态', async () => {
  const [content, legacy] = await Promise.all([
    load('../src/components/ContentPanel.vue'),
    load('../src/game/legacy.js'),
  ])
  assert.match(content, /toggleReleasedPackagesButton[^>]+library-filter-button/)
  assert.match(content, /toggleInstalledSongsButton[^>]+library-filter-button[^>]*>已更新内容：显示</)
  assert.match(content, /已更新内容：隐藏/)
  assert.match(legacy, />删除可玩内容</)
  assert.doesNotMatch(legacy, />删除谱面</)
  assert.doesNotMatch(legacy, />删除美术</)
  assert.match(legacy, /s\.source==="portfolio"\?`谱面/)
  assert.match(legacy, /已更新内容：\$\{state\.hideReleasedPackages\?"隐藏":"显示"\}/)
  assert.match(legacy, /已更新内容：\$\{state\.hideInstalledSongs\?"隐藏":"显示"\}/)
  assert.match(legacy, /songIds:ids/)
  assert.match(legacy, /collabSongIdsForRemoval/)
  assert.match(legacy, /version:"Beta65"/)
})

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import * as rules from '../src/game/rules.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')

test('赞助好评倍率在100后降为每5点1%，并在200封顶', () => {
  const base = {
    platformEnabled: true,
    players: 1200,
    stickiness: 10,
    artPursuit: 60,
  }
  const at100 = rules.monthlySponsorshipIncome({ ...base, rating: 100 })
  const at105 = rules.monthlySponsorshipIncome({ ...base, rating: 105 })
  const at200 = rules.monthlySponsorshipIncome({ ...base, rating: 200 })
  const above200 = rules.monthlySponsorshipIncome({ ...base, rating: 300 })
  assert.ok(Math.abs(at100 - 6.3558) < 1e-9)
  assert.ok(Math.abs(at105 - 6.3907) < 1e-9)
  assert.ok(Math.abs(at200 - 7.0538) < 1e-9)
  assert.equal(above200, at200)
})

test('展会邀请遵守更新后360天、月份概率、4月15保底和70天冷却', () => {
  const base = {
    currentDay: 500,
    firstUpdateDay: 140,
    cooldownUntil: 0,
    hasPendingInvite: false,
  }
  assert.equal(rules.shouldTriggerExhibitionInvite({ ...base, month: 4, dayOfMonth: 14 }, () => 0.199), true)
  assert.equal(rules.shouldTriggerExhibitionInvite({ ...base, month: 4, dayOfMonth: 14 }, () => 0.2), false)
  assert.equal(rules.shouldTriggerExhibitionInvite({ ...base, month: 4, dayOfMonth: 15 }, () => 0.999), true)
  assert.equal(rules.shouldTriggerExhibitionInvite({ ...base, month: 8, dayOfMonth: 1 }, () => 0.029), true)
  assert.equal(rules.shouldTriggerExhibitionInvite({ ...base, month: 8, dayOfMonth: 1 }, () => 0.03), false)
  assert.equal(rules.shouldTriggerExhibitionInvite({ ...base, currentDay: 499, month: 4, dayOfMonth: 15 }, () => 0), false)
  assert.equal(rules.shouldTriggerExhibitionInvite({ ...base, cooldownUntil: 501, month: 4, dayOfMonth: 15 }, () => 0), false)
  assert.equal(rules.shouldTriggerExhibitionInvite({ ...base, firstUpdateDay: null, month: 4, dayOfMonth: 15 }, () => 0), false)
})

test('展会成员只允许2/3/5级，并执行人数、未成年陪同与工种限制', () => {
  const members = [
    { id: 1, role: 'chart', rarity: 2, isMinor: true, occupiedUntil: 0 },
    { id: 2, role: 'chart', rarity: 3, isMinor: false, occupiedUntil: 0 },
    { id: 3, role: 'art', rarity: 5, isMinor: false, occupiedUntil: 0 },
    { id: 4, role: 'copy', rarity: 3, isMinor: false, occupiedUntil: 0 },
    { id: 5, role: 'art', rarity: 4, isMinor: false, occupiedUntil: 0 },
  ]
  assert.equal(rules.validateExhibitionSelection({ members, selectedIds: [1, 3], currentDay: 10 }).ok, false)
  assert.equal(rules.validateExhibitionSelection({ members, selectedIds: [1, 2, 3], currentDay: 10 }).ok, true)
  assert.equal(rules.validateExhibitionSelection({ members, selectedIds: [2, 3, 4], currentDay: 10 }).ok, true)
  assert.equal(rules.exhibitionMemberEligible(members[4], 10), false)
})

test('展会费用按季节和超过4人的证件数结算', () => {
  assert.deepEqual(rules.exhibitionParticipationCost(4, 4), { boothFee: 4500, badgeFee: 0, total: 4500 })
  assert.deepEqual(rules.exhibitionParticipationCost(4, 6), { boothFee: 4500, badgeFee: 600, total: 5100 })
  assert.deepEqual(rules.exhibitionParticipationCost(8, 5), { boothFee: 3000, badgeFee: 300, total: 3300 })
})

test('周边限制、命名、销量、同类加成与恶劣天气收入正确', () => {
  const items = [
    { type: '徽章', name: '徽章A' },
    { type: '徽章', name: '徽章B' },
  ]
  assert.equal(rules.nextExhibitionMerchandiseName(items, '徽章'), '徽章C')
  assert.equal(rules.canAddExhibitionMerchandise(items, '徽章', 3).ok, true)
  assert.equal(rules.canAddExhibitionMerchandise([...items, { type: '徽章', name: '徽章C' }], '徽章', 4).ok, false)
  assert.deepEqual(rules.exhibitionSalesRange('徽章', 50000), { min: 3, max: 65 })
  assert.equal(rules.rollExhibitionTypeSales({ type: '徽章', itemCount: 2, players: 0 }, () => 0.999999), 20)
  const split = rules.splitExhibitionSales(20, 2, () => 0.5)
  assert.equal(split.reduce((sum, value) => sum + value, 0), 20)
  assert.equal(rules.exhibitionSalesRevenue({ units: 20, type: '徽章', badWeather: false }), 360)
  assert.equal(rules.exhibitionSalesRevenue({ units: 20, type: '徽章', badWeather: true }), 180)
  const rates = rules.exhibitionCommunityGrowthRates([{ type: '徽章' }, { type: '明信片' }])
  assert.ok(Math.abs(rates.players - 0.215) < 1e-9)
  assert.ok(Math.abs(rates.fans - 0.065) < 1e-9)
  assert.equal(rates.discussion, 0.05)
})

test('展会界面、存档状态和每日结算接入游戏', async () => {
  const [app, panel, legacy] = await Promise.all([
    load('../src/App.vue'),
    load('../src/components/ExhibitionInvitePanel.vue'),
    load('../src/game/legacy.js'),
  ])
  assert.match(app, /ExhibitionInvitePanel/)
  assert.match(panel, /exhibitionInvitePanel/)
  assert.match(panel, /剩余回应日数/)
  assert.match(legacy, /function exhibitionDaily\(/)
  assert.match(legacy, /currentExhibitionInvite/)
  assert.match(legacy, /exhibitionDaily\(\);memberOccupationDaily\(\)/)
  assert.match(legacy, /version:"Beta65"/)

  const accept = legacy.match(/function acceptExhibitionInvite\(\)[\s\S]*?\n}/)?.[0] ?? ''
  assert.ok(accept.indexOf('exhibitionEventById') < accept.indexOf('state.money-=cost.total'))
  const fire = legacy.match(/function fireMember\(id\)[\s\S]*?\n}/)?.[0] ?? ''
  assert.match(fire, /memberExhibitionProtected/)
  const remove = legacy.match(/function removeMember\(id,msg,type="normal",departureKind=null\)[\s\S]*?\n}/)?.[0] ?? ''
  assert.match(remove, /memberExhibitionProtected/)
  assert.match(legacy, /startMemberOccupation\(m,GAME_RULES\.exhibitionRules\.durationDays,\{force:true,message:false\}\)/)
})

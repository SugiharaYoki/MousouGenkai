import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import * as rules from '../src/game/rules.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')

test('歌曲归属检查以所有曲包的songIds为准，而不只信任song.packageId', () => {
  const song = { id: 7, source: 'commission', packageId: null }
  const target = { id: 2, type: '主线包', collab: false, songIds: [] }
  const packages = [
    { id: 1, type: '支线包', collab: false, songIds: [7] },
    target,
  ]
  assert.deepEqual(rules.canSongJoinPackage({ packageItem: target, song, packages }), {
    ok: false,
    reason: 'already-in-another-package',
  })
})

test('联动歌曲不能加入普通主线、支线或补充包', () => {
  const song = { id: 8, source: 'collab', packageId: null }
  const normal = { id: 2, type: '支线包', collab: false, songIds: [] }
  const collab = { id: 3, type: '支线包', collab: true, songIds: [] }
  const single = { id: 4, type: '单曲', collab: false, songIds: [] }
  assert.equal(rules.canSongJoinPackage({ packageItem: normal, song, packages: [normal] }).reason, 'collab-song-restricted')
  assert.equal(rules.canSongJoinPackage({ packageItem: collab, song, packages: [collab] }).ok, true)
  assert.equal(rules.canSongJoinPackage({ packageItem: single, song, packages: [single] }).ok, true)
})

test('三个月未更新只允许疑虑或好感低于30的空闲成员退组', () => {
  assert.equal(rules.memberCanLeaveForInactivity({ status: '疑虑', affection: 80 }), true)
  assert.equal(rules.memberCanLeaveForInactivity({ status: '正常', affection: 29.9 }), true)
  assert.equal(rules.memberCanLeaveForInactivity({ status: '正常', affection: 30 }), false)
})

test('Alpha按钮只在谱面完成且从未开始测试时显示', () => {
  assert.equal(rules.shouldShowAlphaButton({ installed: false, chartProgress: 99.9, alphaEverStarted: false, alphaStatus: 'idle' }), false)
  assert.equal(rules.shouldShowAlphaButton({ installed: false, chartProgress: 100, artProgress: 20, alphaEverStarted: false, alphaStatus: 'idle' }), true)
  assert.equal(rules.shouldShowAlphaButton({ installed: false, chartProgress: 100, alphaEverStarted: true, alphaStatus: 'idle' }), false)
  assert.equal(rules.shouldShowAlphaButton({ installed: false, chartProgress: 100, alphaEverStarted: true, alphaStatus: 'completed' }), false)
})

test('Alpha完成后删除可玩内容会同时清空谱面和美术，作品集保留默认封面', () => {
  const original = {
    source: 'commission',
    chartProgress: 100,
    artProgress: 100,
    playableQuality: 88,
    _chartCraftLevel: 4,
    _artCraftLevel: 3,
  }
  const deleted = rules.songAfterPlayableContentDeletion(original)
  assert.equal(deleted.chartProgress, 0)
  assert.equal(deleted.artProgress, 0)
  assert.equal(deleted.playableQuality, null)
  assert.equal(deleted.alphaContentInvalidated, true)
  assert.equal(deleted._chartCraftLevel, null)
  assert.equal(deleted._artCraftLevel, null)
  const portfolioDeleted = rules.songAfterPlayableContentDeletion({ ...original, source: 'portfolio' })
  assert.equal(portfolioDeleted.chartProgress, 0)
  assert.equal(portfolioDeleted.artProgress, 100)
  assert.equal(rules.shouldLoseAffectionAfterAlphaContentDeletion(79.99), true)
  assert.equal(rules.shouldLoseAffectionAfterAlphaContentDeletion(80), false)
  assert.equal(rules.songContentReadyForBeta({ alpha: true, alphaStatus: 'completed', alphaContentInvalidated: true, chartProgress: 0, artProgress: 100 }), false)
})

test('曲包命名、上线筛选与Alpha删除操作已接入界面', async () => {
  const [content, legacy] = await Promise.all([
    load('../src/components/ContentPanel.vue'),
    load('../src/game/legacy.js'),
  ])
  assert.match(content, /toggleReleasedPackagesButton/)
  assert.match(legacy, /function renamePackage\(/)
  assert.match(legacy, /function deletePlayableContent\(/)
  assert.doesNotMatch(legacy, /deleteAlphaContent\(/)
  assert.match(legacy, /canSongJoinPackage/)
  assert.match(legacy, /version:"Beta65"/)
})

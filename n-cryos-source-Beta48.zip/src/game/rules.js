export const hiddenMemberRules = Object.freeze({
  minorRecruitChanceByLevel: Object.freeze({
    1: 0.8,
    2: 0.6,
    3: 0.4,
    4: 0,
    5: 0.5,
  }),
  adulthoodTransitionMinDays: 720,
  adulthoodTransitionMaxDays: 1080,
  potentialInsiderChance: 0.03,
  minorPotentialInsiderChance: 0.06,
  potentialInsiderMaturityDays: 180,
  protectedRarity: 3,
})

export const LEVEL5_COPY_REAL_NAMES = Object.freeze(['杂合子', 'Kozak'])

export const collabGamePools = Object.freeze({
  common: Object.freeze([
    'Arcade', 'Dynamite', 'Grapetus', 'Rotation', '黄金比律', '酸梅游戏', 'Milthm',
    'DotOrNot', 'TheNote', '咪赛猫', '黄昏冲刺', 'DemoPiano', '律动点线',
  ]),
  rare: Object.freeze([
    'Roller Ghoster', 'Deluxe舞', '音浪革命', '中二病', '华丽音舞', '流行N音乐',
    '卫星韵律', '节奏Dash', '火与水的交响乐', '极限DJ',
  ]),
})

export function isGuaranteedAdultMember({ name, role, rarity }) {
  return role === 'copy'
    && Number(rarity) === 5
    && LEVEL5_COPY_REAL_NAMES.includes(name)
}

export function applyStoryAllocation({ availableWords, wordCap }, amount) {
  const spent = Math.max(0, Number(amount) || 0)
  return {
    availableWords: Math.max(0, (Number(availableWords) || 0) - spent),
    wordCap: Math.max(0, (Number(wordCap) || 0) - spent),
  }
}

export function refundStoryAllocation({ availableWords, wordCap }, amount) {
  const refunded = Math.max(0, Number(amount) || 0)
  return {
    availableWords: Math.max(0, (Number(availableWords) || 0) + refunded),
    wordCap: Math.max(0, (Number(wordCap) || 0) + refunded),
  }
}

export function expectationReleaseOutcome({ actual, expected }) {
  const ratio = (Number(actual) || 0) / Math.max(1, Number(expected) || 0)
  if (ratio < 0.5) {
    return {
      tier: 'severe-miss',
      ratio,
      expectationMultiplier: 1,
      releaseMultipliers: { attention: 0.7, play: 0.65, good: 0.7, discussion: 1.5 },
      discussionDecayFactor: 1 / 1.5,
      discussionDecayDays: 14,
    }
  }
  if (ratio < 0.8) {
    return {
      tier: 'miss',
      ratio,
      expectationMultiplier: 1,
      releaseMultipliers: { attention: 0.85, play: 0.82, good: 0.85, discussion: 1.25 },
      discussionDecayFactor: 1 / 1.25,
      discussionDecayDays: 60,
    }
  }
  if (Math.abs(ratio - 1) < 0.05) {
    return {
      tier: 'met',
      ratio,
      expectationMultiplier: 1,
      releaseMultipliers: { attention: 1, play: 1.05, good: 1, discussion: 1 },
    }
  }
  if (ratio > 1.3) {
    return {
      tier: 'outstanding',
      ratio,
      expectationMultiplier: 1.05,
      releaseMultipliers: { attention: 1.12, play: 1, good: 1.08, discussion: 1 },
    }
  }
  return {
    tier: 'neutral',
    ratio,
    expectationMultiplier: 1,
    releaseMultipliers: { attention: 1, play: 1, good: 1, discussion: 1 },
  }
}

export function rollCollabOffer(day, random = Math.random) {
  const commonWeight = collabGamePools.common.length * 4
  const rareWeight = collabGamePools.rare.length
  const tierRoll = boundedRandom(random) * (commonWeight + rareWeight)
  const tier = tierRoll < commonWeight ? 'common' : 'rare'
  const pool = collabGamePools[tier]
  const gameName = pool[Math.min(pool.length - 1, Math.floor(boundedRandom(random) * pool.length))]
  const songCount = tier === 'common'
    ? randomIntegerInclusive(2, 3, random)
    : randomIntegerInclusive(4, 5, random)
  const graceDays = tier === 'common'
    ? randomIntegerInclusive(180, 270, random)
    : randomIntegerInclusive(365, 540, random)
  return {
    tier,
    gameName,
    songCount,
    forcedDeadline: Math.max(1, Math.floor(Number(day) || 1)) + graceDays,
  }
}

function boundedRandom(random) {
  return Math.min(0.999999999999, Math.max(0, Number(random()) || 0))
}

export const betaLeakRules = Object.freeze({
  baseDailyChance: 0.0012,
  perLeakerDailyChance: 0.001,
  sideAndSingleMultiplier: 3,
  cooldownDays: 30,
  discussionBuffMultiplier: 1.2,
  discussionBuffDays: 30,
  releaseDiscussionMultiplier: 0.8,
  nextBetaDelayMin: 1,
  nextBetaDelayMax: 3,
})

export const lewdImageRules = Object.freeze({
  alternateCopyChance: 0.5,
  followupChance: 0.15,
  followupMinimumAffectionExclusive: 45,
  followupAffectionCap: 75,
})

export function shouldScheduleLewdImageFollowup(affection) {
  return Number(affection) > lewdImageRules.followupMinimumAffectionExclusive
}

export function lewdImageFollowupAffection(affection) {
  const current = Math.max(0, Number(affection) || 0)
  if (current >= lewdImageRules.followupAffectionCap) return current
  return Math.min(lewdImageRules.followupAffectionCap, current + 1)
}

export function memberProtectedFromInactivityDeparture({ currentDay, actualJoinDay }) {
  return Math.max(0, (Number(currentDay) || 0) - (Number(actualJoinDay) || 0)) < 90
}

export function teamExplosionSongLimit(memberCount) {
  const count = Math.max(0, Number(memberCount) || 0)
  if (count < 10) return 1
  if (count < 15) return 2
  return 3
}

export function teamExplosionDefuseChance(highAffectionMemberCount) {
  const count = Math.max(0, Math.floor(Number(highAffectionMemberCount) || 0))
  return count > 0 ? Math.round(Math.min(0.6, 0.1 + count * 0.05) * 1_000_000) / 1_000_000 : 0
}

export function personalArtQualityAfterPenalty(quality, penalty = 0.7) {
  const current = Number(quality) || 0
  if (current <= 45) return current
  return Math.round(Math.max(45, current - Math.max(0, Number(penalty) || 0)) * 1000) / 1000
}

export function firstReleaseTier(actualQuality) {
  const actual = Number(actualQuality) || 0
  if (actual < 50) return 'bad'
  if (actual <= 73) return 'normal'
  return 'perfect'
}

export function collabAvailableFromYear(yearIndex) {
  return Number(yearIndex) >= 1
}

export function shouldForceCollabOffer({ day, everTriggered }) {
  return Number(day) >= 700 && !everTriggered
}

export function formatCollabSongTitle(gameName, songTitle) {
  return `《${gameName}》联动·${songTitle}`
}

export const scoreTrackerRules = Object.freeze({
  playerThreshold: 2500,
  playerGrowthMultiplier: 1.01,
  failureDelayMinDays: 7,
  failureDelayMaxDays: 15,
  repairGainMin: 5,
  repairGainMax: 10,
  techForMaxRepairGain: 20,
})

export function scoreTrackerGrowthMultiplier({ hasScoreTracker, isBroken }) {
  return hasScoreTracker && !isBroken ? scoreTrackerRules.playerGrowthMultiplier : 1
}

export function rollScoreTrackerFailureDelay(random = Math.random) {
  return randomIntegerInclusive(
    scoreTrackerRules.failureDelayMinDays,
    scoreTrackerRules.failureDelayMaxDays,
    random,
  )
}

export function scoreTrackerRepairGain(tech) {
  const progress = Math.min(1, Math.max(0, Number(tech) || 0) / scoreTrackerRules.techForMaxRepairGain)
  const gain = scoreTrackerRules.repairGainMin
    + (scoreTrackerRules.repairGainMax - scoreTrackerRules.repairGainMin) * progress
  return Math.round(gain * 1000) / 1000
}

export const FIRE_MEMBER_ACTION_COST = 3

export function copyWritingSpiritCost(yearIndex) {
  return Math.min(60, 5 * (Math.max(0, Math.floor(Number(yearIndex) || 0)) + 1))
}

export const copywriterRules = Object.freeze({
  unlockCopyActions: 10,
  unlockMemberCountExclusive: 5,
  initialStoryWordCap: 5000,
  doubtIdleDaysMultiplier: 3,
  doubtRecoveryWords: 500,
  doubtIdleProgressLoss: 20,
  promotionWordsByLevel: Object.freeze({ 1: 5000, 2: 10000 }),
  motivationDays: 7,
  motivationMultiplierByLevel: Object.freeze({ 1: 1.5, 2: 1.4, 3: 1.3, 4: 1.3, 5: 1.3 }),
  fullTenureGrowthDays: 720,
  packageStoryStep: 1000,
  packageStoryPerSong: 2000,
  packageStoryMax: 20000,
  packageExpectationMultiplier: 0.98,
  seniorEventChanceMultiplier: 1.3,
  seniorEventPreferredChance: 0.8,
  seniorCommissionBonus: 0.001,
  seniorExpediteBonus: 0.0015,
})

export const memberAffectionRules = Object.freeze({
  initial: 15,
  maximum: 100,
  naturalDecay: 1,
  trustFloor: 80,
  doubtDailyLoss: 0.2,
  normalDoubtDepartureDays: 15,
  friendlyDoubtDepartureDays: 45,
})

export function memberAffectionLabel(value) {
  const affection = Number(value) || 0
  if (affection < 20) return '陌生'
  if (affection < 50) return '普通'
  if (affection < 80) return '朋友'
  return '信任'
}

export function nextMemberAffection(member, delta, options = {}) {
  const current = Math.min(memberAffectionRules.maximum, Math.max(0, Number(member?.affection) || 0))
  const trustLocked = !!member?.trustLocked || current >= memberAffectionRules.trustFloor
  const change = Number(delta) || 0
  const positiveCap = Number.isFinite(options.positiveCap)
    ? Math.max(0, Number(options.positiveCap))
    : memberAffectionRules.maximum
  let affection
  if (change > 0 && current >= positiveCap) affection = current
  else affection = Math.min(memberAffectionRules.maximum, Math.max(0, current + change))
  if (change > 0) affection = Math.min(affection, Math.max(current, positiveCap))
  if (options.natural && trustLocked && current >= memberAffectionRules.trustFloor) {
    affection = Math.max(memberAffectionRules.trustFloor, affection)
  }
  affection = Math.round(affection * 1000) / 1000
  return {
    affection,
    trustLocked: affection >= memberAffectionRules.trustFloor
      ? true
      : change < 0 && !options.natural
        ? false
        : trustLocked && options.natural,
  }
}

export function memberCanEnterDoubt(affection) {
  return Number(affection) <= 80
}

export function memberShouldConfessLeak(member) {
  return !!member?.leaker && !member?.confessedLeak && Number(member?.affection) > 80
}

export function memberDoubtDepartureDays(affection) {
  return Number(affection) > 50
    ? memberAffectionRules.friendlyDoubtDepartureDays
    : memberAffectionRules.normalDoubtDepartureDays
}

export function memberRecoveryChanceBonus(affection) {
  return Math.max(0, Math.floor((Math.min(100, Number(affection) || 0) - 30) / 10)) / 100
}

export function memberWorkPlayableBonus(affection) {
  return Math.max(0, Math.floor(((Number(affection) || 0) - 50) / 3)) * 0.1
}

export function memberSongQualityAffectionGain(quality) {
  const normalizedQuality = Number(quality) || 0
  if (normalizedQuality >= 6) return 2.5
  if (normalizedQuality >= 5) return 2
  if (normalizedQuality >= 4) return 1
  return 0
}

export function takeoutSpiritRecovery(isTrendyTakeout) {
  return isTrendyTakeout ? 20 : 25
}

export function canUnlockCopywriterRecruitment(copyActionCount, memberCount) {
  return Number(copyActionCount) >= copywriterRules.unlockCopyActions
    && Number(memberCount) > copywriterRules.unlockMemberCountExclusive
}

export function copywriterMotivationMultiplier(level) {
  const normalizedLevel = Math.min(5, Math.max(1, Math.round(Number(level) || 1)))
  return copywriterRules.motivationMultiplierByLevel[normalizedLevel]
}

export function copywriterDailyWordRange(input) {
  const options = typeof input === 'object' && input !== null ? input : { level: input }
  const level = Math.min(5, Math.max(1, Math.round(Number(options.level) || 1)))
  const tenureDays = Math.max(0, Number(options.tenureDays) || 0)
  const totalWords = Math.max(0, Number(options.totalWords) || 0)
  const matureMin = Math.round(5 + (30 - 5) * ((level - 1) / 4))
  const matureMax = Math.round(100 + (350 - 100) * ((level - 1) / 4))
  const noviceMax = [0, 10, 40, 80, 120, 160][level]
  const wordTarget = [0, 5000, 10000, 20000, 35000, 50000][level]
  const tenureGrowth = Math.min(1, tenureDays / copywriterRules.fullTenureGrowthDays)
  const writingGrowth = Math.min(1, totalWords / wordTarget)
  const experience = Math.min(1, tenureGrowth * 0.35 + writingGrowth * 0.65)
  const multiplier = options.motivated ? copywriterMotivationMultiplier(level) : 1
  return [
    Math.max(1, Math.round(matureMin * multiplier)),
    Math.max(1, Math.round((noviceMax + (matureMax - noviceMax) * experience) * multiplier)),
  ]
}

export function rollCopywriterDailyWords(input, random = Math.random) {
  const [min, max] = copywriterDailyWordRange(input)
  return randomIntegerInclusive(min, max, random)
}

export function promotedCopywriterLevel(level, totalWords) {
  const normalizedLevel = Math.min(5, Math.max(1, Math.round(Number(level) || 1)))
  const threshold = copywriterRules.promotionWordsByLevel[normalizedLevel]
  return threshold !== undefined && Number(totalWords) >= threshold ? normalizedLevel + 1 : normalizedLevel
}

export function rollStoryCapacityGain(source, quality, random = Math.random) {
  const range = source === 'portfolio'
    ? [200, 800]
    : source === 'commission'
      ? [1200, 2500]
      : null
  if (!range) return 0
  const normalizedQuality = (Math.min(5, Math.max(1, Number(quality) || 1)) - 1) / 4
  const rawRoll = Math.min(0.999999999999, Math.max(0, Number(random()) || 0))
  const qualityBiasedRoll = Math.pow(rawRoll, 1.6 - normalizedQuality * 1.2)
  return Math.floor(qualityBiasedRoll * (range[1] - range[0] + 1)) + range[0]
}

export function packageStoryCapacity(songCount) {
  return Math.min(
    copywriterRules.packageStoryMax,
    Math.max(0, Math.floor(Number(songCount) || 0)) * copywriterRules.packageStoryPerSong,
  )
}

export function remainingStoryWritingCapacity({ cap, availableWords }) {
  return Math.max(0, (Number(cap) || 0) - (Number(availableWords) || 0))
}

export function updateCopywriterDoubtProgress({ current, written, isIdle }) {
  const progress = isIdle
    ? Math.max(0, (Number(current) || 0) - copywriterRules.doubtIdleProgressLoss)
    : Math.min(copywriterRules.doubtRecoveryWords, (Number(current) || 0) + Math.max(0, Number(written) || 0))
  return { progress, recovered: progress >= copywriterRules.doubtRecoveryWords }
}

export function seniorCopywriterCommissionBonus(count) {
  return Math.round(Math.max(0, Number(count) || 0) * copywriterRules.seniorCommissionBonus * 1_000_000) / 1_000_000
}

export function seniorCopywriterExpediteBonus(count) {
  return Math.round(Math.max(0, Number(count) || 0) * copywriterRules.seniorExpediteBonus * 1_000_000) / 1_000_000
}

export function copyActionEventChance(baseChance, hasSeniorCopywriter) {
  return Math.min(1, Math.max(0, Number(baseChance) || 0) * (hasSeniorCopywriter ? copywriterRules.seniorEventChanceMultiplier : 1))
}

export function getMinorRecruitChance(level) {
  return hiddenMemberRules.minorRecruitChanceByLevel[Number(level)] ?? 0
}

export function memberStartsAsMinor(level, random = Math.random) {
  return random() < getMinorRecruitChance(level)
}

export function getAdultTransitionDays(random = Math.random) {
  return randomIntegerInclusive(
    hiddenMemberRules.adulthoodTransitionMinDays,
    hiddenMemberRules.adulthoodTransitionMaxDays,
    random,
  )
}

export function getMinorEventRateMultiplier({ level, isMinor }) {
  if (!isMinor) return 0
  return Number(level) === 3 || Number(level) === 5 ? 0.4 : 1
}

export function getMadnessRateMultiplier({ isMinor }) {
  return isMinor ? 1.3 : 1
}

export function shouldShowArtLearningProgress(progress) {
  return Number(progress) < 100
}

export function shouldBecomePotentialInsider({ rarity, isMinor, random = Math.random }) {
  if (Number(rarity) === hiddenMemberRules.protectedRarity) return false
  const probability = isMinor
    ? hiddenMemberRules.minorPotentialInsiderChance
    : hiddenMemberRules.potentialInsiderChance
  return random() < probability
}

export function betaLeakChance(packageType, activeLeakerCount) {
  const base = betaLeakRules.baseDailyChance
    + betaLeakRules.perLeakerDailyChance * Math.max(0, Number(activeLeakerCount) || 0)
  const multiplier = packageType === '支线包' || packageType === '单曲'
    ? betaLeakRules.sideAndSingleMultiplier
    : 1
  return Math.min(1, base * multiplier)
}

export function randomIntegerInclusive(min, max, random = Math.random) {
  const low = Math.ceil(min)
  const high = Math.floor(max)
  const roll = Math.min(0.999999999999, Math.max(0, Number(random()) || 0))
  return Math.floor(roll * (high - low + 1)) + low
}

export function absoluteGameDay(yearIndex, month, day) {
  return Number(yearIndex) * 365 + (Number(month) - 1) * 30 + Number(day)
}

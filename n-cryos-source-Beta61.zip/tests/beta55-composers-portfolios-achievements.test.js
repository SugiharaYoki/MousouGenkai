import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import { ACHIEVEMENTS } from '../src/game/achievements.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')
const loadJson = async path => JSON.parse(await load(path))

test('三位新增曲师的核心数值与质量分布准确', async () => {
  const composers = await loadJson('../src/data/composers.json')
  const byName = name => composers.find(item => item.name === name)

  assert.deepEqual(
    ['country','popularity','abstract','avgQuality','efficiency','mental','affDifficulty'].map(key => byName('MAYONNAISE')[key]),
    ['日本',80,4,4,3,100,90],
  )
  assert.deepEqual(byName('MAYONNAISE').prices, { 非商: 10000, 商业: 18000, 正式邀请: 28000 })
  assert.deepEqual(byName('MAYONNAISE').styles, { 灼热: 100, 抒情: 60, 冷冽: 0 })
  assert.deepEqual(byName('MAYONNAISE').qualityProbs, {
    非商: [0,.1,.8,.1,0], 商业: [0,0,.7,.25,.05], 正式邀请: [0,0,0,.85,.15],
  })

  assert.deepEqual(
    ['country','popularity','abstract','avgQuality','efficiency','mental','affDifficulty'].map(key => byName('未确认生物体')[key]),
    ['日本',60,2,3,4,60,40],
  )
  assert.deepEqual(byName('未确认生物体').qualityProbs, {
    非商: [0,.5,.4,.1,0], 商业: [0,0,.6,.35,.05], 正式邀请: [0,0,.3,.6,.1],
  })

  assert.deepEqual(
    ['country','popularity','abstract','avgQuality','efficiency','mental','affDifficulty'].map(key => byName('soul listener')[key]),
    ['韩国',70,3,4,3,80,50],
  )
  assert.deepEqual(byName('soul listener').qualityProbs, {
    非商: [0,0,.5,.45,.05], 商业: [0,0,.2,.7,.1], 正式邀请: [0,0,0,.8,.2],
  })
})

test('九首新增作品的数值与合作曲师归属准确', async () => {
  const portfolios = await loadJson('../src/data/portfolios.json')
  const byName = name => portfolios.find(item => item.name === name)
  const metrics = name => ['price','quality','abstract','style','attention','discussion','good'].map(key => byName(name)[key])

  assert.deepEqual(metrics('天妇罗'), [5000,5,4,'灼热',40,70,90])
  assert.deepEqual(metrics('Best World'), [5886,4,3,'灼热',60,10,70])
  assert.deepEqual(metrics('Best Luck'), [5886,4,2,'灼热',60,10,70])
  assert.deepEqual(metrics('Best Human'), [5886,4,4,'灼热',60,10,70])
  assert.deepEqual(metrics('Power Assault'), [8000,5,4,'灼热',70,10,80])
  assert.deepEqual(metrics('Yggdrasil'), [5000,4,2,'抒情',40,50,70])
  assert.deepEqual(metrics('Re-start a Dream'), [10000,5,2,'灼热',70,90,80])
  assert.deepEqual(metrics('Card Mystery'), [24000,5,5,'灼热',100,100,80])
  assert.deepEqual(metrics('Memories of a City'), [3000,4,2,'抒情',10,30,80])
  assert.deepEqual(byName('Re-start a Dream').collabComposerIds, [15,1007])
  assert.deepEqual(byName('Card Mystery').collabComposerIds, [15,1007,21,28])
})

test('偏执爱好仅在曲库总数超过15后判断风格断档领先', async () => {
  const legacy = await load('../src/game/legacy.js')
  assert.match(legacy, /countedLibrary\.length>15&&STYLE\.some\(style=>styleCounts\[style\]>/)
  assert.match(legacy, /song\.source!=="tutorial"&&song\.style===style/)
})

test('重金建仓与一石多鸟按实付金额和合作作者数触发', async () => {
  const legacy = await load('../src/game/legacy.js')
  const expensive = ACHIEVEMENTS.find(item => item.id === 'expensive_commission')
  const collaboration = ACHIEVEMENTS.find(item => item.id === 'portfolio_collaboration')
  assert.equal(expensive?.title, '重金建仓')
  assert.equal(collaboration?.title, '一石多鸟')
  assert.match(legacy, /\(Number\(x\.pricePaid\)\|\|0\)>=20000\)unlockAchievement\("expensive_commission"\)/)
  assert.match(legacy, /\(p\.collabComposerIds\|\|\[\]\)\.length>1\)unlockAchievement\("portfolio_collaboration"\)/)
  assert.match(legacy, /quality:Number\.isFinite\(Number\(p\.quality\)\)\?Number\(p\.quality\)/)
})

test('主业和存款卡片采用相同字号与按钮尺寸', async () => {
  const [legacyCss, mobileCss] = await Promise.all([
    load('../src/styles/legacy.css'),
    load('../src/styles/mobile.css'),
  ])
  assert.match(legacyCss, /\.money-card \.v,\.job-card \.v\{min-height:30px;font-size:23px/)
  assert.match(legacyCss, /\.money-sidegig\{display:block;width:68%;min-height:42px;margin:auto 0 0 auto/)
  assert.match(mobileCss, /html\.mobile-ui \.money-card \.v,[\s\S]*html\.mobile-ui \.job-card \.v/)
  assert.doesNotMatch(mobileCss, /\.job-value\s*\{\s*font-size:/)
})

test('当前版本号和更新日期已同步', async () => {
  const [index, header, legacy, economy] = await Promise.all([
    load('../index.html'), load('../src/components/AppHeader.vue'),
    load('../src/game/legacy.js'), load('../src/components/EconomyPanel.vue'),
  ])
  assert.match(index, /Beta 61/)
  assert.match(header, /Beta 61/)
  assert.match(legacy, /version:"Beta61"/)
  assert.match(economy, /最后更新日期：2026年08月26日/)
})

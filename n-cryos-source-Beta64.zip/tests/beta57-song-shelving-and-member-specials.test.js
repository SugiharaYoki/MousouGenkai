import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

import * as rules from '../src/game/rules.js'

const load = path => readFile(new URL(path, import.meta.url), 'utf8')

test('组员点曲与社区赞助点曲可以在固定随机数下稳定触发', () => {
  assert.equal(rules.shouldTriggerMemberSongRequest({
    day: 366,
    cooldownUntil: 0,
    eligibleMemberCount: 1,
    availableComposerCount: 1,
  }, () => 0), true)
  assert.equal(rules.shouldTriggerMemberSongRequest({
    day: 365,
    cooldownUntil: 0,
    eligibleMemberCount: 1,
    availableComposerCount: 1,
  }, () => 0), false)
  assert.equal(rules.shouldTriggerMemberSongRequest({
    day: 500,
    cooldownUntil: 520,
    eligibleMemberCount: 1,
    availableComposerCount: 1,
  }, () => 0), false)

  assert.equal(rules.shouldTriggerSponsorSongRequest({
    day: 500,
    cooldownUntil: 0,
    sponsorIncome: 501,
    availableComposerCount: 1,
  }, () => 0), true)
  assert.equal(rules.shouldTriggerSponsorSongRequest({
    day: 500,
    cooldownUntil: 0,
    sponsorIncome: 500,
    availableComposerCount: 1,
  }, () => 0), false)
})

test('两个点曲事件接入每日结算，并使用不会倒数错位的绝对冷却日', async () => {
  const legacy = await load('../src/game/legacy.js')
  assert.match(legacy, /shouldTriggerMemberSongRequest/)
  assert.match(legacy, /recommendCommissionCooldown=state\.day\+45/)
  assert.match(legacy, /shouldTriggerSponsorSongRequest/)
  assert.match(legacy, /mysteryDonationCooldown=state\.day\+90/)
  assert.match(legacy, /recommendationCommissionDaily\(\);mysteryDonationDaily\(\)/)
})

test('创作欲高约稿的成品质量至少为3级，包括旧存档中的在途委托', () => {
  assert.equal(rules.creativeDesireMinimumQuality(1, true), 3)
  assert.equal(rules.creativeDesireMinimumQuality(2, true), 3)
  assert.equal(rules.creativeDesireMinimumQuality(5, true), 5)
  assert.equal(rules.creativeDesireMinimumQuality(1, false), 1)
})

test('雪藏只对好评超过50的未上架歌曲开放，且雪藏歌曲不计入曲库总数', () => {
  assert.equal(rules.canShelveSong({ rating: 50.1, installed: false }), true)
  assert.equal(rules.canShelveSong({ rating: 50, installed: false }), false)
  assert.equal(rules.canShelveSong({ rating: 80, installed: true }), false)
  assert.equal(rules.countActiveLibrarySongs([
    { shelved: false },
    { shelved: true },
    {},
  ]), 2)
})

test('曲库有独立雪藏视图，雪藏曲只保留删除和恢复操作', async () => {
  const [content, legacy] = await Promise.all([
    load('../src/components/ContentPanel.vue'),
    load('../src/game/legacy.js'),
  ])
  assert.match(content, /id="toggleShelvedSongsButton"/)
  assert.match(legacy, /function shelveSong\(id\)/)
  assert.match(legacy, /function restoreShelvedSong\(id\)/)
  assert.match(legacy, /function deleteShelvedSong\(id\)/)
  assert.match(legacy, /state\.showShelvedSongs\?state\.library\.filter\(s=>s\.shelved\)/)
  assert.match(legacy, /onclick="deleteShelvedSong\(\$\{s\.id\}\)"[\s\S]*onclick="restoreShelvedSong\(\$\{s\.id\}\)"/)
})

test('特殊成员帮助事件使用正确门槛、概率与冷却', () => {
  assert.equal(rules.canSuperWorkbookHelp({ tenureDays: 61, daysSinceLastTrigger: 7, alreadyQueued: false }), true)
  assert.equal(rules.canSuperWorkbookHelp({ tenureDays: 60, daysSinceLastTrigger: 7, alreadyQueued: false }), false)
  assert.equal(rules.canWeeklySpecialMemberHelp({ tenureDays: 61, daysSinceLastCheck: 7, daysSinceLastTrigger: 30 }), true)
  assert.equal(rules.canWeeklySpecialMemberHelp({ tenureDays: 61, daysSinceLastCheck: 6, daysSinceLastTrigger: 30 }), false)
  assert.equal(rules.canRedMioAutoJoin({ tenureDays: 91, assignedSongCount: 2 }), true)
  assert.equal(rules.canRedMioAutoJoin({ tenureDays: 90, assignedSongCount: 2 }), false)
})

test('超级练习册、nanakaria与Kiyotsuki的精确提示文案接入逻辑', async () => {
  const legacy = await load('../src/game/legacy.js')
  assert.match(legacy, /成员超级练习册觉得你这样写不太对。经过了他的指导，下一次写程序不消耗行动力。/)
  assert.match(legacy, /成员nanakaria私信说自己心血来潮画了1张衍生图。她将图发给了你，你觉得相当不错。/)
  assert.match(legacy, /成员Kiyotsuki私信说他灵感爆棚，帮《\$\{gameName\(\)\}》写了一段剧情。他发给你阅读后，你觉得可以用上。/)
  assert.match(legacy, /specialMemberDaily\(\);productionDaily\(\)/)
})

test('Ariayaka可无视好感进入调停池，爬爬只在搬屎分支优先', async () => {
  const legacy = await load('../src/game/legacy.js')
  const ariayaka = { name: 'Ariayaka', affection: 1, occupiedUntil: 0 }
  assert.deepEqual(rules.teamArgumentPeacemakerCandidates([ariayaka], 10), [ariayaka])
  assert.equal(ariayaka.affection, 1)
  assert.match(legacy, /teamArgumentPeacemakerCandidates\(state\.members,state\.day\)/)
  assert.match(legacy, /movingWaste[\s\S]*m\.name==="爬爬"/)
  assert.match(legacy, /movingWaste[\s\S]*m\.name==="Iblcya"/)
})

test('成员当前喜好持续90天并使用等级对应的质量倍率', () => {
  assert.equal(rules.memberPreferenceRules.durationDays, 90)
  assert.equal(rules.memberPreferenceQualityMultiplier(1), 1.10)
  assert.equal(rules.memberPreferenceQualityMultiplier(3), 1.10)
  assert.equal(rules.memberPreferenceQualityMultiplier(4), 1.15)
  assert.equal(rules.memberPreferenceQualityMultiplier(5), 1.15)
  assert.equal(rules.applyMemberPreferenceQuality(90, 1.15), 98)
  assert.equal(rules.applyMemberPreferenceQuality(99, 1.15), 99)
})

test('谱面60%与美术50%之后锁定分配，亲自支援取决于平均好感', () => {
  assert.equal(rules.roleAssignmentLocked('chart', 60), false)
  assert.equal(rules.roleAssignmentLocked('chart', 60.01), true)
  assert.equal(rules.roleAssignmentLocked('art', 50), false)
  assert.equal(rules.roleAssignmentLocked('art', 50.01), true)
  assert.equal(rules.canPersonallySupportLockedRole('chart', 60.01, 50), false)
  assert.equal(rules.canPersonallySupportLockedRole('chart', 60.01, 50.01), true)
  assert.equal(rules.canPersonallySupportLockedRole('art', 50.01, 80), false)
  assert.equal(rules.canPersonallySupportLockedRole('art', 50.01, 80.01), true)
})

test('投其所好与可靠支援成就已注册并在对应操作解锁', async () => {
  const [achievements, legacy] = await Promise.all([
    load('../src/game/achievements.js'),
    load('../src/game/legacy.js'),
  ])
  assert.match(achievements, /id: 'matching_style', title: '投其所好'/)
  assert.match(achievements, /id: 'reliable_support', title: '可靠支援'/)
  assert.match(legacy, /unlockAchievement\("matching_style"\)/)
  assert.match(legacy, /unlockAchievement\("reliable_support"\)/)
})

test('Beta64版本号与更新日期同步', async () => {
  const [index, header, legacy, economy] = await Promise.all([
    load('../index.html'), load('../src/components/AppHeader.vue'),
    load('../src/game/legacy.js'), load('../src/components/EconomyPanel.vue'),
  ])
  assert.match(index, /Beta 64/)
  assert.match(header, /Beta 64/)
  assert.match(legacy, /version:"Beta64"/)
  assert.match(economy, /最后更新日期：2026年08月27日/)
})

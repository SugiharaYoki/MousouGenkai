<script setup>
import { useLegacyActions } from '../composables/useLegacyActions'

const { invoke } = useLegacyActions()
</script>

<template>
  <section class="panel mobile-content">
    <div class="tabs" role="tablist" aria-label="内容管理">
      <button class="tab active touch-control" type="button" data-view="composerView" role="tab" @click="invoke('showTab', $event.currentTarget)">联系曲师</button>
      <button class="tab touch-control" type="button" data-view="libraryView" role="tab" @click="invoke('showTab', $event.currentTarget)">管理曲库</button>
      <button class="tab touch-control" type="button" data-view="packageView" role="tab" @click="invoke('showTab', $event.currentTarget)">规划与更新</button>
      <button class="tab touch-control" type="button" data-view="collabView" role="tab" @click="invoke('showTab', $event.currentTarget)">联动</button>
    </div>
    <div id="composerView" class="view active">
      <div class="content-view-heading"><div><h2 class="section-heading">曲师与作品</h2><p class="sub">先选择委托类型与风格，再查看曲师擅长领域和可收录作品。</p></div></div>
      <section id="activeComposerCommissions" class="active-composer-commissions" hidden>
        <div class="active-commission-heading">
          <div><span class="active-commission-kicker">IN PRODUCTION</span><h3>当前正在创作委托的曲师</h3></div>
          <span id="activeCommissionCount" class="active-commission-count"></span>
        </div>
        <div id="activeCommissionList" class="active-commission-list"></div>
      </section>
      <div id="composers" class="list composer-list"></div>
    </div>
    <div id="libraryView" class="view">
      <div class="content-view-heading library-heading">
        <h2 class="section-heading">曲库</h2>
        <button id="toggleInstalledSongsButton" class="touch-control library-filter-button" type="button" aria-pressed="false" @click="invoke('toggleInstalledSongsVisibility')">隐藏已上架</button>
      </div>
      <div class="sub content-note">谱面与美术都完成后可选择 Alpha；Alpha 非发布前置。Beta 要求本次曲包所有曲子拥有谱面与封面。</div>
      <div id="library" class="list"></div>
    </div>
    <div id="packageView" class="view">
      <h2 class="section-heading">曲包与更新</h2>
      <div class="row package-toolbar">
        <select id="packageType" class="touch-control"><option>主线包</option><option>支线包</option><option>补充包</option><option>单曲</option></select>
        <button class="touch-control" type="button" @click="invoke('createPackage')">新建曲包</button>
      </div>
      <div id="packages"></div>
    </div>
    <div id="collabView" class="view"><h2 class="section-heading">联动</h2><div id="collabs"></div></div>
  </section>
</template>

let COMPOSER_MASTER=[];

(function(){
  const addExtraPortfolio=(composerName,item)=>{
    const c=COMPOSER_MASTER.find(x=>x.name===composerName);
    if(c&&!c.portfolio.some(p=>p.name===item.name))c.portfolio.push(item);
  };

  addExtraPortfolio("PICKUPNEAR",{"id":51006,"name":"温室花房第7作：flashback","price":5000,"quality":4,"abstract":3,"style":"抒情","attention":60,"discussion":60,"good":80,"bought":false,"note":"","composerLabel":"PICKUPNEAR vs. 夜枭大叔","collabComposerIds":[],"sharedPortfolioKey":"PICKUPNEAR vs. 夜枭大叔|温室花房第7作：flashback"});
  addExtraPortfolio("夜枭大叔",{"id":51006,"name":"温室花房第7作：flashback","price":5000,"quality":4,"abstract":3,"style":"抒情","attention":60,"discussion":60,"good":80,"bought":false,"note":"","composerLabel":"PICKUPNEAR vs. 夜枭大叔","collabComposerIds":[],"sharedPortfolioKey":"PICKUPNEAR vs. 夜枭大叔|温室花房第7作：flashback"});

  addExtraPortfolio("PICKUPNEAR",{"id":51007,"name":"温室花房第8作：magic","price":5000,"quality":4,"abstract":2,"style":"抒情","attention":70,"discussion":70,"good":80,"bought":false,"note":"","composerLabel":"PICKUPNEAR vs. USAGI","collabComposerIds":[1003],"sharedPortfolioKey":"PICKUPNEAR vs. USAGI|温室花房第8作：magic"});

  addExtraPortfolio("PICKUPNEAR",{"id":51008,"name":"温室花房第9作：recitation","price":5000,"quality":4,"abstract":3,"style":"灼热","attention":60,"discussion":60,"good":80,"bought":false,"note":"","composerLabel":"PICKUPNEAR vs. 纵连大师","collabComposerIds":[1005],"sharedPortfolioKey":"PICKUPNEAR vs. 纵连大师|温室花房第9作：recitation"});
  addExtraPortfolio("纵连大师",{"id":51008,"name":"温室花房第9作：recitation","price":5000,"quality":4,"abstract":3,"style":"灼热","attention":60,"discussion":60,"good":80,"bought":false,"note":"","composerLabel":"PICKUPNEAR vs. 纵连大师","collabComposerIds":[1005],"sharedPortfolioKey":"PICKUPNEAR vs. 纵连大师|温室花房第9作：recitation"});
})();

const MEMBER_NAME_POOL=["AsterLynx","qorii","Nulphase","Re:Vane","Krynt","Mizuel","sylq","Noctbyte","Cervin_","Limefault","Ruvia","K4NDE","morroway","Axelune","TesseraQ","halcyx","VeiNox","Rinquel","nagi//zero","CobaltRift","Seryth","Quenel","Frailix","xenovale","TohkaN","MELT_17","Yurase","pluvion","N4RROW","Seiruka","bitcradle","Arqel","Hakurow","Lunetica","ciel_r","NoiKaze","frame//skip","Orphic8","VantaRay_","shirobit","Eclairex","TsuruneQ","Velqis","mono.kei","Crystfall","Urahane","zenith_404","Rakuzen","FrostIndex","NemuKiri","Iontrace","Kurovia","latency0","AmeRift","Solenq","voidpetal","Taktless","Hibikuro","Myrkline","Refrain_β","meltflora","Aoitsuki","LueurMare","NemuCanvas","SumiRêve","iris//milk","Kohakune","PaleMoth","yuraame","FuyuLace","CottonVoid","Mizuhana_","SereinPico","haneiro","LucidPoppy","ruriiro","KageMallow","NoirMikan","petal.exe","Aonagi","LumiSumi","Tsukishade","MofuGlass","YoruFleur","milkgrave","Sakuroom","CielMori","ameiro_7","PicoLune","NagiPastel","MallowInk","HoshikuzuQ","veilberry","SumiNuit","RakuMelt","fuwari_00","KiriPetal","Lunacot","AmeSketch","NemuRin","白榆","折光","栖迟","雨切","迟川","眠野","空白格","灰阶","逆光层","碎星","旧灯","雾岛以北","栖木","潮汐线","余响","青昼","落纸","沸点","薄明","无色差","雨隙","弦外","深蓝偏移","零号纸箱","冬眠电台","晚潮","微光残片","北纬失真","不稳定像素","昨日信号","纸上噪声","沉默频段","折返线","白噪点","晚星误差","空房间","二十三号接口","不存在的雨","玻璃海","旧城区回声","小馒头","爬爬","Magazet","赤澪","Ariayaka","TCSTWTBHY","超级练习册","Kiyotsuki","母鸡","维生素b","树穴猪","Iblcya","Icier","Laugger","Lei motife","LogicM","NintyKeven","xzadudu179","姜片","Felicks_FoX","RANKB","nanakaria","阿白","永恒指南针","豆乳","神居冰绘","水沐汐","澈子","诡异童话","雨生種","Ether-0","鱼圆","香香鸡","纸巾","注射","域核","LING","MYOB!","QIER"];
const LEVEL5_CHART_NAME_POOL=["爬爬","Magazet","赤澪","Ariayaka","TCSTWTBHY","超级练习册","Kiyotsuki","母鸡","维生素b","树穴猪","Iblcya","Icier","Laugger","Lei motife","LogicM","NintyKeven","xzadudu179","姜片","Felicks_FoX","RANKB"];
const LEVEL5_ART_NAME_POOL=["nanakaria","阿白","永恒指南针","豆乳","神居冰绘","水沐汐","澈子","诡异童话","雨生種","Ether-0","鱼圆","香香鸡","纸巾","注射","域核","LING","MYOB!","QIER"];
const LEVEL5_COPY_NAME_POOL=["杂合子","Kozak"];
const ADDITIONAL_MEMBER_NAME_POOL=["Aetheris","Nyxen","Solvara","Veylith","Kaelum","Zephyrix","Liora","Thalor","Orinth","Eclipta","Vantora","Quixaria","Halcyon","Sylphide","Aurorae","Cimmerian","Nebulon","Pyrrhic","Seraphic","Obsidya","Mirelle","Cyrene","Dravon","Elyrian","Faelith","Glacius","Heliov","Iridian","Jovian","Kaelith","Luminar","Meridian","Nihilith","Oryxia","Phaedra","Quillon","Rivenor","Tenebryl","Umbrael","Virelia","Wisteria","Xanthe","Ysolde","Zorynth","Astrael","Beryll","Cindral","Duskwight","Emberlyn","Solstice","霁月清风","泠鸢栖迟","蘅芜清梦","荻花秋晚","杳霭孤舟","溟濛烟雨","轶尘","煜夜"];
const RESERVED_MEMBER_NAMES=new Set([...LEVEL5_CHART_NAME_POOL,...LEVEL5_ART_NAME_POOL,...LEVEL5_COPY_NAME_POOL]);
const GENERAL_MEMBER_NAME_POOL=[...MEMBER_NAME_POOL,...ADDITIONAL_MEMBER_NAME_POOL].filter(n=>!RESERVED_MEMBER_NAMES.has(n));
const STYLE_COMMISSION_TITLE_POOLS={
  "抒情":["Melody of Memories","Heartstrings","Tearful Smile","Promise in the Rain","Last Goodbye","Fleeting Dream","Whispering Petals","Eternal Embrace","Nostalgia","Serenade for You","Gentle Breeze","Farewell Letter","Blooming Heart","Stardust Melody","Warmth of Dawn","Reminiscence","Softly, Gently","Tender Night","Unspoken Words","Hopeful Tomorrow"],
  "灼热":["Hyperdrive Overload","Metalstorm","Rage Core","Inferno Burst","Overclocked Fury","Stormbreaker","Blast Radius","Rampage Engine","Voltage Spike","Havoc Protocol","Berserker Drive","Collapse Point","Photon Rush","Doomhammer","Circuit Breaker","Turbulence","Critical Mass","Scorched Earth","Final Overdrive","Ragnarok"],
  "冷冽":["Frostbound","Silentium","Crystal Lament","Pale Horizon","Wintermute","Glacier Veil","Hollow Echo","Lunar Drift","Snowblind","Misty Abyss","Frozen Requiem","Arctic Bloom","Nivalis","Whiteout","Solitude in Blue","Diamond Dust","Permafrost","Ghostlight","Crystalline","Hiemal"]
};
const COMMISSION_TITLE_POOL=["Afterglow Protocol","Frozen Pulse","Silent Overdrive","Neon Burial","Glass Horizon","Zero Gravity Bloom","Midnight Fracture","Last Signal","Velvet Collapse","Synthetic Rain","Crimson Static","Broken Parallax","Lunar Afterimage","Distant Frequency","Terminal Blossom","White Noise Heaven","Beyond the Pale Sky","Dead Orbit","Echoes of Tomorrow","Astral Burnout","Nocturnal Error","Parallel Silence","Cold Mirage","Vanishing Point","Infinite Refrain","Faultline Heart","Blue Distortion","Endless Interference","Lucid Collapse","Radiant Ruin","Static Eden","Last Light Syndrome","Beyond Zero","失温海岸","第七码头","白昼坠落","雨后失真","逆光协议","玻璃潮汐","无声焚烧","凌晨航线","偏振星群","旧城回响","零度花园","未完成的晴天","深蓝断层","永夜回路","空白频率","潮汐失控","坠入薄明","赤色噪点","折返宇宙","雨幕之外","燃尽之前","冬眠信号","终点之前","第九次日落","灰烬开花","不存在的车站","云层以下","星海误差","碎光定理","逆流脉冲","远日点","沉默临界","失控边界","风暴以北","蒼い残響","雨の境界線","夜明けのノイズ","透明な終末","星屑メモリー","凍える花","逆さまの空","月蝕パラドックス","灰色の夏","遠雷シグナル","白昼夢エラー","零時の楽園","君のいない軌道","雨音リフレイン","境界の彼方へ","青に沈む","壊れた天球","夜空オーバーフロー","薄明カタストロフィ","世界が眠る前に","未明の残像","断線した未来","光速モラトリアム","永遠未満","静寂コンプレックス","雨粒レゾナンス","空白のアルゴリズム","星を忘れた夜","終末ブルーム","透明境界","無限回廊","君と世界の誤差","凍結都市","月亮坏在凌晨四点","请勿折叠这场暴雨","第十三种蓝","你所看见的并非天空","非法入侵春天","失眠者观测协议","玻璃胃里的星星","灰色星期八","请在终点前醒来","温度计拒绝下降","空气正在删除我们","低电量宇宙","昨日已被撤回","不存在于地图上的海","反向生长的雨","这是最后一次日出","错误编号：夏天","未命名的第六感","世界末日前五分钟","把云层调成静音","折断一束光","无法验证的心跳","你比噪声更安静","第0号晴天","把夜晚压缩成ZIP","记忆读取失败","请勿向星空投掷异物","海平面以上的梦","周三不存在","风正在学习如何燃烧","未经许可的黄昏","黑箱中的候鸟","如果雨拥有管理员权限","我们在错误的宇宙见过","さよなら.exe","月曜日はまだ来ない","雨が壊れる音","存在しない青","世界終了まであと3秒","君を削除できません","午前四時の透明人間","逆再生の春","404号室の月","星屑はログアウトしました","未完成パラノイア","透明人間の心拍数","雨天決行エラー","君だけがバグっている","夢.exeは応答していません","冷蔵庫の中の宇宙","青色過剰摂取","月が二度死ぬ夜","不完全な天気予報","無音の非常ベル","終電のない惑星","さよならを圧縮して","真夜中インストール","空白依存症","透明度100%","夏季限定エラー","君の心臓は非対応です","世界はただいま更新中","雨粒アンインストール","青春バックアップ失敗","星を右クリック","午前三時の例外処理","夢の賞味期限","ERROR: Heaven Not Found","please reboot the moon","God.exe Has Stopped Working","Tuesday Is a Simulation","Eat the Static","Blue Screen Summer","Unauthorized Sunrise","DO NOT FEED THE VOID","0% Angel","Memory Leak in Paradise","The Sky Forgot My Password","ctrl+alt+goodbye","Sleep Is Currently Unavailable","Soft Error, Hard Heart","This Song Will Self-Destruct","Rain.dll","Temporary Human","Heaven Has No Wi-Fi","Moonlight Overflow","Delete Me After Midnight","Your Heart Is Out of Range","Unstable Flower Protocol","404 Days of Summer","Please Insert Another Universe","Offline Angel Syndrome","THE SUN IS BUFFERING","Invalid Emotion Type","Automatic Goodbye Machine","Do Not Refresh the Ocean","Last Login: Yesterday","System32\\Love","Crying in 16:9","This Is Not the Final Boss","Heaven.zip","PLEASE DO NOT RESUSCITATE","The Moon Is Experiencing Technical Difficulties","Error Bloom","I Left My Body in Airplane Mode","17% Human","Cathedral of Broken Notifications","Softlock Paradise","Your Dreams Have Been Archived","Milk.exe","Angel With No User Manual","The Sun Has Entered Safe Mode","Memory Corruption Waltz","Invalid Sky Parameter","God Forgot to Save","Crybaby Protocol","Please Reinstall Morning","Unlicensed Emotion","DEADPIXEL HEART","This Is Probably Fine","Borrowed Gravity","Heaven Is Read-Only","Fatal Error in Blue","Do Not Turn Off the Rain","The Ocean Has No Undo Button","Null Flower","Temporary Soul Container","Saturday Has Been Deprecated","System Message From Nowhere","Burn After Listening","You Are Not Authorized to Feel This","Cosmic Packet Loss","Offline Forever","Floral Segmentation Fault","Love in Compatibility Mode","Unknown Weather Event","Too Many Moons","Subroutine for Crying","Restart Required","No Signal Beyond This Point","Dream Cache Overflow","angel.tmp","Please Accept the Terms of Existence","Unstable Heaven Build","The Stars Are Out of Warranty","Night Mode Malfunction","My Heart Has No Recovery Partition","Unsupported Lifeform","Pink Noise Funeral","Your Soul Is Currently Syncing","Cathedral.exe","Incorrect Universe Selected","The Sky Is Not Responding","Low Battery Messiah","Ctrl+Z the Apocalypse","Broken Sunlight Driver","Rain Permission Denied","Artificial Afterlife","Reality Has Left the Chat","I Think the Moon Is Lying","Zero-Day Angel","Unscheduled Extinction Event","Sleep Mode Is for Cowards","Please Hold While the World Ends","Incorrect Emotional Syntax","Ghost Process","Synthetic Nostalgia Disorder","Heaven Timeout","Romantic Buffer Overflow","Nocturnal Firmware","Manual Override: Summer","You Cannot Delete This Feeling","Fragile Data Structure","The Last Known Good Sky","Blue Screen Theology","The Universe Is Busy","Rain Has No Return Value","Unauthorized Blooming","End User License to Exist","Soft Failure","Caffeine-Based Resurrection","Please Disconnect From Reality","Moon.exe Is Not a Valid Win32 Application","Dead Letter Paradise","Flower With Administrator Privileges","Your Childhood Is No Longer Supported","Panic at Address 0x0000","Static Communion","Emergency Sunlight Patch","Recycle Bin Heaven","I Accidentally Forked the Universe","Beautifully Invalid","Cold Boot Angel","The Horizon Has Crashed","Do Not Rename the Moon","Exception Thrown: LOVE","Temporary God Complex","Paradise in Debug Mode","Please Confirm You Are Alive","End of File, End of World","Δfterglow.exe","NΞON//FRACTURE","ΛNGEL_404","Ωverclocked Heaven","ΣILENT//BURST","CRYØGENIC","ΦANTOM SIGNAL","HYPER//ΛXIS","DΞAD★ORBIT","λost in Static","VØID≠NULL","∆DRENALINE","BŁUE//ERROR","CATHΞDRAL.exe","ΨCHO//FRAME","NØ SIGNAL//","αfter//zero","RE:ΛNIMATE","MΞMORY†LEAK","GL1TCH∴BLOOM","ΗEAVEN//OFFLINE","CRØSS†FADE","NΞRV.exe","ΞCHO//NULL","LUNΛR≠ERROR","ΣLEEP//MODE","VANTA†CORE","PRØTOCOL_β","HΞART//PANIC","SΛTURATED","ØRBITAL†NOISE","ΔRCHIVE://SOUL","NΞURAL★RAIN","KΛTASTROPHΞ","SHUTDØWN_Ω","MΞLT//POINT","SØFT†FAILURE","ΛSTRAL//FAULT","RΞBOOT≠LIFE","HYPER†LIMINAL","NØCTURNE_λ","ΨSTORM","DΞLTA//HEART","ECHØ†VOID","ΣYNTHETIC//SUN","BLΛCK★SIGNAL","CØRE://HEAVEN","NΞGATIVE∞SPACE","FAULT//Σ","ΩMEGA†BLOOM","NULΛ.exe","FRΛGMENT_01","CRY//βETA","ΞXIT≠FOUND","LØST†FUNCTION","ASTRΛL//PANIC","VOID_ΔRIVE","ΣTATIC★FEVER","MØON†BUFFER","HΞLL0//WORLD","ΨNCHRONIZE","GLΛSS≠SKY","FΛTAL//SIGNAL","NØISE_∞","ECHØ//RΞTURN","REQUIΞM†404","SØLAR_βURN","ΔNGEL//KERNEL","VΞCTOR†ZERO","COLD//ΛRCHIVE","ΞRRØR†PARADISE","ΛCID★RAIN","NØVA//CRASH","STATIC_Ψ","ΦRAGMENTED","ΣOUL≠SYNC","LØOP://FOREVER","ΞCLIPSE†MODE","HΞART_0x00","BLØOM//NULL","ΛNTI★GRAVITY","DΞAD//CHANNEL","CRASH†ΨNDROME","GL1TCH_Ω","NØCT//BURN","VØID†SIGNATURE","ΣTAR//FAILURE","MΞTA≠HUMAN","LΛST†PACKET","BLUE_ΔEATH","ΦINAL//BUFFER","ΞNDLESS†CACHE","RΛIN≠VALID","NULΛ★HEAVEN","DΞCAY_λ","ΩFFLINE†ANGEL","SØFT//COLLAPSE","ΨIGNAL_LOST","ΔEBUG†EDEN","ΣYSTEM//ASCENSION"];
const STYLE=["灼热","抒情","冷冽"], RARITY_COORD={1:5,2:3,3:2,4:10,5:5}, BASE_MEMBER_DAYS={1:30,2:27,3:23,4:18,5:14}, COMMISSION_BASE_DAYS=60, BASE_BUG=20;
let uid=100;const nextId=()=>++uid,clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=(a,b)=>a+Math.random()*(b-a),chance=p=>Math.random()<p;

// Excel作品集数据同步修正：以作品集Excel为准覆盖价格/质量/抽象/风格/关注/讨论/好评。
(function(){
 const excelPortfolioData=[{"owner": "留存", "name": "梦工厂", "price": 3000, "quality": 5, "abstract": 1, "style": "抒情", "attention": 80, "discussion": 50, "good": 100}, {"owner": "PICKUPNEAR", "name": "最华丽的独奏", "price": 500, "quality": 3, "abstract": 2, "style": "抒情", "attention": 30, "discussion": 10, "good": 50}, {"owner": "大二", "name": "猫的咖啡厅", "price": 5000, "quality": 3, "abstract": 5, "style": "抒情", "attention": 90, "discussion": 90, "good": 20}, {"owner": "Flower", "name": "infinite-cardinal", "price": 0, "quality": 3, "abstract": 3, "style": "冷冽", "attention": 70, "discussion": 10, "good": 70}, {"owner": "atsusamushi", "name": "School Violence", "price": 5000, "quality": 4, "abstract": 2, "style": "灼热", "attention": 80, "discussion": 20, "good": 70}, {"owner": "Flower", "name": "返校日", "price": 0, "quality": 2, "abstract": 4, "style": "灼热", "attention": 60, "discussion": 20, "good": 50}, {"owner": "白女皇", "name": "时间长流", "price": 2000, "quality": 4, "abstract": 1, "style": "抒情", "attention": 70, "discussion": 40, "good": 60}, {"owner": "美食街", "name": "春日吹雪", "price": 10000, "quality": 4, "abstract": 2, "style": "冷冽", "attention": 60, "discussion": 30, "good": 80}, {"owner": "贪吃蛇", "name": "恐龙时代", "price": 2000, "quality": 4, "abstract": 3, "style": "灼热", "attention": 60, "discussion": 20, "good": 70}, {"owner": "Lemon", "name": "水晶指针", "price": 2000, "quality": 4, "abstract": 3, "style": "抒情", "attention": 50, "discussion": 20, "good": 80}, {"owner": "PICKUPNEAR", "name": "温室花房第1作：afternoon", "price": 1200, "quality": 2, "abstract": 1, "style": "抒情", "attention": 30, "discussion": 10, "good": 60}, {"owner": "PICKUPNEAR", "name": "温室花房第2作：sunlight", "price": 1200, "quality": 2, "abstract": 2, "style": "灼热", "attention": 40, "discussion": 10, "good": 60}, {"owner": "PICKUPNEAR", "name": "温室花房第3作：flower", "price": 1200, "quality": 2, "abstract": 3, "style": "抒情", "attention": 40, "discussion": 10, "good": 60}, {"owner": "PICKUPNEAR", "name": "温室花房第4作：rain", "price": 1200, "quality": 2, "abstract": 2, "style": "冷冽", "attention": 40, "discussion": 20, "good": 50}, {"owner": "PICKUPNEAR", "name": "温室花房第5作：dandelion", "price": 1200, "quality": 2, "abstract": 1, "style": "灼热", "attention": 30, "discussion": 20, "good": 50}, {"owner": "PICKUPNEAR vs. 可燃冰", "name": "温室花房第6作：blizzard", "price": 2400, "quality": 3, "abstract": 2, "style": "冷冽", "attention": 40, "discussion": 10, "good": 60}, {"owner": "stardust", "name": "Before Light", "price": 5000, "quality": 4, "abstract": 2, "style": "灼热", "attention": 40, "discussion": 20, "good": 100}, {"owner": "侧睡", "name": "薪火", "price": 500, "quality": 3, "abstract": 3, "style": "灼热", "attention": 30, "discussion": 10, "good": 50}, {"owner": "shcad", "name": "花海的贤者", "price": 12000, "quality": 5, "abstract": 1, "style": "抒情", "attention": 60, "discussion": 30, "good": 90}, {"owner": "boTanicaMin", "name": "碎裂的心", "price": 500, "quality": 4, "abstract": 2, "style": "冷冽", "attention": 30, "discussion": 10, "good": 70}, {"owner": "topaz", "name": "九龙城寨", "price": 3000, "quality": 5, "abstract": 4, "style": "灼热", "attention": 80, "discussion": 50, "good": 80}, {"owner": "topaz", "name": "熊猫骑士", "price": 0, "quality": 3, "abstract": 3, "style": "灼热", "attention": 40, "discussion": 20, "good": 70}, {"owner": "whiteball", "name": "ruthless war", "price": 5000, "quality": 5, "abstract": 1, "style": "灼热", "attention": 20, "discussion": 50, "good": 80}, {"owner": "sentinel", "name": "when the sun", "price": 2000, "quality": 5, "abstract": 2, "style": "冷冽", "attention": 80, "discussion": 50, "good": 100}, {"owner": "boTanicaMin", "name": "乌托邦", "price": 500, "quality": 4, "abstract": 2, "style": "抒情", "attention": 30, "discussion": 10, "good": 70}, {"owner": "夜枭大叔", "name": "artcore", "price": 2000, "quality": 5, "abstract": 2, "style": "冷冽", "attention": 20, "discussion": 10, "good": 100}, {"owner": "野猪野", "name": "空气循环", "price": 500, "quality": 4, "abstract": 2, "style": "冷冽", "attention": 20, "discussion": 10, "good": 60}, {"owner": "电钻侠", "name": "与电钻共舞", "price": 5000, "quality": 4, "abstract": 4, "style": "灼热", "attention": 50, "discussion": 70, "good": 50}, {"owner": "贪吃蛇 vs. heaven_cube", "name": "点火器", "price": 10000, "quality": 4, "abstract": 2, "style": "灼热", "attention": 50, "discussion": 40, "good": 80}, {"owner": "sentinel", "name": "lapis", "price": 5000, "quality": 3, "abstract": 2, "style": "抒情", "attention": 80, "discussion": 80, "good": 70}, {"owner": "焦耳", "name": "NightGUST", "price": 1200, "quality": 3, "abstract": 2, "style": "冷冽", "attention": 20, "discussion": 10, "good": 70}, {"owner": "KuROWhite", "name": "Feel the Nostalgia", "price": 5000, "quality": 4, "abstract": 1, "style": "抒情", "attention": 40, "discussion": 30, "good": 80}, {"owner": "USAGI", "name": "Small Mommy", "price": 5000, "quality": 4, "abstract": 5, "style": "灼热", "attention": 80, "discussion": 80, "good": 40}, {"owner": "ふるかぶ", "name": "LightTheater", "price": 2000, "quality": 4, "abstract": 1, "style": "抒情", "attention": 40, "discussion": 20, "good": 70}, {"owner": "PICKUPNEAR vs. 夜枭大叔", "name": "温室花房第7作：flashback", "price": 4800, "quality": 5, "abstract": 3, "style": "冷冽", "attention": 40, "discussion": 50, "good": 80}, {"owner": "PICKUPNEAR vs. USAGI", "name": "温室花房第8作：magic", "price": 4800, "quality": 4, "abstract": 4, "style": "灼热", "attention": 60, "discussion": 50, "good": 70}, {"owner": "PICKUPNEAR vs. 纵连大师", "name": "温室花房第9作：recitation", "price": 2400, "quality": 3, "abstract": 4, "style": "灼热", "attention": 40, "discussion": 40, "good": 60}];
 const targets = new Map();
 excelPortfolioData.forEach(p=>{
   if(!targets.has(p.name))targets.set(p.name,[]);
   targets.get(p.name).push(p);
 });
 COMPOSER_MASTER.forEach(c=>{
   (c.portfolio||[]).forEach(p=>{
     let matches=targets.get(p.name);
     if(!matches)return;
     let m=matches.find(x=>x.owner===c.name)||matches[0];
     if(!m)return;
     if(m.price!=null)p.price=m.price;
          if(m.abstract!=null)p.abstract=m.abstract;
     if(m.style!=null)p.style=m.style;
     if(m.attention!=null)p.attention=m.attention;
     if(m.discussion!=null)p.discussion=m.discussion;
     if(m.good!=null)p.good=m.good;
   });
 });
})();

const GAME_RULES=window.__NCRYOS_RULES__;
const state={day:1,money:10000,job:"home",ap:18,dailySpent:0,fatigue:0,tech:0,fans:0,discussion:0,players:0,rating:80,artPursuit:100,expectation:30,stickiness:10,bugChance:BASE_BUG,
playerFloor:0,ratingFloor:0,playerFloorShield:true,ratingFloorShield:true,artEventBonus:0,programQualityBoost:0,inspiration:false,playedRhythmToday:false,takeoutProgramDiscount:false,takeoutRecruitBuff:false,bankrupt:false,bailoutLastDay:-9999,hasReleasedUpdate:false,
lastUpdateDay:null,updateClockStarted:false,hiatusTriggered:false,lastMainlineDay:null,consecutiveSupplement:0,consecutiveSingles:0,
services:{vpn:false,translation:false,takeout:false,workspace:false,sponsor:false,course:false},commissionSelections:{},usedMemberNames:[],usedCommissionTitles:[],sponsorIncome:0,recruitFail:{chart:0,art:0,copy:0},candidate:null,applications:[],studyActionsToday:0,sideSleepNetworkDone:false,day100RecruitEventDone:false,hasSearchedMember:false,sideSleepSearchHintDone:false,firstNonTutorialSongHintDone:false,firstChartCompleteHintDone:false,sideSleepCommissionedOnce:false,sideSleepSameDayExpediteTipDone:false,designConceptConfirmed:false,designStyle:"传统",designPC:false,gameName:"",designNameAnnouncementDone:false,spliceYear1Failed:null,firstReleaseTier:null,programWritesToday:0,copyActionCount:0,copywriterDiscoveryHintShown:false,copyRecruitUnlocked:false,hasHadCopywriter:false,storyWords:0,storyWordCap:5000,storyCapAccountingVersion:2,memberSortMode:"acquired",hideInstalledSongs:false,
formerMemberOpinionCandidates:[],exMemberScandalClusterUntil:0,exMemberScandalDiscussUntil:0,
exMemberScandalDiscussScale:0,exMemberScandalEscalated:false,exMemberGradualLoss:null,
collabOpinionBlockedUntil:0,teamArgumentUntil:0,formerMemberOpinionSpokenNames:[],ruthlessWarBusEventDone:false,lastAnnouncementDay:-9999,departedRecoverables:[],programStudyCount:0,artStudyCount:0,derivativeProgress:0,derivativeCount:0,fiveStarRecruitSuppressionUntil:0,
freeMemberEventsToday:0,feedbackEmailEventDone:false,saveReminder60Done:false,copyFanMonthIndex:0,copyFanMonthStartFans:0,copyFanGainThisMonth:0,multiTalentAffectionMonthIndex:0,takeoutCountToday:0,overeatingStacks:0,takeoutBlockedToday:false,monthlyPraiseLocks:[],documentExplosionCount90:0,documentExplosionPenalty:0,playerMilestone1000Done:false,recommendCommissionCooldown:0,mysteryDonationCooldown:0,mysteryDonationFollowups:[],playerMilestone10000Done:false,playerMilestone100000Done:false,hasScoreTracker:false,scoreTrackerBroken:false,scoreTrackerRepairProgress:100,scoreTrackerFailureDays:[],
milestoneMemberApplicationDays:[],milestoneComposerOfferDays:[],shcadMilestoneDiscountPending:false,
computerBrokenUntil:0,computerRepairCooldownUntil:0,members:[],composers:[],library:[],commissions:[],packages:[],collabs:[],
currentCollabOffer:null,jobLockedUntil:1,firstShcadCommissionDone:false,rumorActiveUntil:0,rumorBaseFansLoss:0,rumorLastTriggerDay:-9999,rumorMinGapDays:90,rumorTriggersThisYear:0,collabFailStack:0,collabsThisYear:0,collabPenaltyDays:0,collabRequestEverTriggered:false,
metaFans:0,metaDiscussion:0,metaPlayers:0,metaRating:80,severeBugUntil:0,updateClockStartDay:240,incomingOffers:[],lastIncomingOfferDayByComposer:{},pendingHiddenBugBonus:0,monthlyHighCoordEvents:0,monthlyLowCoordEvents:0,temporaryCoordBonus:0,temporaryCoordBonusUntil:0,pendingDiscussionDrops:[],temporaryPlayerEffects:[],
lastBetaLeakDay:-9999,leakDiscussionUntil:0,pendingLeakBetaDelay:0,pendingLeakSourcePackageId:null,leakerSpiritRecoveryQueue:[],lewdImageFollowups:[],
firstYear2EventDone:false,firstYear3CommissionDone:false,firstYear7CollabDone:false,commercialFormalCount:0,
gameCoreProgress:0,gameCoreCompleteNotified:false,
chartEditorUnlocked:false,chartEditorProgress:0,chartEditorComplete:false,chartEditorCompleteNotified:false,
chartEditorV2Unlocked:false,chartEditorV2Progress:0,chartEditorV2Complete:false,chartEditorV2CompleteNotified:false,
artStudyStarted:false,artStudyProgress:0,artStudy50Notified:false,artStudy100Notified:false,derivativeProgress:0,derivativeCount:0,
rhythmPlayCount:0,personalChartCount:0,
firstReleaseEvaluated:false,badLaunchUntil:0,perfectLaunchUntil:0,
streamerWindows:[],activeStreamer:null,
streamers:["无所依","造梦先生","愚者约翰内斯","鱼鳞子","红色通行证","真流畅","飞跃巅峰","505","水金","农夫","Blunt_Ball","善树"]};
function formatLargeCount(n){
  n=Number(n)||0;
  if(n>=1000000)return Math.floor(n/1000)+"千";
  return Math.floor(n);
}
function applyPopulationCaps(){
  state.metaFans=Math.min(12000000,state.metaFans||0);
  state.metaPlayers=Math.min(12000000,state.metaPlayers||0);
  state.metaDiscussion=Math.min(24000000,state.metaDiscussion||0);
}
const year=()=>Math.floor((state.day-1)/365),dayOfYear=()=>((state.day-1)%365)+1,dayOfMonth=()=>((state.day-1)%30)+1,monthOfYear=()=>(Math.floor((dayOfYear()-1)/30)%12)+1,isMonthStart=()=>dayOfMonth()===1,isYearStart=()=>dayOfYear()===1;
function ensureNewStateDefaults(){
  if(!state.services)state.services={vpn:false,translation:false,takeout:false,workspace:false,sponsor:false,course:false};
  if(!Array.isArray(state.leakerSpiritRecoveryQueue))state.leakerSpiritRecoveryQueue=[];
  if(state.services.course===undefined)state.services.course=false;
  if(!state.commissionSelections)state.commissionSelections={};
  if(!state.usedMemberNames)state.usedMemberNames=[];
  if(!state.recruitFail)state.recruitFail={chart:0,art:0,copy:0};
  if(!Number.isFinite(state.recruitFail.copy))state.recruitFail.copy=0;
  if(!Number.isFinite(state.copyActionCount))state.copyActionCount=0;
  if(state.copywriterDiscoveryHintShown===undefined)state.copywriterDiscoveryHintShown=false;
  if(!Number.isFinite(state.storyWords))state.storyWords=0;
  if(!Number.isFinite(state.storyWordCap))state.storyWordCap=GAME_RULES.copywriterRules.initialStoryWordCap;
  state.storyWordCap=Math.max(0,state.storyWordCap);
  state.storyWords=clamp(state.storyWords,0,state.storyWordCap);
  if(state.copyRecruitUnlocked===undefined)state.copyRecruitUnlocked=GAME_RULES.canUnlockCopywriterRecruitment(state.copyActionCount,(state.members||[]).length);
  if(state.hasHadCopywriter===undefined)state.hasHadCopywriter=false;
  if((state.members||[]).some(m=>m.role==="copy")||(state.departedRecoverables||[]).some(r=>r.member?.role==="copy"))state.hasHadCopywriter=true;
  if(!Number.isFinite(state.derivativeProgress))state.derivativeProgress=0;
  if(!Number.isFinite(state.derivativeCount))state.derivativeCount=0;
  if(state.hideInstalledSongs===undefined)state.hideInstalledSongs=false;
  if(!Array.isArray(state.lewdImageFollowups))state.lewdImageFollowups=[];
  if(state.collabRequestEverTriggered===undefined){
    state.collabRequestEverTriggered=!!(state.currentCollabOffer||(state.collabs||[]).length||(state.collabsThisYear||0)>0)
  }
  if(!state.lastIncomingOfferDayByComposer)state.lastIncomingOfferDayByComposer={};
  if(!state.usedCommissionTitles)state.usedCommissionTitles=[];
  const ensureApplicantAge=app=>{
    if(!app)return;
    if(GAME_RULES.isGuaranteedAdultMember(app))app.isMinor=false;
    else if(app.isMinor===undefined)app.isMinor=GAME_RULES.memberStartsAsMinor(app.rarity)
  };
  ensureApplicantAge(state.candidate);
  for(const app of (state.applications||[]))ensureApplicantAge(app);
  for(const s of (state.library||[])){
    if(s._chartCraftLevel===undefined)s._chartCraftLevel=null;
    if(s._artCraftLevel===undefined)s._artCraftLevel=null;
    if(!Number.isFinite(s._personalArtPenalty))s._personalArtPenalty=0;
    if(s.storyCapacityGranted===undefined)s.storyCapacityGranted=true;
  }
  for(const m of (state.members||[])){
    if(!m.name||!memberNameAllowed(m.name,m.role,m.rarity)){
      m.name=pickMemberName(m.role,m.rarity)
    }
    if(!Number.isFinite(m.occupiedUntil))m.occupiedUntil=0;
    if(!Number.isFinite(m.lastGuardianPhoneEventDay))m.lastGuardianPhoneEventDay=-9999;
    if(m._statusBeforeOccupation===undefined)m._statusBeforeOccupation=null;
    if(m._statusDaysBeforeOccupation===undefined)m._statusDaysBeforeOccupation=0;
    if(!Number.isFinite(m.lewdCoordUntil))m.lewdCoordUntil=0;
    if(!Number.isFinite(m.academicAbsenceScheduledDay))m.academicAbsenceScheduledDay=0;
    if(!Number.isFinite(m.doubtWritingProgress))m.doubtWritingProgress=0;
    if(!Number.isFinite(m.affection))m.affection=GAME_RULES.memberAffectionRules.initial;
    m.affection=clamp(m.affection,0,GAME_RULES.memberAffectionRules.maximum);
    if(m.affectionTrustLocked===undefined)m.affectionTrustLocked=m.affection>=GAME_RULES.memberAffectionRules.trustFloor;
    if(m.role==="copy"){
      if(!Array.isArray(m.assignedSongIds))m.assignedSongIds=[];
      if(!Number.isFinite(m.copyWordsWritten))m.copyWordsWritten=Math.max(0,Math.round((Number(m.works)||0)*1000));
      if(!Number.isFinite(m.motivatedUntilDay)){
        let started=Number.isFinite(m._statusChangedDay)?m._statusChangedDay:state.day;
        m.motivatedUntilDay=(m.status==="干劲满满"||m._statusBeforeOccupation==="干劲满满")?started+GAME_RULES.copywriterRules.motivationDays:0
      }
    }
    if(!Number.isFinite(m.actualJoinDay))m.actualJoinDay=m.joinDay;
    if(m.ageModelVersion!==2){
      const legacyWasMinor=m.wasMinor===undefined?[1,2].includes(Number(m.rarity)):!!m.wasMinor;
      const legacyIsMinor=m.isMinor===undefined
        ?legacyWasMinor&&state.day<(Number.isFinite(m.minorUntilDay)?m.minorUntilDay:m.actualJoinDay+365)
        :!!m.isMinor;
      m.wasMinor=legacyWasMinor;
      m.isMinor=legacyIsMinor;
      m.adultAtDay=legacyIsMinor?m.actualJoinDay+GAME_RULES.getAdultTransitionDays():0;
      m.ageModelVersion=2
    }
    if(GAME_RULES.isGuaranteedAdultMember(m)){
      m.wasMinor=false;
      m.isMinor=false;
      m.adultAtDay=0;
      m.waitingGaokao=false;
      m.gaokaoTargetYear=null;
      m.gaokaoSprintActive=false
    }
    if(!Number.isFinite(m.adultAtDay))m.adultAtDay=m.isMinor?m.actualJoinDay+GAME_RULES.getAdultTransitionDays():0;
    m.minorUntilDay=m.adultAtDay;
    if(m.potentialInsider===undefined)m.potentialInsider=false;
    if(!Number.isFinite(m.potentialInsiderSinceDay))m.potentialInsiderSinceDay=m.actualJoinDay;
    if(m.leaker===undefined)m.leaker=false;
    if(m.confessedLeak===undefined)m.confessedLeak=false;
    if(m.confessedLeak){m.leaker=false;m.potentialInsider=false}
    if(m.rarity===GAME_RULES.hiddenMemberRules.protectedRarity)m.potentialInsider=false;
    if(m.waitingGaokao===undefined)m.waitingGaokao=!!m.wasMinor&&!m.isMinor&&!m.gaokaoCompleted;
    if(m.gaokaoTargetYear===undefined)m.gaokaoTargetYear=m.waitingGaokao?year()+1:null;
    if(m.gaokaoNoticeShown===undefined)m.gaokaoNoticeShown=false;
    if(m.gaokaoSprintActive===undefined)m.gaokaoSprintActive=false;
    if(m.gaokaoCompleted===undefined)m.gaokaoCompleted=false;
  }
  for(const p of (state.packages||[])){
    if(!Number.isFinite(p.announcementFanBonus))p.announcementFanBonus=0;
    if(!Number.isFinite(p.announcementDiscussionBonus))p.announcementDiscussionBonus=0;
    if(p.announcementBeforeReview===undefined)p.announcementBeforeReview=false;
    if(p.reviewCheckDay===undefined)p.reviewCheckDay=null;
    if(p.leaked===undefined)p.leaked=false;
    if(!Number.isFinite(p.betaExtraDays))p.betaExtraDays=0;
    if(!Number.isFinite(p.scoreTrackerFailureReduction))p.scoreTrackerFailureReduction=0;
    p.scoreTrackerFailureReduction=clamp(p.scoreTrackerFailureReduction,0,GAME_RULES.scoreTrackerRules.maximumFailureChanceReduction);
    if(!Number.isFinite(p.storyWordsAssigned))p.storyWordsAssigned=0;
    if(!Number.isFinite(p.storyExpectationMultiplier))p.storyExpectationMultiplier=1;
  }
  let allocatedStoryWords=(state.packages||[]).reduce((total,p)=>total+Math.max(0,Number(p.storyWordsAssigned)||0),0);
  if(state.storyCapAccountingVersion!==2){
    state.storyWordCap=Math.max(0,state.storyWordCap-allocatedStoryWords);
    state.storyCapAccountingVersion=2
  }
  state.storyWords=clamp(state.storyWords,0,state.storyWordCap);
  if(state.currentCollabOffer){
    if(!state.currentCollabOffer.gameName)state.currentCollabOffer.gameName="未知企划";
    if(!Number.isFinite(state.currentCollabOffer.songCount))state.currentCollabOffer.songCount=3;
    if(!Number.isFinite(state.currentCollabOffer.forcedDeadline))state.currentCollabOffer.forcedDeadline=state.day+365;
    if(!state.currentCollabOffer.tier)state.currentCollabOffer.tier="legacy"
  }
  for(const c of (state.collabs||[])){
    if(!c.gameName)c.gameName="未知企划";
    if(!Number.isFinite(c.songCount))c.songCount=(getPackage(c.packageId)?.songIds||[]).length||3
  }
  for(const r of (state.departedRecoverables||[])){
    if(!Number.isFinite(r.recoverProgress))r.recoverProgress=0;
    if(r.abandonAt===undefined)r.abandonAt=null;
    if(!Number.isFinite(r.departedDay))r.departedDay=state.day;
    if(r.member){
      if(!Number.isFinite(r.member.affection))r.member.affection=GAME_RULES.memberAffectionRules.initial;
      r.member.affection=clamp(r.member.affection,0,GAME_RULES.memberAffectionRules.maximum);
      if(r.member.affectionTrustLocked===undefined)r.member.affectionTrustLocked=r.member.affection>=GAME_RULES.memberAffectionRules.trustFloor
    }
  }
  if(state.metaRating===undefined)state.metaRating=80;
  if(!state.hasReleasedUpdate && state.rating===0 && state.metaRating===0)state.metaRating=80;
  const d={
    gameCoreProgress:0,gameCoreCompleteNotified:false,
    chartEditorUnlocked:false,chartEditorProgress:0,chartEditorComplete:false,chartEditorCompleteNotified:false,
    artStudyStarted:false,artStudyProgress:0,artStudy50Notified:false,artStudy100Notified:false,derivativeProgress:0,derivativeCount:0,
    rhythmPlayCount:0,personalChartCount:0,
    applications:[],studyActionsToday:0,sideSleepNetworkDone:false,
    hasSearchedMember:false,sideSleepSearchHintDone:false,firstNonTutorialSongHintDone:false,
firstChartCompleteHintDone:false,sideSleepCommissionedOnce:false,sideSleepSameDayExpediteTipDone:false,
    designConceptConfirmed:false,designStyle:"传统",designPC:false,gameName:"",designNameAnnouncementDone:false,spliceYear1Failed:null,
    firstReleaseTier:null,programWritesToday:0,memberSortMode:"acquired",
    formerMemberOpinionCandidates:[],exMemberScandalClusterUntil:0,exMemberScandalDiscussUntil:0,
    exMemberScandalDiscussScale:0,exMemberScandalEscalated:false,exMemberGradualLoss:null,
    collabOpinionBlockedUntil:0,teamArgumentUntil:0,formerMemberOpinionSpokenNames:[],ruthlessWarBusEventDone:false,lastAnnouncementDay:-9999,departedRecoverables:[],programStudyCount:0,artStudyCount:0,derivativeProgress:0,derivativeCount:0,fiveStarRecruitSuppressionUntil:0,
    freeMemberEventsToday:0,feedbackEmailEventDone:false,saveReminder60Done:false,copyFanMonthIndex:0,copyFanMonthStartFans:0,copyFanGainThisMonth:0,multiTalentAffectionMonthIndex:0,takeoutCountToday:0,overeatingStacks:0,takeoutBlockedToday:false,monthlyPraiseLocks:[],documentExplosionCount90:0,documentExplosionPenalty:0,playerMilestone1000Done:false,playerMilestone10000Done:false,playerMilestone100000Done:false,hasScoreTracker:false,scoreTrackerBroken:false,scoreTrackerRepairProgress:100,scoreTrackerFailureDays:[],
    milestoneMemberApplicationDays:[],milestoneComposerOfferDays:[],shcadMilestoneDiscountPending:false,
    computerBrokenUntil:0,computerRepairCooldownUntil:0,
    firstReleaseEvaluated:false,badLaunchUntil:0,perfectLaunchUntil:0,
    streamerWindows:[],activeStreamer:null,
    lastBetaLeakDay:-9999,leakDiscussionUntil:0,pendingLeakBetaDelay:0,pendingLeakSourcePackageId:null,leakerSpiritRecoveryQueue:[],
    streamers:["无所依","造梦先生","愚者约翰内斯","鱼鳞子","红色通行证","真流畅","飞跃巅峰","505","水金","农夫","Blunt_Ball","善树"]
  };
  for(const [k,v] of Object.entries(d))if(state[k]===undefined)state[k]=v;
  if(state.day100RecruitEventDone===undefined)state.day100RecruitEventDone=state.day>100;
  if(state.hasSearchedMember===undefined)state.hasSearchedMember=!!(state.candidate||(state.members||[]).length||(state.recruitFail&&((state.recruitFail.chart||0)>0||(state.recruitFail.art||0)>0)));
  if(state.sideSleepSearchHintDone===undefined)state.sideSleepSearchHintDone=state.day>15;
  if(state.firstNonTutorialSongHintDone===undefined)state.firstNonTutorialSongHintDone=(state.library||[]).some(s=>s.source!=="tutorial");
  if(state.firstChartCompleteHintDone===undefined)state.firstChartCompleteHintDone=(state.library||[]).some(s=>Number(s.chartProgress)>=100);
  if(state.sideSleepCommissionedOnce===undefined){
    let sideSleep=(state.composers||[]).find(c=>c.name==="侧睡");
    state.sideSleepCommissionedOnce=!!(sideSleep&&(
      (state.commissions||[]).some(x=>x.composerId===sideSleep.id&&!x.portfolioSong)||
      (state.library||[]).some(s=>s.composerId===sideSleep.id&&s.source==="commission")
    ));
  }
  if(state.sideSleepSameDayExpediteTipDone===undefined)state.sideSleepSameDayExpediteTipDone=false;
  if(state.designConceptConfirmed===undefined)state.designConceptConfirmed=false;
  if(!["创新","缝合","传统"].includes(state.designStyle))state.designStyle="传统";
  state.designPC=!!state.designPC;
  if(typeof state.gameName!=="string")state.gameName="";
  state.gameName=state.gameName.trim();
  if(state.designNameAnnouncementDone===undefined)state.designNameAnnouncementDone=false;
  if(!state.gameName)state.designConceptConfirmed=false;
  if(state.spliceYear1Failed===undefined)state.spliceYear1Failed=null;
  if(state.firstReleaseTier===undefined)state.firstReleaseTier=null;
  if(state.firstReleaseTier===null&&state.firstReleaseEvaluated){
    state.firstReleaseTier=(state.perfectLaunchUntil||0)>0?"perfect":(state.badLaunchUntil||0)>0?"bad":"normal";
  }
  if(state.programWritesToday===undefined)state.programWritesToday=0;
  if(!["acquired","level"].includes(state.memberSortMode))state.memberSortMode="acquired";
  if(!Array.isArray(state.formerMemberOpinionCandidates))state.formerMemberOpinionCandidates=[];
  if(!Number.isFinite(state.exMemberScandalClusterUntil))state.exMemberScandalClusterUntil=0;
  if(!Number.isFinite(state.exMemberScandalDiscussUntil))state.exMemberScandalDiscussUntil=0;
  if(!Number.isFinite(state.exMemberScandalDiscussScale))state.exMemberScandalDiscussScale=0;
  state.exMemberScandalEscalated=!!state.exMemberScandalEscalated;
  if(state.exMemberGradualLoss!==null&&typeof state.exMemberGradualLoss!=="object")state.exMemberGradualLoss=null;
  if(!Number.isFinite(state.collabOpinionBlockedUntil))state.collabOpinionBlockedUntil=0;
  if(!Number.isFinite(state.teamArgumentUntil))state.teamArgumentUntil=0;
  if(!Array.isArray(state.formerMemberOpinionSpokenNames))state.formerMemberOpinionSpokenNames=[];
  if(!Array.isArray(state.departedRecoverables))state.departedRecoverables=[];
  if(state.programStudyCount===undefined)state.programStudyCount=Math.max(0,Math.floor(Number(state.tech)||0));
  if(state.artStudyCount===undefined)state.artStudyCount=Math.max(0,Math.round((Number(state.artStudyProgress)||0)/.5));
  if(!Number.isFinite(state.fiveStarRecruitSuppressionUntil))state.fiveStarRecruitSuppressionUntil=0;
  if(!Number.isFinite(state.freeMemberEventsToday))state.freeMemberEventsToday=0;
  if(state.feedbackEmailEventDone===undefined)state.feedbackEmailEventDone=false;
  if(state.saveReminder60Done===undefined)state.saveReminder60Done=false;
  if(!Number.isFinite(state.copyFanMonthIndex))state.copyFanMonthIndex=0;
  if(!Number.isFinite(state.copyFanMonthStartFans))state.copyFanMonthStartFans=0;
  if(!Number.isFinite(state.copyFanGainThisMonth))state.copyFanGainThisMonth=0;
  if(!Number.isFinite(state.takeoutCountToday))state.takeoutCountToday=0;
  if(!Number.isFinite(state.overeatingStacks))state.overeatingStacks=0;
  state.takeoutBlockedToday=!!state.takeoutBlockedToday;
  if(state.playerMilestone1000Done===undefined)state.playerMilestone1000Done=false;
  if(state.playerMilestone10000Done===undefined)state.playerMilestone10000Done=false;
  if(state.playerMilestone100000Done===undefined)state.playerMilestone100000Done=false;
  if(state.hasScoreTracker===undefined)state.hasScoreTracker=false;
  state.scoreTrackerBroken=!!state.scoreTrackerBroken;
  if(!Number.isFinite(state.scoreTrackerRepairProgress))state.scoreTrackerRepairProgress=state.scoreTrackerBroken?0:100;
  state.scoreTrackerRepairProgress=clamp(Number(state.scoreTrackerRepairProgress)||0,0,100);
  if(!Array.isArray(state.scoreTrackerFailureDays))state.scoreTrackerFailureDays=[];
  state.scoreTrackerFailureDays=[...new Set(state.scoreTrackerFailureDays.filter(Number.isFinite).map(d=>Math.max(1,Math.floor(d))))].sort((a,b)=>a-b);
  if(!state.hasScoreTracker){state.scoreTrackerBroken=false;state.scoreTrackerRepairProgress=100;state.scoreTrackerFailureDays=[]}
  if(!Array.isArray(state.milestoneMemberApplicationDays))state.milestoneMemberApplicationDays=[];
  if(!Array.isArray(state.milestoneComposerOfferDays))state.milestoneComposerOfferDays=[];
  state.shcadMilestoneDiscountPending=!!state.shcadMilestoneDiscountPending;
  if(!Number.isFinite(state.computerBrokenUntil))state.computerBrokenUntil=0;
  if(!Number.isFinite(state.computerRepairCooldownUntil))state.computerRepairCooldownUntil=0;
  if(Array.isArray(state.incomingOffers)){
    for(const o of state.incomingOffers){
      if(!o.title)o.title=pickCommissionTitle(o.style);
      if(!o.origin)o.origin="legacy"
    }
  }
  state.gameCoreProgress=clamp(Number(state.gameCoreProgress)||0,0,100);
  state.chartEditorProgress=clamp(Number(state.chartEditorProgress)||0,0,100);
  state.chartEditorV2Progress=clamp(Number(state.chartEditorV2Progress)||0,0,100);
  state.artStudyProgress=clamp(Number(state.artStudyProgress)||0,0,100);
  if(state.hasReleasedUpdate && state.gameCoreProgress>=100 && !state.chartEditorComplete)state.chartEditorUnlocked=true;
  if(state.hasReleasedUpdate && state.chartEditorComplete && !state.chartEditorV2Complete)state.chartEditorV2Unlocked=true;
}

function designGrowthMultipliers(){
  let fan=1,discussion=1,player=1;
  if(!state.designConceptConfirmed)return {fan,discussion,player};
  let y=year();
  if(state.designStyle==="创新"&&y===0){
    let t=clamp((state.day-1)/364,0,1);
    let bonus=.30*(1-t);
    fan*=1+bonus;discussion*=1+bonus
  }else if(state.designStyle==="缝合"){
    if(y===0){
      fan*=.80;player*=.80;
      if(state.day<=90)discussion*=2
    }else if(y===1&&state.spliceYear1Failed===true){
      fan*=.60;player*=.60
    }
  }else if(state.designStyle==="传统"&&state.day<=365*7){
    fan*=.80;discussion*=.80
  }
  if(state.designPC){fan*=1.20;player*=1.20}
  return {fan,discussion,player}
}
function designSponsorMultiplier(){
  if(!state.designConceptConfirmed||state.designStyle!=="缝合"||state.day>365*3)return 1;
  let t=clamp((state.day-1)/(365*3-1),0,1);
  return .80+.20*t
}
function designProgramMultiplier(stage){
  if(!state.designConceptConfirmed)return 1;
  let m=1;
  if(state.designStyle==="创新"&&(stage==="core"||stage==="v1"))m*=.80;
  if(state.designStyle==="传统"){
    if(stage==="core"||stage==="v1")m*=1.50;
    if(stage==="v2")m*=1.80
  }
  if(stage==="core"&&state.designPC)m*=.80;
  return m
}
function chartEfficiencyMultiplier(m){
  if(!state.designConceptConfirmed||!m||m.role!=="chart")return 1;
  if(state.designStyle==="传统"){
    const table={1:1.30,2:1.20,3:1.10,4:1.20,5:1.30};
    return table[m.rarity]||1
  }
  if(state.designStyle==="缝合"&&m.rarity===4)return 1.20;
  return 1
}
function designDoubtIdleDays(){
  return state.designConceptConfirmed&&state.designStyle==="传统"?30:15
}
function memberJoinDayForDesign(role,rarity){
  if(state.designConceptConfirmed&&state.designStyle==="缝合"&&role==="chart"&&rarity>=3)return state.day-60;
  return state.day
}
function createJoinedMember({name,role,rarity,isMinor}){
  let actualJoinDay=state.day;
  let fixedMinor=GAME_RULES.isGuaranteedAdultMember({name,role,rarity})
    ?false
    :isMinor===undefined?GAME_RULES.memberStartsAsMinor(rarity):!!isMinor;
  let adultAtDay=fixedMinor?actualJoinDay+GAME_RULES.getAdultTransitionDays():0;
  let potentialInsider=GAME_RULES.shouldBecomePotentialInsider({rarity,isMinor:fixedMinor});
  return {
    id:nextId(),name,role,rarity,
    joinDay:memberJoinDayForDesign(role,rarity),actualJoinDay,
    idleDays:0,status:"正常",statusDays:0,cooldownUntil:0,works:0,assignedSongIds:[],doubtWritingProgress:0,copyWordsWritten:0,motivatedUntilDay:0,coordExtraUntil:0,
    affection:GAME_RULES.memberAffectionRules.initial,affectionTrustLocked:false,
    _spliceTenureApplied:state.designConceptConfirmed&&state.designStyle==="缝合"&&role==="chart"&&rarity>=3,
    ageModelVersion:2,wasMinor:fixedMinor,isMinor:fixedMinor,adultAtDay,minorUntilDay:adultAtDay,
    potentialInsider,potentialInsiderSinceDay:actualJoinDay,leaker:false,confessedLeak:false,
    waitingGaokao:false,gaokaoTargetYear:null,gaokaoNoticeShown:false,gaokaoSprintActive:false,gaokaoCompleted:false
  }
}
function applySpliceExistingTenure(){
  if(state.designStyle!=="缝合")return;
  for(const m of state.members||[]){
    if(m.role==="chart"&&m.rarity>=3&&!m._spliceTenureApplied){
      m.joinDay-=60;
      m._spliceTenureApplied=true
    }
  }
}
function updateDesignYearState(){
  if(!state.designConceptConfirmed||state.designStyle!=="缝合")return;
  if(state.day>=366&&state.spliceYear1Failed===null){
    state.spliceYear1Failed=!(state.firstReleaseTier==="normal"||state.firstReleaseTier==="perfect")
  }
}
function confirmDesignConcept(){
  if(state.designConceptConfirmed)return;
  let style=document.getElementById("designStyleSelect")?.value||"传统";
  let pc=(document.getElementById("designPCSelect")?.value||"否")==="是";
  let name=(document.getElementById("designGameNameInput")?.value||"").trim();
  if(!name){
    log("请先填写游戏名称。");
    document.getElementById("designGameNameInput")?.focus();
    return
  }
  state.designStyle=style;
  state.designPC=pc;
  state.gameName=name;
  state.designConceptConfirmed=true;
  if(style==="缝合"){
    applySpliceExistingTenure();
    if(state.day>=366)state.spliceYear1Failed=!(state.firstReleaseTier==="normal"||state.firstReleaseTier==="perfect")
  }
  log(`游戏设计理念已确定：${style}${pc?"，上线电脑端":"，不上线电脑端"}，游戏名《${gameName()}》。`,"gold");
  if(!state.designNameAnnouncementDone){
    state.designNameAnnouncementDone=true;
    log(`你创建了官方账号，并发布了一条视频《全新非商音游${gameName()}宣传视频》！`)
  }
  render()
}
function gameNameRaw(){return (state.gameName||"").trim()||"未命名音游"}
function gameName(){
  return gameNameRaw().replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
}
function renderDesignConcept(){
  let p=document.getElementById("designConceptPanel");if(!p)return;
  p.style.display=state.designConceptConfirmed?"none":"block";
  if(!state.designConceptConfirmed){
    let s=document.getElementById("designStyleSelect"),pc=document.getElementById("designPCSelect"),nameInput=document.getElementById("designGameNameInput");
    if(s)s.value=state.designStyle||"传统";
    if(pc)pc.value=state.designPC?"是":"否";
    if(nameInput&&document.activeElement!==nameInput)nameInput.value=state.gameName||""
  }
}
function programActionBaseCost(){
  let base=state.takeoutProgramDiscount?2:3;
  if(state.designConceptConfirmed&&state.designPC&&(state.programWritesToday||0)===0)base+=1;
  return base
}
function setMemberSortMode(mode){
  state.memberSortMode=mode==="level"?"level":"acquired";
  renderMembers()
}
function sortedMembers(){
  let arr=[...(state.members||[])];
  if(state.memberSortMode==="level"){
    const order={chart:0,art:1,copy:2};
    arr.sort((a,b)=>(b.rarity-a.rarity)||((order[a.role]??9)-(order[b.role]??9))||(a.joinDay-b.joinDay)||(a.id-b.id))
  }
  return arr
}

const teamCap=()=>year()<3?30:80,apCap=()=>state.job==="home"?42+year()*3:64+year()*4;
function baseDailyAP(){if(state.job==="home")return 18;if(state.job==="easy")return 10;if(state.job==="normal")return ((state.day-1)%7)===0?2:12;let d=(state.day-1)%7;return d===0||(year()>=6&&d===1)?1:6}
function todayAPGain(){return Math.max(0,baseDailyAP()+(state.services.workspace?2:0)-(state.collabPenaltyDays>0?3:0))}
function actionMultiplier(){return state.dailySpent>apCap()*.60?2:1}
function effectiveActionCost(base){return base*actionMultiplier()}
function spendAP(base){
  let need=effectiveActionCost(base);
  if(state.ap+1e-9<need){
    log(actionMultiplier()>1?`今日行动量已超过累计上限60%，该行动当前实际需要 ${need} 行动点。`:"行动点不足。");
    return false
  }
  state.ap=Math.max(0,Math.round((state.ap-need)*1000000)/1000000);
  state.dailySpent=Math.round((state.dailySpent+need)*1000000)/1000000;
  return true
}
function fmt(n){
  n=Math.round(Number(n)||0);
  if(n>=1000000)return Math.floor(n/1000)+"千";
  return n.toLocaleString("zh-CN")
}
let eventToastTimer=null;
function showEventToast(x,cls){
  let toast=document.getElementById("eventToast"),content=document.getElementById("eventToastContent");
  if(!toast||!content)return;
  content.innerHTML=`第${state.day}天｜${x}`;
  toast.className=`event-toast${cls?` ${cls}`:""}`;
  void toast.offsetWidth;
  toast.classList.add("show");
  clearTimeout(eventToastTimer);
  eventToastTimer=setTimeout(()=>toast.classList.remove("show"),3000)
}
function log(x,type="normal"){let cls=type==="green"?"event-green":type==="green-strong"?"event-green-strong":type==="gold"?"event-gold":type==="blue"?"event-blue":type==="red"?"event-red":type==="gray"?"event-gray":type==="purple"?"event-purple":"";document.getElementById("log").innerHTML=`<div class="${cls}">第${state.day}天｜${x}</div>`+document.getElementById("log").innerHTML;showEventToast(x,cls)}
function logDayEntry(){document.getElementById("log").innerHTML=`<div class="event-purple">进入第${state.day}天</div>`+document.getElementById("log").innerHTML}
const getSong=id=>state.library.find(s=>s.id===id),getMember=id=>state.members.find(m=>m.id===id),getPackage=id=>state.packages.find(p=>p.id===id),getComposer=id=>state.composers.find(c=>c.id===id);
function weighted(a){let r=Math.random(),s=0;for(const [v,p] of a){s+=p;if(r<=s)return v}return a[a.length-1][0]}
function makeSong(name,q,style,abstract,composerId,source){let base=100*q,att=base*(1+abstract*.08),dis=base*.55*(1+abstract*.12);return{id:nextId(),name,composerId,source,quality:q,style,abstract,attention:att,discussion:dis,good:60+q*7,originalAttention:att,originalDiscussion:dis,artPercent:100-abstract*6,chartProgress:0,artProgress:0,alpha:false,alphaStatus:"idle",alphaRemaining:0,alphaTotal:0,alphaBonusApplied:false,installed:false,installedDay:null,chartMemberIds:[],artMemberId:null,position:"普通曲",packageId:null,hiddenArtPendingUntil:null,storyCapacityGranted:false,_playableBonus:0,_personalArtPenalty:0,_memberAffectionBonus:0,_playableMultiplier:1,_chartCraftLevel:null,_artCraftLevel:null}}
function playableCraftLevel(s){
  let chart=Number(s._chartCraftLevel)||1;
  let art=Number(s._artCraftLevel)||1;
  if(state.designConceptConfirmed&&state.designStyle==="创新"&&chart<=2)chart*=.80;
  return clamp((chart+art)/2,.8,5)
}
function projectedPlayableQuality(s,{includeMemberAffection=true}={}){
  let q=clamp(Number(s.quality)||1,1,5);
  let craft=playableCraftLevel(s);
  let qn=(q-1)/4, rn=(craft-1)/4;
  // 四个设计锚点：
  // 1级歌+1级谱/画≈5；5级歌+1级谱/画≈40；
  // 1级歌+5级谱/画≈20；5级歌+5级谱/画≈95。
  let base=5+35*qn+15*rn+40*qn*rn;
  base+=(s._playableBonus||0);
  base*=s._playableMultiplier||1;
  if(includeMemberAffection&&base<92)base=Math.min(92,base+(s._memberAffectionBonus||0));
  if((s._personalArtPenalty||0)>0)base=GAME_RULES.personalArtQualityAfterPenalty(base,s._personalArtPenalty);
  return clamp(base,0,100)
}
function finalizePlayableQuality(s){
  if(s.chartProgress>=100&&s.artProgress>=100&&typeof s.playableQuality!=="number"){
    let expected=projectedPlayableQuality(s);
    let expectedWithoutAffection=projectedPlayableQuality(s,{includeMemberAffection:false});
    // 最终生成时加入明显浮动；极高分仍封顶100。
    let variance=rnd(.82,1.18);
    let withoutAffection=clamp(expectedWithoutAffection*variance,0,100);
    let withAffection=clamp(expected*variance,0,100);
    s.playableQuality=withoutAffection>=92?withoutAffection:Math.min(92,withAffection);
    log(`《${s.name}》谱面与美术均已完成：生成可玩质量 ${s.playableQuality.toFixed(1)}。`);
  }
}
function generatePlayOnRelease(s){
  if(typeof s.play==="number")return s.play;
  return Math.max(1,s.attention*(.45+s.quality*.08)*(typeof s.playableQuality==="number"?s.playableQuality/80:1));
}

function buildComposerRoster(previous=[]){
  let oldByName=new Map((previous||[]).map(c=>[c.name,c]));
  return COMPOSER_MASTER.map(base=>{
    let old=oldByName.get(base.name);
    let c=JSON.parse(JSON.stringify(base));
    if(old){
      c.affection=Number(old.affection)||0;
      c.sickUntil=Number(old.sickUntil)||0;
      c.depressedUntil=Number(old.depressedUntil)||0;
      c.depressionCooldownUntil=Number(old.depressionCooldownUntil)||0;
      c.collabs=Number(old.collabs)||0;
      c.comfortCount=Number(old.comfortCount)||0;
      c.lastExpediteDay=Number.isFinite(old.lastExpediteDay)?old.lastExpediteDay:-9999;
      c.expediteBlockedUntil=Number.isFinite(old.expediteBlockedUntil)?old.expediteBlockedUntil:0;
      let bought=new Map((old.portfolio||[]).map(p=>[p.name,!!p.bought]));
      c.portfolio.forEach(p=>{if(bought.has(p.name))p.bought=bought.get(p.name)});
    }
    if(!Number.isFinite(c.lastExpediteDay))c.lastExpediteDay=-9999;
    if(!Number.isFinite(c.expediteBlockedUntil))c.expediteBlockedUntil=0;
    return c
  })
}
function syncSongCreatorAttribution(){
  let sideSleep=state.composers.find(c=>c.name==="侧睡");
  for(const s of (state.library||[])){
    if(s.source==="tutorial"&&sideSleep)s.composerId=sideSleep.id;
  }
}
function syncComposerMasterData(){state.composers=buildComposerRoster(state.composers);syncSongCreatorAttribution()}
function composerDisplayOrder(){
  return state.composers.slice().sort((a,b)=>{
    if(a.name==="侧睡")return b.name==="侧睡"?0:-1;
    if(b.name==="侧睡")return 1;
    if(a.name==="shcad")return b.name==="shcad"?0:-1;
    if(b.name==="shcad")return 1;
    return a.name.localeCompare(b.name,"en",{sensitivity:"base",numeric:true})
  })
}
function seed(){
state.composers=buildComposerRoster([]);
let tutorialComposer=state.composers.find(c=>c.name==="侧睡");
let tutorial=makeSong("教程曲",3,"抒情",0,tutorialComposer?.id??null,"tutorial");
tutorial.chartProgress=0;
tutorial.artProgress=0;
tutorial.alpha=false;
tutorial.alphaStatus="idle";
tutorial.installed=false;
tutorial.installedDay=null;
state.library=[tutorial];

}
function grantStoryCapacityForSong(s){
  if(!s||s.storyCapacityGranted)return 0;
  s.storyCapacityGranted=true;
  let gain=GAME_RULES.rollStoryCapacityGain(s.source,s.quality);
  if(gain<=0)return 0;
  state.storyWordCap+=gain;
  log(`收录《${s.name}》后，游戏剧情字数上限增加 ${fmt(gain)} 字。`,"blue");
  return gain
}
function onSongAddedToLibrary(s){
  if(!s)return;
  grantStoryCapacityForSong(s);
  fulfillMemberSongWishes(s);
  if(s.source==="tutorial"||state.firstNonTutorialSongHintDone)return;
  state.firstNonTutorialSongHintDone=true;
  log("曲师侧睡给你发了一条私信留言。他关照你，每首歌曲都得拥有谱面与封面，而你可以将其分配给谱师与美术推进工作。如果你觉得画封面太耗时间，也可以在曲师的“作品集”里购买自带封面的歌曲。","blue")
}
function onFirstChartCompleted(){
  if(state.firstChartCompleteHintDone)return;
  state.firstChartCompleteHintDone=true;
  log("曲师侧睡提醒你，如果谱面的结果不尽人意，可以通过alpha测试略微抬高它的质量。但也不能过分依赖alpha测试，因为它能达到的效果有限。","blue")
}
function installedSongs(){return state.library.filter(s=>s.installed)}
function setMemberMotivated(m){
  if(!m)return;
  m.status="干劲满满";
  m.statusDays=0;
  m._statusChangedDay=state.day;
  if(m.role==="copy")m.motivatedUntilDay=state.day+GAME_RULES.copywriterRules.motivationDays
}
function expireCopywriterMotivation(m){
  if(!m||m.role!=="copy"||!Number.isFinite(m.motivatedUntilDay)||state.day<m.motivatedUntilDay)return;
  if(m.status==="干劲满满"){
    m.status="正常";m.statusDays=0;m._statusChangedDay=state.day
  }
  if(m._statusBeforeOccupation==="干劲满满"){
    m._statusBeforeOccupation="正常";m._statusDaysBeforeOccupation=0
  }
  m.motivatedUntilDay=0
}
function clearAllMemberDoubts(){
  for(const m of state.members){
    if(m.status==="疑虑"){
      m.status="正常";
      m.statusDays=0;
      m._statusChangedDay=state.day
    }
    if(m._statusBeforeOccupation==="疑虑"){
      m._statusBeforeOccupation="正常";
      m._statusDaysBeforeOccupation=0
    }
  }
}
function scheduleUniqueDays(field,start,count){
  if(!Array.isArray(state[field]))state[field]=[];
  for(let i=0;i<count;i++){
    let d=start+i;
    if(!state[field].includes(d))state[field].push(d)
  }
}
function hasShcadSongInLibrary(){
  return state.library.some(s=>getComposer(s.composerId)?.name==="shcad")
}
function checkPlayerMilestones(){
  let p=Number(state.players)||0;
  if(p>=1000&&!state.playerMilestone1000Done){
    state.playerMilestone1000Done=true;
    clearAllMemberDoubts();
    log("游戏的玩家数量首次突破了1000人！<br>制作组的大家非常开心，但这还只是起点。<br>我们接下来会朝着10000人努力！","gold");
    log(`曲师侧睡发来了祝贺短信！<br>他说之后也一直会在最前线支持《${gameName()}》，并祝你日后事事顺利！`,"green");
    if(hasShcadSongInLibrary()){
      state.shcadMilestoneDiscountPending=true;
      log(`曲师shcad发来了祝贺短信！<br>他认为《${gameName()}》给他的作曲生涯也带来了一束光芒。他说下一首歌曲会再次给你打折。`,"green")
    }
    scheduleUniqueDays("milestoneMemberApplicationDays",state.day+1,3)
  }

  if(p>=GAME_RULES.scoreTrackerRules.playerThreshold&&!state.hasScoreTracker){
    state.hasScoreTracker=true;
    state.scoreTrackerBroken=false;
    state.scoreTrackerRepairProgress=100;
    state.scoreTrackerFailureDays=[];
    log(`社区开始制作《${gameName()}》的查分器。`,"blue")
  }

  if(p>=10000&&!state.playerMilestone10000Done){
    state.playerMilestone10000Done=true;
    clearAllMemberDoubts();
    log(`游戏的玩家数量首次突破了10000人。<br>说实话，制作组的大家从来没想到会有今天，开心之余也开始感慨幸亏一路坚持了下来。<br>我们的下一个目标会是几万人？十万人？<br>不论如何，这款音游也终于在圈内站稳了脚跟。《${gameName()}》将由你带领至故事的下一篇章。`,"gold");
    scheduleUniqueDays("milestoneComposerOfferDays",state.day+1,3)
  }

  if(p>=100000&&!state.playerMilestone100000Done){
    state.playerMilestone100000Done=true;
    clearAllMemberDoubts();
    log(`游戏的玩家数量首次突破了100000人。<br>这是由你创造的奇迹。<br>但在这一路上，你是否回望了过往？<br>你迎合过多少合作对象？有没有辜负任何玩家的期待？有没有牺牲你的组员的梦想与努力？<br>事实上，尽管世人总是乐意为这些问题给出自己的主观答案，但它们或许本就没有对错；而不存在对错的问题，也不该因为事实而被口诛笔伐。<br>等待着你的前路是无尽的，而你的梦想也是无尽的；希望你在追随前者的旅途上，永远不要忘记后半句话也成立。<br>《${gameName()}》所经历的，是地表最低难度的非商业音游运营旅程。`,"gold");
    scheduleUniqueDays("milestoneComposerOfferDays",state.day+1,3);
    log("游戏制作者：杉原夜季（Kiyotsuki）<br>特别鸣谢：《梦见霖音：Milthm》制作组<br><br>祝贺你，恭喜第一阶段通关！","gray")
  }
}
function milestoneIncomingEligible(c){
  if(!c||composerHasActiveCommission(c.id))return false;
  if(state.incomingOffers.some(o=>o.composerId===c.id))return false;
  if(state.day<c.depressedUntil)return false;
  if(state.day<c.sickUntil&&c.affection<60)return false;
  return true
}
function processMilestoneDailyRewards(){
  if((state.milestoneMemberApplicationDays||[]).includes(state.day)){
    let role=chance(.5)?"chart":"art";
    let rarity=rollRecruitRarity();
    createMemberApplication(role,rarity,`有${role==="chart"?"谱师":"美术"}主动申请加入制作组！`);
    state.milestoneMemberApplicationDays=state.milestoneMemberApplicationDays.filter(d=>d!==state.day)
  }

  if((state.milestoneComposerOfferDays||[]).includes(state.day)){
    let eligible=state.composers.filter(milestoneIncomingEligible);
    if(eligible.length){
      let c=eligible[Math.floor(Math.random()*eligible.length)];
      createIncomingOffer(c,{origin:"player-milestone"})
    }
    state.milestoneComposerOfferDays=state.milestoneComposerOfferDays.filter(d=>d!==state.day)
  }
}
function recalcPublic(){
  applyPopulationCaps();
  let arr=installedSongs(),a=0,d=0,p=0,g=0,w=0;
  let avgAtt=arr.length?arr.reduce((z,s)=>z+Math.max(1,s.attention),0)/arr.length:1;
  for(const s of arr){let wt=Math.max(1,s.attention),rel=wt/avgAtt;a+=s.attention;d+=s.discussion*rel;p+=s.play*rel;g+=s.good*wt;w+=wt}
  state.fans=Math.max(0,a+arr.length+state.metaFans);
  state.discussion=Math.max(0,d+arr.length+state.metaDiscussion);
  let rawPlayers=Math.max(0,p+arr.length+state.metaPlayers);
  let rawRating=Math.max(0,(w?g/w:0)+arr.length+state.metaRating);
  if(rawPlayers<state.playerFloor){
    if(state.playerFloorShield){let oldFloor=state.playerFloor;state.playerFloor*=.8;state.playerFloorShield=false;state.players=oldFloor}else state.players=Math.max(rawPlayers,state.playerFloor)
  }else state.players=rawPlayers;
  if(rawRating<state.ratingFloor){
    if(state.ratingFloorShield){let oldFloor=state.ratingFloor;state.ratingFloor*=.8;state.ratingFloorShield=false;state.rating=oldFloor}else state.rating=Math.max(rawRating,state.ratingFloor)
  }else state.rating=rawRating;
  let extra=0,dm=1;
  for(const e of state.temporaryPlayerEffects){
    if(state.day<=e.discussUntil)dm=Math.max(dm,e.discussMul);
    if(state.day<=e.playerHoldUntil)extra+=e.extraPlayers;
    else if(state.day<=e.fadeUntil)extra+=e.extraPlayers*clamp(1-(state.day-e.playerHoldUntil)/(e.fadeUntil-e.playerHoldUntil),0,1)
  }
  state.discussion*=dm;
  if(state.day<=(state.exMemberScandalDiscussUntil||0)){
    state.discussion*=1+(state.exMemberScandalDiscussScale||1)
  }
  if(state.day<(state.leakDiscussionUntil||0)){
    state.discussion*=GAME_RULES.betaLeakRules.discussionBuffMultiplier
  }
  state.players+=extra;
  if(state.day<=state.severeBugUntil)state.players*=.10;
  if(!state.hasReleasedUpdate)state.players=0;
  checkPlayerMilestones();
}
function updateFloors(){
  let strength=clamp(state.stickiness/100,0,1);
  state.playerFloor=Math.max(state.playerFloor,state.players*strength*.35);
  state.ratingFloor=Math.max(state.ratingFloor,state.rating*strength*.55);
}
function recalcArt(){
  let songs=installedSongs();
  if(!songs.length){
    state.artPursuit=clamp(100+(state.artEventBonus||0),0,110);
    return
  }
  const abstractPenalty={0:0,1:2,2:6,3:12,4:30,5:80};
  let total=0;
  for(const s of songs){
    let abs=clamp(Math.round(Number(s.abstract)||0),0,5);
    let q=clamp(Math.round(Number(s.quality)||1),1,5);
    let qualityBonus=q===5?8:q===4?4:0;
    total+=100-(abstractPenalty[abs]||0)+qualityBonus;
  }
  let base=total/songs.length;
  state.artPursuit=clamp(base+(state.artEventBonus||0),0,110)
}
function artMods(){let stick=1,expect=1,sponsor=1,ratingGrowth=1;if(year()>=2){if(state.artPursuit>99){stick=1.5;expect=2;sponsor=3}else if(state.artPursuit>90){stick=1.4;expect=1.3;sponsor=1.5}else if(state.artPursuit>80)stick=1.3;else if(state.artPursuit>70){stick=1.2;expect=1.2}if(state.artPursuit<30){expect=.7;ratingGrowth=.7}if(state.artPursuit<10)sponsor=0}return{stick,expect,sponsor,ratingGrowth}}
function styleState(){
  if(year()<2)return{name:"无",playerMul:1,stickyMul:1,dominant:null};
  let c={灼热:0,抒情:0,冷冽:0},a=installedSongs();
  if(!a.length)return{name:"多元发展",playerMul:1.1,stickyMul:1,dominant:null};
  a.forEach(s=>c[s.style]++);let total=a.length,dom=STYLE.reduce((x,y)=>c[x]>=c[y]?x:y),pct=c[dom]/total;
  if(pct>.70){
    let recent=[...a].sort((x,y)=>(y.installedDay||0)-(x.installedDay||0));
    let last3=recent.slice(0,3),last10=recent.slice(0,10);
    let broken=(last3.length===3&&last3.every(s=>s.style!==dom))||last10.filter(s=>s.style!==dom).length>=4;
    if(broken)return{name:`${dom}·风格显著（专一效果受抑制）`,playerMul:.85,stickyMul:1.1,dominant:dom};
    return{name:`${dom}·风格专一`,playerMul:.70,stickyMul:1.2,dominant:dom}
  }
  if(pct>.50)return{name:`${dom}·风格显著`,playerMul:.85,stickyMul:1.1,dominant:dom};
  if(STYLE.every(x=>c[x]/total<.40))return{name:"多元发展",playerMul:1.1,stickyMul:1,dominant:null};
  return{name:"无",playerMul:1,stickyMul:1,dominant:null}
}
function spendAllowed(amount){
  if(state.bankrupt)return false;
  if(state.money>0)return true;
  return amount<=1500;
}
function canSpendMoney(amount){
  if(!spendAllowed(amount)){
    if(state.bankrupt)log("破产状态（将存款积累到20000解除破产状态）下无法进行这项支出。");
    else log("存款≤0时无法进行花费超过1500的行动。");
    return false
  }
  return true
}
function setJob(v){
  if(state.day < (state.jobLockedUntil||1)){
    log(`当前主业仍在锁定期，最早可在第 ${state.jobLockedUntil} 天修改。`);
    document.getElementById("jobSelect").value=state.job;
    render();
    return;
  }
  if(v===state.job){render();return}
  state.job=v;
  let lockDays=v==="easy"?7:v==="normal"?30:v==="hard"?365:0;
  state.jobLockedUntil=state.day+lockDays;
  if(lockDays>0)log(`已选择${v==="easy"?"短期零工":v==="normal"?"中期工作":"长期合同"}主业，接下来 ${lockDays} 天内不能修改主业。`);
  else log("已切换为家里蹲主业。");
  render()
}
function applyJobDay(){
  let cycleDay=((state.day-1)%7)+1;
  if(state.job==="home"){
    state.money-=100;
    state.fatigue=Math.max(0,state.fatigue-10);
  }else if(state.job==="easy"){
    let inc=200;
    if(year()>=4){
      let h=Math.floor((state.day-1-4*365)/(365/2))+1;
      if(year()<=8)inc+=Math.max(0,h)*50;
      else{
        let first=Math.floor((9*365-4*365)/(365/2))*50,l=Math.floor((state.day-1-9*365)/(365/2))+1;
        inc+=first+Math.max(0,l)*25
      }
    }
    state.money+=inc;
    state.fatigue=Math.max(0,state.fatigue-5);
  }else if(state.job==="normal"){
    if(cycleDay===1)state.fatigue+=20;
    if(cycleDay===6||cycleDay===7)state.fatigue=Math.max(0,state.fatigue-30);
    if(isMonthStart()){
      let extraYears=Math.max(0,year()-3);
      state.money+=8000*Math.pow(1.08,extraYears)
    }
  }else{
    let extraYears=Math.max(0,year()-3),wf=50+Math.min(40,extraYears);
    if(cycleDay===1)state.fatigue+=wf;
    if(cycleDay===7)state.fatigue=Math.max(0,state.fatigue-60);
    if(isMonthStart()){
      state.money+=12000*Math.pow(1.10,extraYears);
      for(const m of state.members)changeMemberAffection(m,1,{positiveCap:40})
    }
    if(dayOfYear()===365)state.money+=18000
  }
}
function serviceMonthlyCost(){if(!isMonthStart())return;let c={vpn:50,translation:100,takeout:200,workspace:1000,sponsor:50,course:3000};Object.keys(c).forEach(k=>{if(state.services[k])state.money-=c[k]})}
function toggleService(k){
  let c={vpn:50,translation:100,takeout:200,workspace:1000,sponsor:50,course:3000}[k];
  if(!state.services[k]){
    if(!canSpendMoney(c))return;
    state.money-=c;state.services[k]=true
  }else state.services[k]=false;
  render()
}
function sponsorship(){if(!isMonthStart())return;state.sponsorIncome=0;if(!state.services.sponsor||state.artPursuit<10)return;if(state.stickiness>=40){let pp=Math.min(.2,.01*(1+state.stickiness/25));state.sponsorIncome=state.players*pp*artMods().sponsor*designSponsorMultiplier();state.money+=state.sponsorIncome;if(state.sponsorIncome>2000){let e=state.sponsorIncome-2000;state.expectation+=(e>6000?6000/300+(e-6000)/600:e/300)}}}
function bankruptcyCheck(){if(state.money<=-20000&&!state.bankrupt){if(state.sponsorIncome>3000&&state.day-state.bailoutLastDay>=1095){state.money=0;state.bailoutLastDay=state.day;log("救命保底：赞助收入满足条件，存款恢复为0。")}else{state.bankrupt=true;log("进入破产状态（将存款积累到20000解除破产状态）。")}}if(state.bankrupt&&state.money>=20000){state.bankrupt=false;log("解除破产状态（将存款积累到20000解除破产状态）。")}}
function computerBroken(){
  return state.day<(state.computerBrokenUntil||0)
}
function computerDaily(){
  if((state.computerBrokenUntil||0)>0){
    if(state.day>=state.computerBrokenUntil){
      state.computerBrokenUntil=0;
      state.computerRepairCooldownUntil=state.day+180;
      log("电脑终于修好了！","green")
    }else{
      return
    }
  }

  if(state.day<366)return;
  if(state.job==="normal"||state.job==="hard")return;
  if(state.day<(state.computerRepairCooldownUntil||0))return;
  if(chance(.0001)){
    state.computerBrokenUntil=state.day+3;
    log("电脑坏了！这下糟糕了。","red")
  }
}
function computerActionBlocked(){
  if(!computerBroken())return false;
  log("电脑坏了，目前无法进行这项操作。");
  return true
}
function freeActionEvent({isCopyAction=false}={}){
  // “你爹来了”与“组员多才多艺”同一次行动严格互斥；
  // 两类事件当天合计最多触发2次。
  if((state.freeMemberEventsToday||0)>=2)return false;

  let l3=state.members.filter(m=>m.rarity===3&&!memberOccupied(m));
  let l4=state.members.filter(m=>m.rarity===4&&!memberOccupied(m));
  let seniorCopywriters=state.members.filter(m=>m.role==="copy"&&m.rarity>=3&&!memberOccupied(m));
  let boosted=isCopyAction&&seniorCopywriters.length>0;
  const pickMemberForEvent=pool=>{
    if(isCopyAction&&seniorCopywriters.length&&chance(GAME_RULES.copywriterRules.seniorEventPreferredChance)){
      return seniorCopywriters[Math.floor(Math.random()*seniorCopywriters.length)]
    }
    return pool[Math.floor(Math.random()*pool.length)]
  };

  if(l4.length&&chance(GAME_RULES.copyActionEventChance(Math.min(.5,l4.length*.04),boosted))){
    let m=pickMemberForEvent(l4);
    state.freeMemberEventsToday=(state.freeMemberEventsToday||0)+1;
    state.temporaryCoordBonus=20;state.temporaryCoordBonusUntil=state.day+7;
    log(`你爹来了：${memberName(m)} 接手了这次操作。`,"blue");
    return "free4"
  }else if(l3.length){
    let multiChance=Math.min(.4,l3.length*.04);
    if(l3.some(m=>state.day-(m.actualJoinDay??m.joinDay)<=7))multiChance=Math.min(1,multiChance*3);
    if(chance(GAME_RULES.copyActionEventChance(multiChance,boosted))){
      let m=pickMemberForEvent(l3);
      state.freeMemberEventsToday=(state.freeMemberEventsToday||0)+1;
      let monthIndex=currentOperationMonth();
      if(state.fatigue>100&&state.multiTalentAffectionMonthIndex!==monthIndex){
        changeMemberAffection(m,2);
        state.multiTalentAffectionMonthIndex=monthIndex
      }
      log(`组员多才多艺：${memberName(m)} 接手了这次操作。`,"blue");
      return "free3"
    }
  }
  return false
}
function burnoutCopyCheck(){let t=state.money<=0?80:100;if(state.fatigue<=t)return;let p=clamp(.05+(state.fatigue-t)/(200-t)*.45,.05,.5);if(chance(p)){state.metaDiscussion+=Math.max(20,state.discussion*.4);state.metaFans+=Math.max(10,state.fans*.3);state.metaRating-=Math.max(10,state.rating*.45);applyRandomMemberAffection(m=>m.affection<80,3,-3);log("精神过低：文案暴雷。")}}
function pendingAnnouncementPackage(){
  return state.packages
    .filter(p=>p.status==="等待上架"&&state.day<(p.releaseDay||Infinity))
    .sort((a,b)=>(a.releaseDay||Infinity)-(b.releaseDay||Infinity))[0]||null
}
function announcementCooldownLeft(){
  return Math.max(0,7-(state.day-(state.lastAnnouncementDay||-9999)))
}
function publishDerivativeAnnouncement(){
  let p=pendingAnnouncementPackage();
  return publishUpdateAnnouncementWithDerivative(p)
}
function publishUpdateAnnouncementWithDerivative(p){
  if((state.derivativeCount||0)<=0)return false;
  if(!p||p.status!=="等待上架")return false;
  let left=announcementCooldownLeft();
  if(left>0){log(`距离上次发布公告还不到7天，还需要等待${left}天。`);return false}
  if(!spendAP(2))return false;
  state.fatigue+=5;
  state.lastAnnouncementDay=state.day;
  state.derivativeCount--;
  p.announcementFanBonus=(p.announcementFanBonus||0)+.10;
  if(!p.reviewEventChecked)p.announcementBeforeReview=true;
  state.temporaryPlayerEffects.push({type:"衍生图公告",until:state.day+15,stickinessBonus:.01});
  log("你发布了一条带有衍生图的更新公告。玩家更加期待这次更新！");
  render();
  return true
}
function publishUpdateAnnouncement(p){
  if(!p||p.status!=="等待上架")return false;
  let left=announcementCooldownLeft();
  if(left>0){log(`距离上次发布公告还不到7天，还需要等待${left}天。`);return false}
  if(!spendAP(2))return false;
  state.fatigue+=5;
  state.lastAnnouncementDay=state.day;
  p.announcementFanBonus=(p.announcementFanBonus||0)+.05;
  if(!p.reviewEventChecked)p.announcementBeforeReview=true;
  log("你发布了一条关于游戏更新的公告。玩家开始注意到将有一场更新到来！");
  render();
  return true
}
function currentOperationMonth(){
  return Math.floor((state.day-1)/30)+1
}
function ensureCopyFanMonth(){
  let m=currentOperationMonth();
  if(state.copyFanMonthIndex!==m){
    recalcPublic();
    state.copyFanMonthIndex=m;
    state.copyFanMonthStartFans=Math.max(0,Number(state.fans)||0);
    state.copyFanGainThisMonth=0
  }
}
function addCopyFanGain(rawGain){
  ensureCopyFanMonth();
  let month=currentOperationMonth();
  let cap=month<=3?100:Math.max(0,state.copyFanMonthStartFans*1.2);
  let remain=Math.max(0,cap-(state.copyFanGainThisMonth||0));
  let actual=Math.min(Math.max(0,rawGain),remain);
  state.metaFans+=actual;
  state.copyFanGainThisMonth=(state.copyFanGainThisMonth||0)+actual;
  return actual
}
function writeCopy(){
  let announcementPackage=pendingAnnouncementPackage();
  if(announcementPackage){
    publishUpdateAnnouncement(announcementPackage);
    return
  }
  let free=freeActionEvent({isCopyAction:true});
  let copyYearCost=Math.min(10,Math.max(0,year()));
  let apCost=2+copyYearCost;
  let spiritCost=GAME_RULES.copyWritingSpiritCost(year());
  let operationFatigue=free?0:state.fatigue;
  if(!free&&!spendAP(apCost))return;
  if(!free)state.fatigue+=spiritCost;
  state.copyActionCount=(state.copyActionCount||0)+1;
  if(!state.copywriterDiscoveryHintShown&&state.copyActionCount>=5){
    state.copywriterDiscoveryHintShown=true;
    log(`你的精彩动态文案吸引到了一些剧情写手。在不久远的未来，他们或许会有兴趣加入《${gameName()}》。试着写更多的动态，并建立起制作组团队的雏形吧！`,"blue")
  }
  updateCopyRecruitmentUnlock();
  state.expectation+=3*artMods().expect;
  let dg=designGrowthMultipliers();
  state.metaDiscussion+=10*dg.discussion;
  addCopyFanGain(5*growthSpeedMultiplier()*dg.fan);
  if(!free)burnoutCopyCheck();
  else log(`${free==="free4"?"你爹来了":"组员多才多艺"}：本次写动态不消耗行动点，且本次操作精神消耗视为0。`,"blue");
  render()
}
function writeProgram(){
  if(computerActionBlocked())return;
  if(!state.designConceptConfirmed){
    log("必须先在页面最顶端完成“游戏设计理念”，才能开始写程序。");
    document.getElementById("designConceptPanel")?.scrollIntoView({behavior:"smooth",block:"start"});
    return
  }
  let base=programActionBaseCost(),free=freeActionEvent();
  let operationFatigue=free?0:state.fatigue;
  if(!free&&!spendAP(base))return;
  if(!free)state.fatigue+=20+(state.takeoutProgramDiscount?10:0);
  state.programWritesToday=(state.programWritesToday||0)+1;
  let gain=6*(state.inspiration?1.5:1);
  state.bugChance=clamp(state.bugChance-gain,0,100);
  state.programQualityBoost+=.5*(state.inspiration?1.5:1);
  advanceProgramDevelopment();
  reduceScoreTrackerFailureChanceDuringBeta();
  advanceScoreTrackerRepair();
  state.inspiration=false;state.takeoutProgramDiscount=false;
  if(free)log(`${free==="free4"?"你爹来了":"组员多才多艺"}：本次写程序不消耗行动点，且本次操作精神消耗视为0。`,"blue");
  render()
}
function sideGigStudyMultiplier(){
  let n=Math.max(0,(state.programStudyCount||0)+(state.artStudyCount||0));
  if(n<=200)return 1+.30*(n/200);
  if(n<=1000)return 1.30+.30*((n-200)/800);
  return 1.60
}
function sideGig(){
  if(!spendAP(8))return;
  state.fatigue+=40;
  let v=100*sideGigStudyMultiplier()*rnd(.4,1.6);
  state.money+=v;
  log(`赚外快获得 ${Math.floor(v)}。`);
  render()
}
function studyProgram(){
  if(computerActionBlocked())return;
  let cost=state.services.course?3:5;
  if(!spendAP(cost))return;
  let fatigueGain=(state.studyActionsToday||0)>=2?15:30;
  state.studyActionsToday=(state.studyActionsToday||0)+1;
  state.fatigue+=fatigueGain;
  state.programStudyCount=(state.programStudyCount||0)+1;
  // “学程序”基础每次程序水平+1；原有“灵感爆棚”仍使本次收益为1.5倍。
  state.tech+=state.inspiration?1.5:1;
  state.inspiration=false;
  render()
}
function createDerivative(){
  if(state.artStudyProgress<100)return;
  let free=freeActionEvent();
  let cost=state.takeoutProgramDiscount?7:8;
  if(!free&&!spendAP(cost))return;
  if(!free)state.spirit=Math.max(0,state.spirit-30);
  state.takeoutProgramDiscount=false;

  let gain=rnd(3,8);
  state.derivativeProgress+=gain;
  log(`花了点时间，为《${state.gameName||"游戏"}》画了一会衍生图。`);

  if(state.derivativeProgress>=100){
    state.derivativeCount++;
    state.derivativeProgress=0;
    log(`新的衍生图创作完毕了！当前可分配的衍生图数量：${state.derivativeCount}`,"green");
  }

  if(free)log(`${free==="free4"?"你爹来了":"组员多才多艺"}：本次创作衍生图不消耗行动点。`,"blue");
  render()
}
function studyArt(){
  if(computerActionBlocked())return;
  let cost=state.services.course?7:10;
  if(!spendAP(cost))return;
  let fatigueGain=(state.studyActionsToday||0)>=2?25:50;
  state.studyActionsToday=(state.studyActionsToday||0)+1;
  state.fatigue+=fatigueGain;
  state.artStudyCount=(state.artStudyCount||0)+1;
  if(!state.artStudyStarted)state.artStudyStarted=true;
  let before=state.artStudyProgress;
  let gain=.5;
  let seniorArt=state.members.filter(m=>m.role==="art"&&m.rarity>=3);
  if(seniorArt.length)gain+=.3;
  if(seniorArt.some(m=>state.day-m.joinDay>=365))gain+=.4;
  state.artStudyProgress=clamp(state.artStudyProgress+gain,0,100);
  if(before<50&&state.artStudyProgress>=50&&!state.artStudy50Notified){
    state.artStudy50Notified=true;
    log("学会了美术！现在已经可以自己给歌曲提供美术了！","gold");
  }
  if(before<100&&state.artStudyProgress>=100&&!state.artStudy100Notified){
    state.artStudy100Notified=true;
    log("彻底学会了美术！","gold");
  }
  render()
}
function advanceProgramDevelopment(){
  if(!state.hasReleasedUpdate){
    if(state.gameCoreProgress>=100)return;
    let before=state.gameCoreProgress;
    state.gameCoreProgress=clamp(state.gameCoreProgress+(1+state.tech*0.1)*designProgramMultiplier("core"),0,100);
    if(before<100&&state.gameCoreProgress>=100&&!state.gameCoreCompleteNotified){
      state.gameCoreCompleteNotified=true;
      log("游戏本体制作完成！","gold");
    }
    return;
  }
  if(state.chartEditorUnlocked&&!state.chartEditorComplete){
    let before=state.chartEditorProgress;
    let gain=Math.min(6,(2+state.tech*0.15)*designProgramMultiplier("v1"));state.chartEditorProgress=clamp(state.chartEditorProgress+gain,0,100);
    if(before<100&&state.chartEditorProgress>=100){
      state.chartEditorComplete=true;
      state.chartEditorV2Unlocked=true;
      if(!state.chartEditorCompleteNotified){
        state.chartEditorCompleteNotified=true;
        log("游戏制谱器制作完成！","gold");
      }
    }
    return;
  }
  if(state.chartEditorV2Unlocked&&!state.chartEditorV2Complete){
    let before=state.chartEditorV2Progress;
    let gain=Math.min(4,(0.5+state.tech*0.05)*designProgramMultiplier("v2"));state.chartEditorV2Progress=clamp(state.chartEditorV2Progress+gain,0,100);
    if(before<100&&state.chartEditorV2Progress>=100){
      state.chartEditorV2Complete=true;
      if(!state.chartEditorV2CompleteNotified){
        state.chartEditorV2CompleteNotified=true;
        log("游戏制谱器制作完成！","gold");
      }
    }
  }
}
function personallyDraw(songId){
  if(computerActionBlocked())return;
  let s=getSong(songId);if(!s||s.installed)return;
  if(state.artStudyProgress<50)return log("学习美术进度达到50%后才能亲自画图。");
  if(s.artProgress>=100)return log("这首歌曲的美术已经完成。");
  if(!spendAP(6))return;
  if(state.artStudyProgress<100){
    if(typeof s.playableQuality==="number")s.playableQuality=GAME_RULES.personalArtQualityAfterPenalty(s.playableQuality);
    else s._personalArtPenalty=Math.round(((s._personalArtPenalty||0)+.7)*1000)/1000;
  }
  s.artProgress=Math.min(100,s.artProgress+5);
  log(`亲自画图：《${s.name}》美术进度 +5%${state.artStudyProgress<100?"；会使成品可玩质量下降":""}。`);
  if(s.artProgress>=100){
    if(s.artMemberId){
      let m=getMember(s.artMemberId);
      if(m)m.assignedSongIds=m.assignedSongIds.filter(id=>id!==s.id);
      s.artMemberId=null;
    }
    finalizePlayableQuality(s);
  }
  render()
}
function playRhythm(){
  if(!spendAP(2))return;
  state.rhythmPlayCount=(state.rhythmPlayCount||0)+1;
  state.fatigue=Math.max(0,state.fatigue-40-(!state.playedRhythmToday&&state.takeoutRecruitBuff?10:0));
  state.playedRhythmToday=true;
  let teammates=state.members.filter(m=>m.role==="chart"&&[3,4].includes(m.rarity));
  if(teammates.length&&chance(.01)){
    let m=teammates[Math.floor(Math.random()*teammates.length)];
    changeMemberAffection(m,1);
    log(`打音游的时候在多人模式匹配到了同制作组的${m.name}，狠狠切磋了几把，酣畅淋漓。`,"blue")
  }
  if(chance(.03+state.rating/10000+state.tech/1000)){state.inspiration=true;log("灵感爆棚。")}
  render()
}
function takeout(){
  if(!state.services.takeout)return log("需要外卖平台会员。");
  if(state.takeoutBlockedToday)return log("今天已经吃坏肚子，不能再点外卖了。");
  if((state.takeoutCountToday||0)>=6)return log("今天已经点过6次外卖了。");
  if(!spendAP(1))return;

  state.takeoutCountToday=(state.takeoutCountToday||0)+1;
  let trendyTakeout=chance(.05);
  state.fatigue=Math.max(0,state.fatigue-GAME_RULES.takeoutSpiritRecovery(trendyTakeout));
  state.takeoutRecruitBuff=true;
  state.takeoutProgramDiscount=true;
  if(trendyTakeout)log("吃到国潮外卖了，心情很差。","red");

  if(state.takeoutCountToday>=4){
    state.overeatingStacks=(state.overeatingStacks||0)+1
  }

  let sickChance=Math.min(1,(state.overeatingStacks||0)*.20);
  if((state.overeatingStacks||0)>0&&chance(sickChance)){
    state.fatigue+=30;
    state.takeoutBlockedToday=true;
    log("吃得太多了！肚子好痛，没法正常干活了。","red")
  }
  render()
}
function resetTakeoutForNewDay(){
  state.takeoutCountToday=0;
  state.takeoutBlockedToday=false;
  state.overeatingStacks=Math.max(0,(state.overeatingStacks||0)-2)
}
function memberRoleName(role){return role==="chart"?"谱师":role==="art"?"美术":"文案"}
function changeMemberAffection(m,delta,options={}){
  if(!m)return 0;
  let result=GAME_RULES.nextMemberAffection(
    {affection:m.affection,trustLocked:m.affectionTrustLocked},
    delta,
    options
  );
  m.affection=result.affection;
  m.affectionTrustLocked=result.trustLocked;
  confessMemberLeak(m);
  return m.affection
}
function confessMemberLeak(m){
  if(!GAME_RULES.memberShouldConfessLeak(m))return false;
  m.confessedLeak=true;
  m.leaker=false;
  m.potentialInsider=false;
  log(`${m.name}向你承认，他曾经泄露过《${state.gameName||"未命名游戏"}》的更新内容。他表示非常抱歉，并保证以后再也不会发生第二次。他的坦白使你感到很欣慰。`,"blue");
  return true
}
function memberLeakConfessionDaily(){
  for(const m of state.members)confessMemberLeak(m)
}
function applyRandomMemberAffection(predicate,count,delta){
  let pool=state.members.filter(predicate);
  for(let i=pool.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]]}
  for(const m of pool.slice(0,count))changeMemberAffection(m,delta)
}
function memberAffectionDaily(){
  for(const m of state.members){
    let joinedAt=Number.isFinite(m.actualJoinDay)?m.actualJoinDay:m.joinDay;
    let membershipDays=Math.max(0,state.day-joinedAt);
    if(membershipDays>0&&membershipDays%30===0)changeMemberAffection(m,-GAME_RULES.memberAffectionRules.naturalDecay,{natural:true});
    if(m.status==="疑虑"||m._statusBeforeOccupation==="疑虑")changeMemberAffection(m,-GAME_RULES.memberAffectionRules.doubtDailyLoss)
  }
}
function fulfillMemberSongWishes(s){
  if(!s)return;
  let composerIds=new Set([s.composerId,s.composer,...(s.composerIds||[])].filter(id=>id!==null&&id!==undefined));
  for(const m of state.members){
    if(!m.recommendComposerId||state.day>(m.recommendComposerDeadline||0)||!composerIds.has(m.recommendComposerId))continue;
    changeMemberAffection(m,10);
    m.recommendComposerId=null;m.recommendComposerDeadline=0;
    log(`收录了${m.name}期待的歌曲，你们的关系更加亲近了。`,"green")
  }
}
function updateCopyRecruitmentUnlock(){
  if(state.copyRecruitUnlocked)return;
  if(!GAME_RULES.canUnlockCopywriterRecruitment(state.copyActionCount,state.members.length))return;
  state.copyRecruitUnlocked=true;
  log("新的成员招聘选项“寻找文案”已经解锁。","green")
}
function recruitProbability(role){let p=.05+state.recruitFail[role]*.05;if(state.designConceptConfirmed&&state.designStyle==="缝合"&&role==="chart"&&year()===0)p+=.05;let f=state.ap/Math.max(1,apCap());p*=role==="art"?.3+.7*(1-f):.3+.7*f;if(state.fatigue>(state.money<=0?80:100))p*=.5;if(state.takeoutRecruitBuff)p*=1.05;if(styleState().name==="多元发展")p*=1.12;return clamp(p,0,1)}
function memberNameAllowed(name,role,rarity){
  if(LEVEL5_CHART_NAME_POOL.includes(name))return role==="chart"&&rarity===5;
  if(LEVEL5_ART_NAME_POOL.includes(name))return role==="art"&&rarity===5;
  if(LEVEL5_COPY_NAME_POOL.includes(name))return role==="copy"&&rarity===5;
  return GENERAL_MEMBER_NAME_POOL.includes(name);
}
function memberNamePoolFor(role,rarity){
  if(role==="chart"&&rarity===5)return [...GENERAL_MEMBER_NAME_POOL,...LEVEL5_CHART_NAME_POOL];
  if(role==="art"&&rarity===5)return [...GENERAL_MEMBER_NAME_POOL,...LEVEL5_ART_NAME_POOL];
  if(role==="copy"&&rarity===5)return [...GENERAL_MEMBER_NAME_POOL,...LEVEL5_COPY_NAME_POOL];
  return GENERAL_MEMBER_NAME_POOL;
}
function memberStartsMinorAtRecruitment({name,role,rarity}){
  return !GAME_RULES.isGuaranteedAdultMember({name,role,rarity})&&GAME_RULES.memberStartsAsMinor(rarity)
}
function usedMemberNames(){
  return new Set((state.members||[]).map(m=>m.name).filter(Boolean)
    .concat((state.applications||[]).map(a=>a.name).filter(Boolean))
    .concat(state.candidate&&state.candidate.name?[state.candidate.name]:[]))
}
function pickUniqueMemberName(role,rarity,excludeName=null){
  let used=usedMemberNames();
  if(excludeName)used.delete(excludeName);
  let tries=0;
  while(tries<100){
    let name=pickMemberName(role,rarity,excludeName);
    if(!used.has(name))return name;
    tries++
  }
  let base=memberRoleName(role);
  let i=1;
  while(used.has(`${base}${i}`))i++;
  return `${base}${i}`
}
function pickMemberName(role,rarity,preferred=null){
  if(preferred&&memberNameAllowed(preferred,role,rarity))return preferred;
  let used=new Set(state.usedMemberNames||[]);
  let allowed=memberNamePoolFor(role,rarity);
  let available=allowed.filter(n=>!used.has(n));
  let pool=available.length?available:allowed;
  let name=pool[Math.floor(Math.random()*pool.length)]||`成员${nextId()}`;
  if(!(state.usedMemberNames||[]).includes(name))state.usedMemberNames.push(name);
  return name
}
function rollRecruitRarity(){
  let p5=state.day<(state.fiveStarRecruitSuppressionUntil||0)?.0125:.05;
  if(chance(p5))return 5;
  // 非5级部分维持原本1~4级之间的相对概率，不因5级抑制而改坏其它等级分布。
  return weighted([[1,.38/.95],[2,.28/.95],[3,.18/.95],[4,.11/.95]])
}
function markFiveStarRecruit(rarity){
  if(rarity===5)state.fiveStarRecruitSuppressionUntil=state.day+90
}
function createMemberApplication(role,rarity,message=null){
  if(!state.applications)state.applications=[];
  let name=pickUniqueMemberName(role,rarity);
  let app={id:nextId(),role,rarity,name,isMinor:memberStartsMinorAtRecruitment({name,role,rarity})};
  state.applications.push(app);
  if(message)log(message,"blue");
  render()
}
function acceptApplication(id){
  let app=(state.applications||[]).find(a=>a.id===id);if(!app)return;
  if(state.members.length>=teamCap())return log("人数已达上限，暂时无法接受这份申请。");
  let joined=createJoinedMember(app);
  state.members.push(joined);
  if(joined.role==="copy")state.hasHadCopywriter=true;
  updateCopyRecruitmentUnlock();
  markFiveStarRecruit(app.rarity);
  state.applications=state.applications.filter(a=>a.id!==id);
  log(`已接受${app.name}的加入申请。`,"blue");
  render()
}
function rejectApplication(id){
  state.applications=(state.applications||[]).filter(a=>a.id!==id);
  render()
}

function recommendationCommissionDaily(){
  if(state.recommendCommissionCooldown>state.day) {
    state.recommendCommissionCooldown--;
    return
  }
  if(state.day<366)return;
  let members=state.members.filter(m=>[2,3,5].includes(m.rarity));
  if(!members.length||!chance(.0001))return;
  let m=members[Math.floor(Math.random()*members.length)];
  let composers=state.composers||[];
  let c=composers.filter(c=>!composerHasActiveCommission(c.id)&&composerReachable(c));
  if(!c.length)return;
  let target=c[Math.floor(Math.random()*c.length)];
  state.recommendCommissionCooldown=45;
  m.recommendComposerId=target.id;
  m.recommendComposerDeadline=state.day+30;
  let more=state.library.some(s=>s.composerId===target.id||s.composerIds?.includes(target.id))?"更多":"";
  let style=target.name;
  log(`制作组成员${m.name}提到，如果我们的游戏能收录${more}${style}的歌曲就好了……`,"blue")
}
function mysteryDonationDaily(){
  if(state.mysteryDonationCooldown>0){
    state.mysteryDonationCooldown--;
    return
  }
  if(state.sponsorIncome<=500||!chance(.005))return;
  let composers=(state.composers||[]).filter(c=>composerReachable(c));
  if(!composers.length)return;
  let c=composers[Math.floor(Math.random()*composers.length)];
  let ratio=.1+(Math.min(100,state.rating)/100)*1.9*Math.random();
  let money=Math.max(state.sponsorIncome*.1,state.sponsorIncome*ratio);
  money=Math.min(money,state.sponsorIncome*2);
  state.money+=money;
  state.mysteryDonationCooldown=90;
  state.mysteryDonationTarget=c.id;
  state.mysteryDonationUntil=state.day+180;
  log(`《${gameName()}》收到了一笔神秘的捐款。对方留言说，如果未来能在游戏里看到${c.name}的曲子就好了。`,"blue")
}

function specialRecruitmentEvents(){
  if(state.day>=16&&!state.hasSearchedMember&&!state.sideSleepSearchHintDone){
    state.sideSleepSearchHintDone=true;
    log("曲师侧睡意识到你现在还在单打独斗。他告诉你：如果曲库添加了新的歌曲，记得在左下角的制作组窗口“找谱师”或“找美术”。","blue")
  }
  if(state.day>=5&&!state.sideSleepNetworkDone&&chance(.10)){
    state.sideSleepNetworkDone=true;
    createMemberApplication("chart",3,"曲师侧睡非常在意企划的动向，并为你举荐了一位谱师，你可以在左下角的制作组窗口查看申请。")
  }
  if(state.day===100&&!state.day100RecruitEventDone){
    state.day100RecruitEventDone=true;
    let role=chance(.5)?"chart":"art";
    createMemberApplication(role,4,"你的企划蒸蒸日上，吸引了一位圈内的大佬申请加入制作组！只不过，管理大佬可能会比你想象的要辛苦，所以要权衡利弊。你可以在左下角的制作组窗口查看申请。")
  }
  // 显示上的“第2年”从第366天开始。
  if(state.day>=366&&state.fans>3000&&chance(.005)){
    let role=chance(.5)?"chart":"art";
    let rarity=rollRecruitRarity();
    createMemberApplication(role,rarity,`有${role==="chart"?"谱师":"美术"}申请加入制作组！`)
  }
}
function searchMember(role){
  if(role==="copy"&&!state.copyRecruitUnlocked)return log("写动态至少10次且制作组人数超过5人后才能寻找文案。");
  if(!state.designConceptConfirmed)return log("必须先完成“游戏设计理念”后才能寻找制作组成员。");
  if(state.bankrupt)return log("破产状态（将存款积累到20000解除破产状态）下无法寻找制作组成员。");
  if(state.members.length>=teamCap())return log("人数已达上限。");
  if(!spendAP(1))return;
  state.hasSearchedMember=true;
  if(chance(recruitProbability(role))){
    state.recruitFail[role]=0;
    let rarity=rollRecruitRarity();
    let name=pickUniqueMemberName(role,rarity);
    state.candidate={role,rarity,name,isMinor:memberStartsMinorAtRecruitment({name,role,rarity})}
  }else{
    state.recruitFail[role]++;
    log("寻找失败。")
  }
  render()
}
function acceptCandidate(){
  let c=state.candidate;if(!c)return;
  if(state.members.length>=teamCap())return log("人数已达上限，暂时无法录用。");
  let joined=createJoinedMember({name:c.name||pickUniqueMemberName(c.role,c.rarity),role:c.role,rarity:c.rarity,isMinor:c.isMinor});
  state.members.push(joined);
  if(joined.role==="copy")state.hasHadCopywriter=true;
  updateCopyRecruitmentUnlock();
  markFiveStarRecruit(c.rarity);
  state.candidate=null;
  log(`已录用${c.rarity}级${memberRoleName(c.role)} ${c.name||""}。`);
  render()
}function rejectCandidate(){state.candidate=null;render()}
let pendingFireMemberId=null;
function openFireMemberDialog(id){
  let m=getMember(id);if(!m||memberOccupied(m))return;
  pendingFireMemberId=id;
  let message=document.getElementById("fireMemberConfirmText");
  if(message)message.textContent=`确定开除成员${m.name}吗？将会消耗3行动点`;
  let dialog=document.getElementById("fireMemberDialog");
  if(dialog&&!dialog.open)dialog.showModal()
}
function closeFireMemberDialog(){
  pendingFireMemberId=null;
  let dialog=document.getElementById("fireMemberDialog");
  if(dialog?.open)dialog.close()
}
function confirmFireMember(){
  let id=pendingFireMemberId;
  closeFireMemberDialog();
  if(id!==null)fireMember(id)
}
function spendFixedAP(cost){
  if(state.ap+1e-9<cost){log("行动点不足。");return false}
  state.ap=Math.max(0,Math.round((state.ap-cost)*1000000)/1000000);
  state.dailySpent=Math.round((state.dailySpent+cost)*1000000)/1000000;
  return true
}
function fireMember(id){
  let i=state.members.findIndex(m=>m.id===id);if(i<0)return;
  let m=state.members[i];
  if(memberOccupied(m)){log(`${m.name}目前正被事务占用，无法开除。`);return}
  let caughtLeaker=!!m.leaker;
  let hasLeakHistory=!!(m.leaker||m.confessedLeak);
  let argumentInvolved=state.day<=(m.argumentInvolvedUntil||0);
  if(!spendFixedAP(GAME_RULES.FIRE_MEMBER_ACTION_COST))return;
  if(argumentInvolved){
    for(const x of state.members){
      if(x.id!==m.id&&state.day<=(x.argumentInvolvedUntil||0))changeMemberAffection(x,5)
    }
    state.teamArgumentUntil=0;
    for(const x of state.members)x.argumentInvolvedUntil=0;
  }
  if(!hasLeakHistory)noteMemberDepartureForScandal(m);
  let opinionMul=argumentInvolved?4:1;
  if(!hasLeakHistory){
    if(m.rarity===4)registerFormerMemberOpinion(m,.002*opinionMul);
    else if([2,3,5].includes(m.rarity))registerFormerMemberOpinion(m,.0005*opinionMul)
  }
  state.library.forEach(s=>{s.chartMemberIds=s.chartMemberIds.filter(x=>x!==id);if(s.artMemberId===id)s.artMemberId=null});
  m.affection=0;m.affectionTrustLocked=false;
  state.members.splice(i,1);
  if(caughtLeaker){
    state.leakerSpiritRecoveryQueue.push({day:state.day+1,amount:100});
    log("你成功开除了制作组内的泄密者。你决定将这个秘密留给自己。","green")
  }
  if(chance(.05)){
    let rarity=Math.min(5,m.rarity+1);
    state.candidate={role:m.role,rarity,name:pickUniqueMemberName(m.role,rarity,m.name),isMinor:GAME_RULES.memberStartsAsMinor(rarity)}
  }
  render()
}
function coordCap(){let b=0;for(const m of state.members){let y=Math.floor(Math.max(0,state.day-m.joinDay-180)/365);b+=Math.min(8,y*2)}return 100+b}
function coordValue(){let v=state.members.reduce((a,m)=>a+RARITY_COORD[m.rarity]+(state.day<=(m.coordExtraUntil||0)?5:0)+(state.day<=(m.lewdCoordUntil||0)?2:0),0)+Math.floor(state.members.length/10)*5;if(state.day<=state.temporaryCoordBonusUntil)v+=Math.min(state.temporaryCoordBonus,Math.max(0,100-v));if(state.day<=(state.teamArgumentUntil||0))v+=5;return Math.min(coordCap(),v)}
function memberOccupied(m){
  return !!m&&state.day<(m.occupiedUntil||0)
}
function releaseMemberOccupation(m){
  if(!m||memberOccupied(m)||m.status!=="事务占用")return;
  m.status=m._statusBeforeOccupation||"正常";
  m.statusDays=Number(m._statusDaysBeforeOccupation)||0;
  m._statusBeforeOccupation=null;
  m._statusDaysBeforeOccupation=0
}
function detachMemberFromAllWork(m){
  if(!m)return;
  for(const sid of [...(m.assignedSongIds||[])]){
    let s=getSong(sid);if(!s)continue;
    s.chartMemberIds=(s.chartMemberIds||[]).filter(id=>id!==m.id);
    if(s.artMemberId===m.id)s.artMemberId=null
  }
  m.assignedSongIds=[]
}
function startMemberOccupation(m,days){
  if(!m||memberOccupied(m))return;
  m._statusBeforeOccupation=m.status||"正常";
  m._statusDaysBeforeOccupation=Number(m.statusDays)||0;
  m.status="事务占用";
  m.occupiedUntil=state.day+days;
  m.lastGuardianPhoneEventDay=state.day;

  detachMemberFromAllWork(m);
  log(`突发情况：${m.name}的手机被家长收走了。${days}天内无法推进工作。`)
}
function academicAbsenceEligible(m){
  return !!m&&GAME_RULES.getMinorEventRateMultiplier({level:m.rarity,isMinor:m.isMinor})>0
}
function startAcademicAbsence(m){
  if(!m)return;
  if(!memberOccupied(m)){
    m._statusBeforeOccupation=m.status||"正常";
    m._statusDaysBeforeOccupation=Number(m.statusDays)||0
  }
  m.status="事务占用";
  m.occupiedUntil=Math.max(m.occupiedUntil||0,state.day+30);
  detachMemberFromAllWork(m);
  log(`${m.name}因为学业原因，必须缺席30天。${m.name}负责的相关工作已暂时停止。`,"blue")
}
function academicAbsenceDaily(){
  // 先兑现此前已经预告过的缺席。
  for(const m of state.members){
    if((m.academicAbsenceScheduledDay||0)===state.day){
      m.academicAbsenceScheduledDay=0;
      if(m.isMinor)startAcademicAbsence(m)
    }
  }

  // 5月1日、12月1日分别对每名符合条件的成员独立进行20%判定。
  let reminderDay=dayOfMonth()===1&&(monthOfYear()===5||monthOfYear()===12);
  if(!reminderDay)return;
  for(const m of state.members){
    if(!academicAbsenceEligible(m))continue;
    if((m.academicAbsenceScheduledDay||0)>state.day)continue;
    let eventMultiplier=GAME_RULES.getMinorEventRateMultiplier({level:m.rarity,isMinor:m.isMinor});
    if(chance(.20*eventMultiplier)){
      m.academicAbsenceScheduledDay=state.day+30;
      log(`${m.name}将在1个月后因学业缺席30天。`,"blue")
    }
  }
}
function isGameCalendarDate(month,day){
  return dayOfYear()===(month-1)*30+day
}
function startGaokaoSprint(m){
  if(!m)return;
  if(!memberOccupied(m)){
    m._statusBeforeOccupation=m.status||"正常";
    m._statusDaysBeforeOccupation=Number(m.statusDays)||0
  }
  m.status="事务占用";
  m.gaokaoSprintActive=true;
  m.occupiedUntil=Math.max(m.occupiedUntil||0,GAME_RULES.absoluteGameDay(m.gaokaoTargetYear,6,11));
  detachMemberFromAllWork(m);
  log(`${m.name}开始高考冲刺，暂时停止手头全部工作。`,"blue")
}
function finishGaokaoSprint(m){
  if(!m||!m.gaokaoSprintActive||memberOccupied(m))return;
  releaseMemberOccupation(m);
  setMemberMotivated(m);
  m.gaokaoSprintActive=false;
  m.waitingGaokao=false;
  m.gaokaoCompleted=true;
  log(`${m.name}结束了高考冲刺，重新回到制作组并变得干劲满满。`,"blue")
}
function hiddenMemberLifecycleDaily(){
  for(const m of state.members){
    if(m.isMinor&&state.day>=m.adultAtDay){
      m.isMinor=false;
      m.waitingGaokao=true;
      m.gaokaoTargetYear=year()+1;
      m.gaokaoNoticeShown=false;
      log(`${m.name}成年了！`,"blue")
    }
    if(!m.waitingGaokao||m.gaokaoCompleted)continue;
    if(year()===m.gaokaoTargetYear&&isGameCalendarDate(1,1)&&!m.gaokaoNoticeShown){
      m.gaokaoNoticeShown=true;
      log(`${m.name}将在今年高考，他会于2月1日开始高考冲刺。`,"blue")
    }
    if(year()===m.gaokaoTargetYear&&isGameCalendarDate(2,1)&&!m.gaokaoSprintActive){
      startGaokaoSprint(m)
    }
    if(m.gaokaoSprintActive&&state.day>=GAME_RULES.absoluteGameDay(m.gaokaoTargetYear,6,11)){
      finishGaokaoSprint(m)
    }
  }
}
function promotePotentialInsiders(){
  for(const m of state.members){
    if(m.confessedLeak){m.potentialInsider=false;m.leaker=false;continue}
    if(m.rarity===GAME_RULES.hiddenMemberRules.protectedRarity){
      m.potentialInsider=false;
      continue
    }
    if(!m.potentialInsider||m.leaker||memberOccupied(m)||m.status==="事务占用")continue;
    if(state.day-(m.potentialInsiderSinceDay||m.actualJoinDay||m.joinDay)<=GAME_RULES.hiddenMemberRules.potentialInsiderMaturityDays)continue;
    m.potentialInsider=false;
    m.leaker=true
  }
}
function memberOccupationDaily(){
  academicAbsenceDaily();
  hiddenMemberLifecycleDaily();
  for(const m of state.members){
    releaseMemberOccupation(m);
    if(memberOccupied(m))continue;
    let eventMultiplier=GAME_RULES.getMinorEventRateMultiplier({level:m.rarity,isMinor:m.isMinor});
    if(eventMultiplier<=0)continue;
    if(state.day<=180)continue;
    if(![2,3,4,5,6,9,10,11].includes(monthOfYear()))continue;
    if(state.day-(m.lastGuardianPhoneEventDay||-9999)<60)continue;
    if(chance(.005*eventMultiplier))startMemberOccupation(m,Math.floor(rnd(7,16)))
  }
  promotePotentialInsiders()
}
function memberWave(m){
  let halfYears=Math.floor(Math.max(0,state.day-m.joinDay)/180);
  let neg=Math.max(-.10,-.10+halfYears*.01),pos=.10+halfYears*.01;
  return 1+rnd(neg,pos)
}
function productionEfficiency(m){let y=Math.floor(Math.max(0,state.day-m.joinDay)/365),ret=Math.max(.5,1-y*.05),sp=state.sponsorIncome>5000?.8:state.sponsorIncome>2000?.9:1;return ret*sp}
function memberDailyEvents(){
  for(const m of [...state.members]){
    if(m.role==="copy")continue;
    if(memberOccupied(m))continue;
    let as=m.assignedSongIds.length>0;
    if(as){m.idleDays=0;continue}
    m.idleDays++;
    if(m.status==="疑虑"){
      m.statusDays++;
      let departureDays=GAME_RULES.memberDoubtDepartureDays(m.affection);
      if(m.statusDays>departureDays&&chance(.10)){
        removeMember(m.id,`疑虑：${memberName(m)} 因疑虑持续超过${departureDays}天而退组。`,"blue","doubt");
        continue
      }
    }
    if(m.status!=="正常"||state.day<m.cooldownUntil)continue;
    let tenure=state.day-m.joinDay;
    if(tenure>90){
      if(m.rarity>=3){
        let p=Math.min(.10,.01+Math.floor(tenure/180)*.005);
        if(coordValue()<coordCap()*.60)p*=.30;
        if(chance(p)){
          setMemberMotivated(m);
          log(`干劲满满：${memberName(m)} 进入干劲满满状态。`,"blue")
        }
      }else{
        let p=Math.min(.10,.005+Math.floor(tenure/180)*.003);
        if(coordValue()<coordCap()*.70)p*=.30;
        if(chance(p)){
          setMemberMotivated(m);
          log(`干劲满满：${memberName(m)} 进入干劲满满状态。`,"blue");
          continue
        }
        if(m.idleDays>designDoubtIdleDays()){
          let d=.05;if(coordValue()<coordCap()*.70)d*=.30;
          if(GAME_RULES.memberCanEnterDoubt(m.affection)&&chance(d)){
            m.status="疑虑";m.statusDays=0;m._statusChangedDay=state.day;
            log(`疑虑：${memberName(m)} 开始对留在制作组产生疑虑。`,"blue")
          }
        }
      }
    }else if(m.idleDays>designDoubtIdleDays()){
      if(chance(.80)){
        setMemberMotivated(m);
        log(`干劲满满：${memberName(m)} 进入干劲满满状态。`,"blue")
      }else if(GAME_RULES.memberCanEnterDoubt(m.affection)){
        m.status="疑虑";m.statusDays=0;m._statusChangedDay=state.day;
        log(`疑虑：${memberName(m)} 开始对留在制作组产生疑虑。`,"blue")
      }
    }
  }
}
function teamArgumentChance(){
  if(state.day<=90||state.members.length<2)return 0;
  let cap=coordCap(),c=coordValue();
  if(c<=cap*.60)return 0;
  let p=.005;
  for(const m of state.members){
    if(m.rarity===3)p-=.0001;
    let tenure=state.day-m.joinDay;
    if(tenure>365)p-=.0001;
    if(tenure>1095)p-=.0001;
  }
  return Math.max(0,p)
}
function pickArgumentMembers(){
  let all=state.members.filter(m=>!memberOccupied(m));
  let preferred=all.filter(m=>m.rarity===2||m.rarity===4);
  const takeRandom=arr=>arr.splice(Math.floor(Math.random()*arr.length),1)[0];
  let picked=[];
  while(picked.length<2&&preferred.length){
    let m=takeRandom(preferred);
    picked.push(m);
    all=all.filter(x=>x.id!==m.id)
  }
  while(picked.length<2&&all.length)picked.push(takeRandom(all));
  return picked
}
function teamArgumentDaily(){
  let p=teamArgumentChance();
  if(p<=0||!chance(p))return;
  let pair=pickArgumentMembers();
  if(pair.length<2)return;
  state.teamArgumentUntil=Math.max(state.teamArgumentUntil||0,state.day+15);
  for(const m of pair)m.argumentInvolvedUntil=Math.max(m.argumentInvolvedUntil||0,state.day+15);
  log(`制作组的${pair[0].name}和${pair[1].name}在组内产生了争吵！`,"red")
}
function lewdImageDaily(){
  let eligible=state.members.filter(m=>!memberOccupied(m)&&[4,5].includes(m.rarity)&&(state.day-m.joinDay)>180);
  if(!eligible.length||state.members.filter(m=>!memberOccupied(m)).length<2||!chance(.01))return;

  let special=eligible.filter(m=>m.role==="chart"&&(m.name==="Iblcya"||m.name==="爬爬"));
  let x=special.length&&chance(.70)
    ?special[Math.floor(Math.random()*special.length)]
    :eligible[Math.floor(Math.random()*eligible.length)];

  let others=state.members.filter(m=>m.id!==x.id&&!memberOccupied(m));
  if(!others.length)return;
  let y=others[Math.floor(Math.random()*others.length)];

  x.lewdCoordUntil=Math.max(x.lewdCoordUntil||0,state.day+15);
  if(chance(GAME_RULES.lewdImageRules.alternateCopyChance)){
    log(`${x.name}往制作组聊天群搬屎，导致群里吵了起来。`,"blue")
  }else{
    setMemberMotivated(y);
    if(GAME_RULES.shouldScheduleLewdImageFollowup(x.affection)){
      state.lewdImageFollowups.push({memberId:x.id,day:state.day+1})
    }
    log(`${x.name}在制作组内发涩图，造成了不良影响。但${y.name}因此获得了干劲。`,"blue")
  }
}
function processLewdImageFollowups(){
  let due=(state.lewdImageFollowups||[]).filter(item=>state.day>=item.day);
  state.lewdImageFollowups=(state.lewdImageFollowups||[]).filter(item=>state.day<item.day);
  for(const item of due){
    let m=getMember(item.memberId);
    if(!m||!chance(GAME_RULES.lewdImageRules.followupChance))continue;
    let next=GAME_RULES.lewdImageFollowupAffection(m.affection);
    if(next!==m.affection){m.affection=next;m.affectionTrustLocked=m.affection>=GAME_RULES.memberAffectionRules.trustFloor}
    log(`${m.name}不服你阻止他往制作组群里发涩图，于是私聊给你多发了几张。你将他痛骂了一顿。`,"blue")
  }
}
function coordinationDailyEvents(){
  teamArgumentDaily();
  let c=coordValue(),cap=coordCap();
  if(c>cap*.5&&state.monthlyHighCoordEvents<2&&chance(Math.min(.05,(c-cap*.5)/(cap*.5)*.05))){state.monthlyHighCoordEvents++;teamExplosion(c>cap*.8)}
  let crazyCandidates=state.members.filter(m=>!memberOccupied(m)&&state.day-(m.actualJoinDay??m.joinDay)>7);
  let averageMadnessMultiplier=crazyCandidates.length
    ?crazyCandidates.reduce((sum,m)=>sum+GAME_RULES.getMadnessRateMultiplier(m),0)/crazyCandidates.length
    :0;
  if(c<20&&state.monthlyLowCoordEvents<2&&crazyCandidates.length&&chance(Math.min(.10,(20-c)/20*.10)*averageMadnessMultiplier)){
    state.monthlyLowCoordEvents++;
    memberCrazy(crazyCandidates)
  }
}
function teamExplosion(high){
  let peacemakers=state.members.filter(m=>Number(m.affection)>80);
  if(peacemakers.length&&chance(GAME_RULES.teamExplosionDefuseChance(peacemakers.length))){
    let peacemaker=peacemakers[Math.floor(Math.random()*peacemakers.length)];
    log(`制作组的成员们因为观念不合，差点吵了起来。所幸${peacemaker.name}及时现身，第一时间化解了矛盾。`,"blue");
    return
  }
  let damaged=[];
  let songLimit=GAME_RULES.teamExplosionSongLimit(state.members.length);
  state.library.filter(s=>!s.installed&&(s.chartProgress<100||s.artProgress<100)).slice(0,songLimit).forEach(s=>{
    if(chance(.5))s.chartProgress=Math.max(0,s.chartProgress-20);else s.artProgress=Math.max(0,s.artProgress-20);
    damaged.push(s.name)
  });
  const removeOne=()=>{
    let e=state.members.filter(m=>![2,5].includes(m.rarity)&&!memberOccupied(m)),d=e.filter(m=>m.status==="疑虑"),p=d.length?d:e;
    if(p.length){
      let m=p[Math.floor(Math.random()*p.length)];
      removeMember(m.id,`组内爆炸：${memberName(m)} 在冲突中退组。`,"blue")
    }
  };
  if(chance(.30))removeOne();
  if(high&&chance(.50))removeOne();
  log(`组内爆炸：制作组发生冲突${damaged.length?`，影响了《${damaged.join("》《")}》的制作进度`:""}。`,"blue");
}
function memberCrazyProgressThreshold(m){
  if(m.rarity===1)return 80;
  if(m.rarity===2)return 70;
  return 50
}
function memberCrazyHasProtectedWork(m){
  let threshold=memberCrazyProgressThreshold(m);
  return (m.assignedSongIds||[]).some(id=>{
    let s=getSong(id);if(!s)return false;
    let progress=m.role==="chart"?Number(s.chartProgress)||0:Number(s.artProgress)||0;
    return progress>threshold
  })
}
function memberCrazy(eligibleMembers=null){
  // 实际入组7天内的新成员绝不会触发“疯了”。
  let e=eligibleMembers||state.members.filter(m=>!memberOccupied(m)&&state.day-(m.actualJoinDay??m.joinDay)>7);
  if(!e.length)return;
  let totalWeight=e.reduce((sum,m)=>sum+GAME_RULES.getMadnessRateMultiplier(m),0);
  let roll=Math.random()*totalWeight,m=e[e.length-1];
  for(const candidate of e){
    roll-=GAME_RULES.getMadnessRateMultiplier(candidate);
    if(roll<=0){m=candidate;break}
  }
  let who=m.name||"未命名",s=getSong((m.assignedSongIds||[])[0]),result="没有正在进行的工作受到直接影响";
  if(s){
    if(chance(.5)){
      if(m.role==="chart")s.chartProgress=100;else s.artProgress=100;
      s._playableMultiplier=(s._playableMultiplier||1)*rnd(.7,2);
      completeRole(s,m.role);finalizePlayableQuality(s);
      result=`《${s.name}》的${m.role==="chart"?"谱面":"美术"}被直接完成，但歌曲的可玩质量可能受到影响`
    }else{
      let protectedWork=memberCrazyHasProtectedWork(m);
      if(m.role==="chart"){
        s.chartProgress=protectedWork?Math.max(0,s.chartProgress-20):0
      }else{
        s.artProgress=protectedWork?Math.max(0,s.artProgress-20):0
      }
      result=protectedWork
        ?`《${s.name}》的${m.role==="chart"?"谱面":"美术"}进度下降20%`
        :`《${s.name}》的${m.role==="chart"?"谱面":"美术"}进度归零`;
      if(chance(.3)){
        removeMember(m.id,`有组员疯了：${who}在事件中直接退组。`,"blue");
        log(`有组员疯了：${who}受到影响，${result}。`,"blue");
        return
      }
    }
  }
  m.coordExtraUntil=state.day+180;
  log(`有组员疯了：${who}受到影响，${result}。`,"blue")
}
function formerMemberEffectScale(){
  // 第3年从第731天开始；之后每完整运营180天，效果强度再乘0.9。
  if(state.day<731)return 1;
  let halfYears=Math.floor(Math.max(0,state.day-731)/180);
  return Math.pow(.9,halfYears)
}
function registerFormerMemberOpinion(m,dailyChance){
  if(!m||dailyChance<=0)return;
  if((state.formerMemberOpinionSpokenNames||[]).includes(m.name||"未命名"))return;
  if(!state.formerMemberOpinionCandidates)state.formerMemberOpinionCandidates=[];
  if(state.formerMemberOpinionCandidates.some(c=>!c.triggered&&c.name===(m.name||"未命名")))return;
  state.formerMemberOpinionCandidates.push({
    id:nextId(),
    name:m.name||"未命名",
    role:m.role,
    rarity:m.rarity,
    departDay:state.day,
    eligibleFrom:state.day+30,
    expireDay:state.day+730,
    dailyChance,
    triggered:false
  })
}
function escalateFormerMemberScandal(){
  if(state.exMemberScandalEscalated)return;
  state.exMemberScandalEscalated=true;
  let scale=formerMemberEffectScale();
  state.exMemberScandalClusterUntil=Math.max(state.exMemberScandalClusterUntil||0,state.day+30);
  state.exMemberScandalDiscussUntil=Math.max(state.exMemberScandalDiscussUntil||0,state.day+30);
  state.exMemberScandalDiscussScale=Math.max(state.exMemberScandalDiscussScale||0,scale);
  let totalFanLoss=Math.max(0,state.fans)*.10*scale;
  let totalStickLoss=Math.max(0,state.stickiness)*.10*scale;
  state.exMemberGradualLoss={
    remainingDays:30,
    dailyFanLoss:totalFanLoss/30,
    dailyStickLoss:totalStickLoss/30
  }
}
function noteMemberDepartureForScandal(m){
  if(state.day<=(state.exMemberScandalClusterUntil||0)){
    log(`由于${m?.name||"一名组员"}的退组，对近期的制作组节奏产生了连带影响。玩家社区充斥着愤怒的发言。`,"red");
    escalateFormerMemberScandal()
  }
}
function triggerFormerMemberOpinion(c){
  if(!c||c.triggered)return;
  if((state.formerMemberOpinionSpokenNames||[]).includes(c.name)){
    c.triggered=true;
    return
  }
  c.triggered=true;
  if(!state.formerMemberOpinionSpokenNames)state.formerMemberOpinionSpokenNames=[];
  state.formerMemberOpinionSpokenNames.push(c.name);
  for(const other of (state.formerMemberOpinionCandidates||[]))if(other!==c&&other.name===c.name)other.triggered=true;
  let scale=formerMemberEffectScale();

  // 每次负面观点都保证下一次联动至少15天后才可能到来。
  state.collabOpinionBlockedUntil=Math.max(state.collabOpinionBlockedUntil||0,state.day+15);

  // 30天关联窗口内的后续负面观点显示“连带影响”文本。
  if(state.day<=(state.exMemberScandalClusterUntil||0)){
    log(`由于前组员${c.name}也发表了对制作组的负面观点，对近期的制作组节奏产生了连带影响。玩家社区充斥着愤怒的发言。`,"red");
    escalateFormerMemberScandal();
    return
  }

  log(`前组员${c.name}在组外发表了对制作组的负面观点！制作组声誉受到影响。`,"red");
  state.exMemberScandalClusterUntil=state.day+30;
  state.exMemberScandalDiscussUntil=state.day+7;
  state.exMemberScandalDiscussScale=scale;
  state.exMemberScandalEscalated=false;

  // “粘性玩家”按现有玩家粘性值处理。
  state.stickiness=Math.max(0,state.stickiness*(1-.01*scale))
}
function formerMemberOpinionDaily(){
  // 已升级后的关注与玩家粘性损失，在30天内均匀发生。
  let loss=state.exMemberGradualLoss;
  if(loss&&loss.remainingDays>0){
    state.metaFans-=loss.dailyFanLoss;
    state.stickiness=Math.max(0,state.stickiness-loss.dailyStickLoss);
    loss.remainingDays--;
    if(loss.remainingDays<=0)state.exMemberGradualLoss=null
  }

  let list=state.formerMemberOpinionCandidates||[];
  for(const c of list){
    if(c.triggered)continue;
    if(state.day>c.expireDay)continue;
    if(state.day>=c.eligibleFrom&&chance(c.dailyChance))triggerFormerMemberOpinion(c)
  }
  // 两年内都没有触发的前成员永久失效，同时清理已经触发的旧记录。
  state.formerMemberOpinionCandidates=list.filter(c=>!c.triggered&&state.day<=c.expireDay)
}
function canLeaveRecoverable(m){
  return !!m&&(Number(m.works)||0)>=1&&(state.day-m.joinDay)>180
}
function registerDepartedRecoverable(m){
  if(!canLeaveRecoverable(m))return;
  if(!state.departedRecoverables)state.departedRecoverables=[];
  state.departedRecoverables=state.departedRecoverables.filter(r=>r.member?.id!==m.id);
  let saved=JSON.parse(JSON.stringify(m));
  saved.assignedSongIds=[];
  saved.status="正常";
  saved.statusDays=0;
  saved.occupiedUntil=0;
  saved._statusBeforeOccupation=null;
  saved._statusDaysBeforeOccupation=0;
  saved.argumentInvolvedUntil=0;
  state.departedRecoverables.push({
    id:nextId(),
    member:saved,
    departedDay:state.day,
    recoverProgress:0,
    abandonAt:null
  })
}
function recoverMemberAttempt(rid){
  let r=(state.departedRecoverables||[]).find(x=>x.id===rid);if(!r)return;
  let lockLeft=Math.max(0,30-(state.day-r.departedDay));
  if(lockLeft>0){log(`成员离组未满30天，还需要等待${lockLeft}天才能尝试找回。`);return}
  if(state.members.length>=teamCap())return log("人数已达上限，暂时无法找回成员。");
  if(!spendAP(10))return;
  r.recoverProgress=Math.min(100,(r.recoverProgress||0)+rnd(5,15));
  let name=r.member?.name||"该成员";
  let affectionBonus=GAME_RULES.memberRecoveryChanceBonus(r.member?.affection);
  let recoveredEarly=affectionBonus>0&&chance(affectionBonus);
  if(r.recoverProgress<100&&!recoveredEarly){
    log(`找回成员${name}失败。`);
    render();
    return
  }

  let m=JSON.parse(JSON.stringify(r.member));
  m.assignedSongIds=[];
  m.status="正常";
  m.statusDays=0;
  m.cooldownUntil=Math.max(Number(m.cooldownUntil)||0,state.day);
  m.occupiedUntil=0;
  m._statusBeforeOccupation=null;
  m._statusDaysBeforeOccupation=0;
  m.argumentInvolvedUntil=0;
  state.members.push(m);
  if(m.role==="copy")state.hasHadCopywriter=true;
  state.departedRecoverables=state.departedRecoverables.filter(x=>x.id!==rid);
  // 重新回组后，尚未触发的“前组员负面观点”不再继续判定。
  state.formerMemberOpinionCandidates=(state.formerMemberOpinionCandidates||[]).filter(c=>c.name!==m.name);
  log(`找回成员${name}成功！制作组的大家或许其实很开心。`);
  render()
}
function toggleAbandonRecoverable(rid){
  let r=(state.departedRecoverables||[]).find(x=>x.id===rid);if(!r)return;
  r.abandonAt=r.abandonAt?null:state.day+7;
  render()
}
function cleanupDepartedRecoverables(){
  state.departedRecoverables=(state.departedRecoverables||[]).filter(r=>!r.abandonAt||state.day<r.abandonAt)
}
function removeMember(id,msg,type="normal",departureKind=null){
  let m=getMember(id);if(!m)return;
  let who=memberName(m);
  noteMemberDepartureForScandal(m);
  if(departureKind==="doubt")registerFormerMemberOpinion(m,.002);
  registerDepartedRecoverable(m);
  state.library.forEach(s=>{s.chartMemberIds=s.chartMemberIds.filter(x=>x!==id);if(s.artMemberId===id)s.artMemberId=null});
  state.members=state.members.filter(x=>x.id!==id);
  log(msg.includes(who)?msg:`${who}：${msg}`,type)
}
function remindDoubtingMembers(){
  for(const m of state.members.filter(x=>x.status==="疑虑"&&x._statusChangedDay!==state.day)){
    log(`疑虑：${memberName(m)} 正处于疑虑状态。`,"blue")
  }
}
function assignMember(mid,sid){
  if(state.bankrupt)return log("破产状态（将存款积累到20000解除破产状态）下无法分配任务。");
  let m=getMember(mid),s=getSong(sid);
  if(!m||!s||s.installed)return log("任务分配失败：成员或歌曲不可用。");
  if(m.role==="copy")return log("文案成员会自主工作，不需要手动分配任务。");
  if(memberOccupied(m))return log(`${m.name}目前正被事务占用，无法分配工作。`);
  if(m.role==="chart"){
    if(s.chartMemberIds.includes(mid))return log(`${memberName(m)} 已经在制作《${s.name}》的谱面。`);
    if(m.assignedSongIds.length>=3)return log("一个谱师最多同时写3张谱。");
    s.chartMemberIds.push(mid);m.assignedSongIds.push(sid);
  }else{
    if(s.artMemberId===mid)return log(`${memberName(m)} 已经在绘制《${s.name}》的封面。`);
    if(m.assignedSongIds.length>=1)return log("一个美术最多同时画1张封面。");
    if(s.artMemberId)return log("这首曲子已经分配美术。");
    s.artMemberId=mid;m.assignedSongIds.push(sid);
  }
  let bonusText="";
  if(["干劲满满","疑虑"].includes(m.status)){
    if(m.status==="干劲满满"){
      changeMemberAffection(m,1);
      let b=m.rarity>=3?rnd(15,30):rnd(10,30);
      if(m.role==="chart")s.chartProgress=Math.min(100,s.chartProgress+b);else s.artProgress=Math.min(100,s.artProgress+b);
      bonusText=`；“干劲满满”立即增加 ${b.toFixed(1)}% 进度`;
      if((m.role==="chart"&&s.chartProgress>=100)||(m.role==="art"&&s.artProgress>=100))completeRole(s,m.role);
      finalizePlayableQuality(s);
    }
    m.status="正常";m.statusDays=0;m.cooldownUntil=state.day+60;
  }
  log(`任务分配成功：${memberName(m)} → 《${s.name}》${m.role==="chart"?"谱面":"封面"}${bonusText}。`);
  render();
}
function personalChartGain(){
  let gain=15/3;
  for(const t of [50,150,250,350,450])if(state.rhythmPlayCount>=t)gain+=2/3;
  for(const t of [5,10,30,60,120])if(state.personalChartCount>=t)gain+=1/3;
  return gain;
}
function personallyChart(sid){
  if(computerActionBlocked())return;
  let c=6+(state.sponsorIncome>5000?1:0);
  if(!spendAP(c))return;
  let s=getSong(sid);if(!s||s.installed)return;
  let gain=personalChartGain();
  s.chartProgress=Math.min(100,s.chartProgress+gain);
  state.personalChartCount=(state.personalChartCount||0)+1;
  s._playableBonus=(s._playableBonus||0)+1/3;
  log(`亲自写谱：《${s.name}》制谱进度 +${gain.toFixed(2).replace(/\\.00$/,"")}%。`);
  if(s.chartProgress>=100){completeRole(s,"chart")}
  finalizePlayableQuality(s);render()
}
function allocatedStoryWordTotal(){
  return (state.packages||[]).reduce((total,p)=>total+Math.max(0,Number(p.storyWordsAssigned)||0),0)
}
function remainingStoryWritingCapacity(){
  return GAME_RULES.remainingStoryWritingCapacity({cap:state.storyWordCap,availableWords:state.storyWords})
}
function copywriterProductionOptions(m){
  return {
    level:m.rarity,
    tenureDays:Math.max(0,state.day-(m.actualJoinDay??m.joinDay)),
    totalWords:Math.max(0,Number(m.copyWordsWritten)||0),
    motivated:m.status==="干劲满满"
  }
}
function promoteCopywriterByWords(m){
  if(!m||m.role!=="copy")return;
  let before=m.rarity;
  let after=before,next=after;
  do{after=next;next=GAME_RULES.promotedCopywriterLevel(after,m.copyWordsWritten)}while(next!==after);
  if(after===before)return;
  m.rarity=after;
  if(after===GAME_RULES.hiddenMemberRules.protectedRarity)m.potentialInsider=false;
  log(`${m.name}累计完成${fmt(m.copyWordsWritten)}字剧情创作，成长为${after}级文案。`,"green")
}
function copywriterDaily(){
  for(const m of state.members.filter(member=>member.role==="copy")){
    expireCopywriterMotivation(m);
    if(memberOccupied(m))continue;
    let available=remainingStoryWritingCapacity();
    if(available<=0){
      m.idleDays=(m.idleDays||0)+1;
      if(m.status==="疑虑"){
        m.statusDays=(m.statusDays||0)+1;
        let result=GAME_RULES.updateCopywriterDoubtProgress({current:m.doubtWritingProgress,written:0,isIdle:true});
        m.doubtWritingProgress=result.progress;
        let departureDays=GAME_RULES.memberDoubtDepartureDays(m.affection);
        if(m.statusDays>departureDays&&chance(.10)){
          removeMember(m.id,`疑虑：${memberName(m)} 因疑虑持续超过${departureDays}天而退组。`,"blue","doubt");
          continue
        }
      }else if(m.status==="正常"&&state.day>=m.cooldownUntil&&m.idleDays>designDoubtIdleDays()*GAME_RULES.copywriterRules.doubtIdleDaysMultiplier){
        let doubtChance=.05;
        if(coordValue()<coordCap()*.70)doubtChance*=.30;
        if(GAME_RULES.memberCanEnterDoubt(m.affection)&&chance(doubtChance)){
          m.status="疑虑";m.statusDays=0;m.doubtWritingProgress=0;m._statusChangedDay=state.day;
          log(`疑虑：${memberName(m)} 因长期没有可写剧情而开始产生疑虑。`,"blue")
        }
      }
      continue
    }

    m.idleDays=0;
    let written=Math.min(available,GAME_RULES.rollCopywriterDailyWords(copywriterProductionOptions(m)));
    state.storyWords+=written;
    m.copyWordsWritten=(Number(m.copyWordsWritten)||0)+written;
    m.works=m.copyWordsWritten/1000;
    promoteCopywriterByWords(m);
    if(m.status==="疑虑"){
      let result=GAME_RULES.updateCopywriterDoubtProgress({current:m.doubtWritingProgress,written,isIdle:false});
      m.doubtWritingProgress=result.progress;
      if(result.recovered){
        m.status="正常";m.statusDays=0;m.doubtWritingProgress=0;m.cooldownUntil=state.day+60;m._statusChangedDay=state.day;
        log(`${m.name}通过持续完成500字剧情写作，解除了疑虑。`,"green")
      }
    }
  }
}
function productionDaily(){for(const s of state.library.filter(x=>!x.installed)){if(s.chartProgress<100&&s.chartMemberIds.length){let t=0;for(const id of [...s.chartMemberIds]){let m=getMember(id);if(!m)continue;let activeCount=Math.max(1,m.assignedSongIds.length);
let b=100/BASE_MEMBER_DAYS[m.rarity]/activeCount*productionEfficiency(m)*memberWave(m)*chartEfficiencyMultiplier(m);
if(m.rarity>=2){
  let halfYears=Math.floor(Math.max(0,state.day-m.joinDay)/180);
  if(state.chartEditorComplete){
    let editorBonus=Math.min(3,0.5+halfYears*0.2);
    b+=editorBonus/activeCount;
  }
  if(state.chartEditorV2Complete){
    let editorV2Bonus=Math.min(1,0.3+halfYears*0.1);
    b+=editorV2Bonus/activeCount;
  }
}
if(s.position==="魔王曲")b/=1.4;if(chance(.002)&&state.day-m.joinDay>=3){b=100;s._playableBonus=(s._playableBonus||0)+m.rarity}t+=b}s.chartProgress=Math.min(100,s.chartProgress+t);if(s.chartProgress>=100)completeRole(s,"chart")}if(s.artProgress<100&&s.artMemberId){let m=getMember(s.artMemberId);if(m){let b=100/BASE_MEMBER_DAYS[m.rarity]*productionEfficiency(m)*memberWave(m);if(s.position==="魔王曲")b/=1.4;if(chance(.004)&&state.day-m.joinDay>=1)b=100;s.artProgress=Math.min(100,s.artProgress+b);if(s.artProgress>=100)completeRole(s,"art")}}}}
function completeRole(s,role){
  let ids=role==="chart"?s.chartMemberIds:[s.artMemberId];
  let levels=[];
  let affectionBonuses=[];
  ids.forEach(id=>{
    let m=getMember(id);if(!m)return;
    levels.push(m.rarity);
    affectionBonuses.push(GAME_RULES.memberWorkPlayableBonus(m.affection));
    changeMemberAffection(m,GAME_RULES.memberSongQualityAffectionGain(s.quality));
    m.assignedSongIds=m.assignedSongIds.filter(x=>x!==s.id);
  });
  if(affectionBonuses.length)s._memberAffectionBonus=(s._memberAffectionBonus||0)+affectionBonuses.reduce((a,b)=>a+b,0)/affectionBonuses.length;
  if(levels.length){
    let avg=levels.reduce((a,b)=>a+b,0)/levels.length;
    if(role==="chart")s._chartCraftLevel=avg;
    else s._artCraftLevel=avg;
  }else{
    // 玩家亲自完成但没有对应成员时，暂按最低制作等级计入；
    // 亲自写谱/画图已有自己的独立加成或惩罚。
    if(role==="chart"&&!s._chartCraftLevel)s._chartCraftLevel=1;
    if(role==="art"&&!s._artCraftLevel)s._artCraftLevel=1;
  }
  // 成员成长按本次作品的预计可玩质量计算。
  ids.forEach(id=>{
    let m=getMember(id);if(!m)return;
    let projected=projectedPlayableQuality(s);
    m.works+=projected>=80?(m.rarity===1?2:m.rarity===2?3:1.5):1;
    if(m.rarity===1&&m.works>=5&&chance(.2))m.rarity=2;
    else if(m.rarity===2&&m.works>=15&&chance(.1)){
      m.rarity=3;
      m.potentialInsider=false
    }
    else if(m.rarity===4&&m.works>=50&&chance(.05))m.rarity=5;
  });
  if(role==="chart")s.chartMemberIds=[];else s.artMemberId=null;
  finalizePlayableQuality(s);
  if(role==="chart")onFirstChartCompleted()
}
function composerHasActiveCommission(id){
  return state.commissions.some(x=>!x.portfolioSong&&x.composerId===id);
}
function activeCommissionForComposer(id){
  return state.commissions.find(x=>!x.portfolioSong&&x.composerId===id)||null
}
function seniorCopywriterCount(){
  return state.members.filter(m=>m.role==="copy"&&m.rarity>=3).length
}
function expediteSuccessRate(efficiency){
  const table={1:.05,2:.10,3:.20,4:.30,5:1};
  let eff=clamp(Math.round(Number(efficiency)||1),1,5);
  let p=table[eff];
  if(state.services.translation){
    const bonus={1:.05,2:.04,3:.03,4:.02,5:0};
    p+=bonus[eff]
  }
  p+=GAME_RULES.seniorCopywriterExpediteBonus(seniorCopywriterCount());
  return Math.min(1,p)
}
function expediteMaxReduction(efficiency){
  const table={1:30,2:20,3:10,4:5,5:0};
  return table[clamp(Math.round(Number(efficiency)||1),1,5)]
}
function expediteMaxBackfireDelay(efficiency){
  const table={1:30,2:20,3:10,4:3,5:0};
  return table[clamp(Math.round(Number(efficiency)||1),1,5)]
}
function expediteMentalBreakChance(mental){
  let m=clamp(Number(mental)||100,10,100);
  if(m>=70)return 0;
  // 10心理=30%；20心理约24.8%；70心理=0%，中间平滑下降。
  let t=(70-m)/60;
  return .30*Math.pow(t,1.05)
}
function expediteReductionDays(c,maxDays){
  if(maxDays<=0)return 0;
  let affection=clamp(Number(c.affection)||0,0,100);
  // 低好感通常只靠近上限的约25%~60%；高好感逐渐更靠近上限。
  let minRatio=.25+.55*(affection/100);
  let ratio=rnd(minRatio,1);
  return Math.max(1,Math.round(maxDays*ratio))
}
function expediteBackfireDays(maxDays){
  if(maxDays<=0)return 0;
  return Math.max(1,Math.round(rnd(Math.max(1,maxDays*.25),maxDays)))
}
function expediteCommission(id){
  let c=getComposer(id),x=activeCommissionForComposer(id);
  if(!c||!x)return;
  if(c.country!=="中国"&&!state.services.vpn){
    log("需要 VPN 才能对中国以外的曲师进行催稿。");
    return
  }
  if(c.name==="侧睡"&&x.isFirstSideSleepCommission&&x.startDay===state.day&&!state.sideSleepSameDayExpediteTipDone){
    state.sideSleepSameDayExpediteTipDone=true;
    log("催稿失败：侧睡不仅没有加快制作进度，还骂了一句你有病。他让你以后在恰当的实际进行催稿，过度催稿可能会造成意想不到的负面效果。");
    render();
    return
  }
  let eff=clamp(Math.round(Number(c.efficiency)||1),1,5);

  if(eff>=5){
    log("这位曲师的效率已经足够快了，没必要进行催稿了。");
    return
  }
  if(state.day<(c.expediteBlockedUntil||0)){
    let left=Math.max(1,(c.expediteBlockedUntil||0)-state.day);
    log(`${c.name}目前不接受催稿，还需要等待${left}天。`);
    return
  }
  if(state.day-(c.lastExpediteDay||-9999)<7){
    let left=7-(state.day-(c.lastExpediteDay||-9999));
    log(`${c.name}距离上次催稿还不到7天，还需要等待${left}天。`);
    return
  }

  c.lastExpediteDay=state.day;

  let breakChance=expediteMentalBreakChance(c.mental);
  if(chance(breakChance)){
    let delay=expediteBackfireDays(expediteMaxBackfireDelay(eff));
    x.deliverDay+=delay;
    c.expediteBlockedUntil=state.day+30;
    log(`心态爆炸：${c.name}被催稿后状态受到影响，30天内无法再次催稿，本次制作工期延长${delay}天。`,"red");
    render();
    return
  }

  if(!chance(expediteSuccessRate(eff))){
    log(`催稿失败：${c.name}没有因此加快制作进度。`);
    render();
    return
  }

  let remaining=Math.max(0,x.deliverDay-state.day);
  let reducible=Math.max(0,remaining-1);
  let reduction=Math.min(reducible,expediteReductionDays(c,expediteMaxReduction(eff)));
  if(reduction<=0){
    log(`${c.name}的委托曲已经只剩1天左右完成，无法再通过催稿缩短工期。`);
    render();
    return
  }
  x.deliverDay-=reduction;
  log(`催稿成功：${c.name}加快了制作进度，预计工期缩短${reduction}天。`,"green");
  render()
}
function composerReachable(c){if(c.country!=="中国"&&!state.services.vpn)return false;if(state.day<c.depressedUntil)return false;if(state.day<c.sickUntil&&c.affection<60)return false;return true}
function reputationSignal(){return Math.max(0,(state.fans+state.discussion+state.players)/300+state.rating)}
function composerSelection(id){
  if(!state.commissionSelections[id])state.commissionSelections[id]={nature:"非商",style:"灼热"};
  return state.commissionSelections[id]
}
function setComposerSelection(id,key,value){
  let s=composerSelection(id);s[key]=value;renderComposers()
}
function currentCommissionPrice(c,nature="非商"){
  let price=c.prices[nature]*(1-Math.min(.35,c.affection*.003));
  if(year()>=3&&state.artPursuit>80)price*=1.10;
  if(year()>=3&&state.artPursuit>85)price*=1.05;
  if(c.name==="shcad"){
    if(!state.firstShcadCommissionDone)price*=0.5;
    else if(state.shcadMilestoneDiscountPending)price*=0.60;
  }
  return Math.max(0,price);
}
function commissionSuccess(c){
  let elite=c.popularity>=70&&c.avgQuality>=4;
  let fans=Math.max(0,state.fans),p;
  if(elite){
    // 高人气高技术曲师：开局个位数；约5000关注时进入20%~30%；之后再稳定增长。
    let start=clamp(.075-(c.popularity-70)*.0015-(c.avgQuality-4)*.018,.025,.075);
    let at5000=clamp(.29-(c.popularity-70)*.001-(c.avgQuality-4)*.018,.20,.29);
    if(fans<=5000){
      let t=Math.pow(fans/5000,1.35);
      p=start+(at5000-start)*t;
    }else{
      p=at5000+Math.min(.42,(fans-5000)/30000*.42);
      p*=1+Math.min(.12,reputationSignal()/30000);
    }
  }else{
    // 普通/新手友好曲师前期仍可维持约40%~50%左右。
    let start=clamp(.56-c.popularity*.0022-Math.max(0,c.avgQuality-3)*.035,.38,.52);
    if(fans<=5000)p=start+(Math.min(.66,start+.12)-start)*(fans/5000);
    else p=Math.min(.86,Math.min(.66,start+.12)+(fans-5000)/35000*.20);
    p*=1+Math.min(.10,reputationSignal()/25000);
  }
  if(state.services.translation&&c.country!=="中国")p*=1.2;
  if(year()>=3&&state.artPursuit>95)p*=.9;
  if(styleState().name==="多元发展")p*=1.12;
  c.bond.forEach(id=>{let b=getComposer(id);if(b&&b.collabs>0)p*=1.08});
  p+=GAME_RULES.seniorCopywriterCommissionBonus(seniorCopywriterCount());
  return clamp(p,.02,.95)
}
function abstractRoll(c,commissioned=false){
  let v=clamp(Math.round(c.abstract+rnd(-1,1)),0,5);
  if(commissioned&&state.designConceptConfirmed){
    let level=clamp(Math.round(Number(c.abstract)||1),1,5);
    if(state.designStyle==="创新"){
      const p={1:.10,2:.20,3:.30,4:.15,5:0};
      if(chance(p[level]))v=Math.min(5,v+1)
    }else if(state.designStyle==="传统"){
      const p={1:0,2:.20,3:.30,4:.20,5:.30};
      if(chance(p[level]))v=Math.max(0,v-1)
    }
  }
  return v
}
function weightedQuality(weights){let total=weights.reduce((a,b)=>a+Math.max(0,Number(b)||0),0);if(total<=0)return 3;let r=Math.random()*total,a=0;for(let i=0;i<5;i++){a+=Math.max(0,Number(weights[i])||0);if(r<=a)return i+1}return 5}
function commissionDurationRange(v){
  const table={
    1:[80,200],
    2:[55,120],
    3:[32,95],
    4:[16,60],
    5:[7,30],
    6:[5,22]
  };
  let x=clamp(Number(v)||1,1,6),lo=Math.floor(x),hi=Math.ceil(x);
  if(lo===hi)return table[lo].slice();
  let t=x-lo,a=table[lo],b=table[hi];
  return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]
}
function rollCommissionDays(efficiency,nature){
  let [minD,maxD]=commissionDurationRange(efficiency);
  let base=rnd(minD,maxD);
  if(nature==="非商"){
    // 非商将正常工期随机波动扩大约一倍，但仍避免常态出现1天交稿。
    let mid=(minD+maxD)/2;
    base=mid+(base-mid)*2;
    base=clamp(base,Math.max(3,minD*.5),maxD*1.5);
  }
  return base
}
function qualityRoll(c,nature,style){if(year()>=3&&!state.firstYear3CommissionDone){state.firstYear3CommissionDone=true;return Math.max(4,weightedQuality(c.qualityProbs[nature]||[0,0,1,0,0]))}let q=weightedQuality(c.qualityProbs[nature]||[0,0,1,0,0]);if(c.styles[style]>=80&&chance(.18))q=Math.min(5,q+1);if(year()>=3&&state.artPursuit>85&&chance(.08))q=Math.min(5,q+1);return q}
function pickCommissionTitle(style){
  let used=new Set(state.usedCommissionTitles||[]);
  let candidates=[...COMMISSION_TITLE_POOL,...(STYLE_COMMISSION_TITLE_POOLS[style]||[])];
  let available=candidates.filter(n=>!used.has(n));
  let pool=available.length?available:candidates;
  let title=pool[Math.floor(Math.random()*pool.length)]||"Untitled";
  if(!(state.usedCommissionTitles||[]).includes(title))state.usedCommissionTitles.push(title);
  return title
}
function commissionComposer(id){
  if(!state.designConceptConfirmed)return log("必须先完成“游戏设计理念”后才能主动约曲。");
  let c=getComposer(id);if(!c)return;
  if(composerHasActiveCommission(id)){log(`${c.name} 当前正在制作你的委托曲，需要等这首曲子完成后才能再次约稿。`);return}
  if(!composerReachable(c)){log("当前无法主动联系该曲师。");return}
  let sel=composerSelection(id),st=sel.style,n=sel.nature;
  if(!spendAP(1))return;
  render();
  let isFirstShcad=(c.name==="shcad"&&!state.firstShcadCommissionDone);
  let price=currentCommissionPrice(c,n);
  if(!canSpendMoney(price)){log("存款不足：本次约曲行动已消耗1行动点，但没有扣除约稿费用。");return}
  let earlyHighPriceNoncommercial=state.day<=90&&n==="非商"&&price>=4500;
  let accepted=isFirstShcad?true:(earlyHighPriceNoncommercial?chance(.05):commissionSuccess(c));
  if(!accepted){log(`${c.name}没有接受约稿，下次再试试吧。`);return}
  state.money-=price;
  let usedShcadMilestoneDiscount=c.name==="shcad"&&state.shcadMilestoneDiscountPending&&!isFirstShcad;
  if(usedShcadMilestoneDiscount)state.shcadMilestoneDiscountPending=false;
  // 一旦接受了玩家主动发出的委托，同曲师尚未处理的主动来稿不再并存。
  state.incomingOffers=state.incomingOffers.filter(o=>o.composerId!==c.id);
  if(isFirstShcad){
    state.firstShcadCommissionDone=true;
    log("shcad非常支持你们的企划，决定第一首歌曲为你们减少50%的约稿费用。");
  }
  if(n!=="非商")state.commercialFormalCount++;
  let q=qualityRoll(c,n,st);
  if(state.designConceptConfirmed&&state.designStyle==="传统"&&q===5&&chance(.10))q=4;
  let days=rollCommissionDays(c.efficiency,n);
  if(c.styles[st]>=80)days*=.85;
  if(year()>=3&&state.artPursuit>90)days*=1.10;
  if(n==="正式邀请")days=Math.min(days,90);
  if(c.mental<50){days*=rnd(1,2);if(chance((50-c.mental)/100))q=Math.max(1,q-1)}
  let deliverDay=state.day+Math.max(1,Math.round(days));
  let isFirstSideSleepCommission=(c.name==="侧睡"&&!state.sideSleepCommissionedOnce);
  if(isFirstSideSleepCommission)state.sideSleepCommissionedOnce=true;
  c.lastExpediteDay=state.day;
  state.commissions.push({id:nextId(),composerId:id,style:st,nature:n,q,startDay:state.day,deliverDay,displayName:"约稿委托的曲子",notified:{20:false,50:false,80:false},isFirstSideSleepCommission});
  log(`约稿成功：${c.name} 已接受委托并开始制作约稿委托的曲子。`,"green");
  render()
}
function commissionDaily(){
  for(const x of [...state.commissions]){
    // Portfolio purchases from older saves are still handled safely, but new purchases enter the library immediately.
    if(x.portfolioSong){
      if(state.day>=x.deliverDay){
        state.library.push(x.portfolioSong);
        state.commissions=state.commissions.filter(a=>a.id!==x.id);
        log(`作品集歌曲《${x.name}》已进入曲库。`,"green-strong");
        onSongAddedToLibrary(x.portfolioSong);
      }
      continue;
    }

    let total=Math.max(1,x.deliverDay-x.startDay);
    let progress=clamp((state.day-x.startDay)/total,0,1);

    for(const pct of [20,50,80]){
      if(progress>=pct/100&&!x.notified[pct]){
        x.notified[pct]=true;
        let c=getComposer(x.composerId);
        let workName=x.title?`《${x.title}》`:"约稿委托曲";
        log(`约稿进度：${c?.name||"曲师"} 的${workName}已完成 ${pct}% 。`,"green");
      }
    }

    if(state.day>=x.deliverDay){
      let c=getComposer(x.composerId);
      let title=x.title||pickCommissionTitle(x.style);
      let s=makeSong(title,x.q,x.style,abstractRoll(c,true),c.id,"commission");
      s.attention*=1+c.popularity/100;
      s.originalAttention=s.attention;
      state.library.push(s);
      c.collabs++;

      if(x.incomingOffer){
        // 保留旧版主动来稿的好感收益，只把结算时间移动到真正制作完成时。
        let existingCount=installedSongs().filter(z=>z.composerId===c.id).length;
        let affectionGain=(100/Math.max(1,c.affDifficulty))*(existingCount>5?1.2:1);
        c.affection+=affectionGain
      }else{
        c.affection+=10/Math.max(1,c.affDifficulty)
      }

      state.commissions=state.commissions.filter(a=>a.id!==x.id);
      log(`委托 ${c.name} 制作的曲子《${title}》制作完成了，已进入曲库。`,"green-strong");
      onSongAddedToLibrary(s);

      // 熟练风格 + 已合作至少3次：普通委托完成时20%概率立刻收到下一份主动来稿。
      // 任何由主动来稿产生的委托都 suppressImmediateIncoming，防止链式无限触发。
      maybeImmediateIncomingAfterCommission(c,x);
    }
  }
}

function portfolioQualityFromGood(good){
  let g=Number(good)||0;
  if(g<30)return 1;
  if(g<50)return 2;
  if(g<70)return 3;
  if(g<85)return 4;
  if(g<96)return 5;
  return 6;
}
function createSongFromPortfolio(p,c){
  let composerIds=(p.collabComposerIds&&p.collabComposerIds.length)?[...p.collabComposerIds]:[c.id];
  let s={
    id:nextId(),
    name:p.name,
    source:"portfolio",
    composer:composerIds[0],
    composerIds,
    composerLabel:p.composerLabel||c.name,
    style:p.style,
    quality:portfolioQualityFromGood(p.good),
    abstract:p.abstract,
    attention:p.attention*4,
    originalAttention:p.attention*4,
    discussion:p.discussion*4,
    originalDiscussion:p.discussion*4,
    good:p.good,
    chartProgress:0,
    artProgress:100,
    alpha:false,
    installed:false,
    chartMemberIds:[],
    artMemberId:null,
    position:"普通曲",
    alphaStatus:"idle",
    playableQuality:null,
    artPercent:100,
    play:0,
    packageId:null
  };
  return s;
}

function buyPortfolio(cid,pid){
  let c=getComposer(cid),p=c?.portfolio.find(x=>x.id===pid);if(!p||p.bought)return;
  if(c.country!=="中国"&&!state.services.vpn){log("需要 VPN 才能主动联系该曲师购买作品。");return}
  if(state.day<c.sickUntil&&c.affection<60){log("该曲师当前感冒，暂时无法购买作品。");return}
  if(state.day<c.depressedUntil&&c.affection<80){log("该曲师当前无法出售作品。");return}
  let price=p.price*(1-Math.min(.35,c.affection*.003));
  if(!canSpendMoney(price)){log("存款不足。");return}
  state.money-=price;

  // 合作作品购买一次后，所有相关曲师卡片上的同一作品同时视为已购买。
  if(p.sharedPortfolioKey){
    for(const cc of state.composers){
      for(const pp of (cc.portfolio||[])){
        if(pp.sharedPortfolioKey===p.sharedPortfolioKey)pp.bought=true
      }
    }
  }else{
    p.bought=true
  }

  let y=year()+dayOfYear()/365,scale=y>=7?1:y>=3?.5+(y-3)/4*.5:.1+(y/3)*.4;
  let primaryComposerId=(p.collabComposerIds&&p.collabComposerIds.length?p.collabComposerIds[0]:c.id);
  // 作品集歌曲必须继承作品集所属曲师，不能重新生成普通约稿歌曲的曲师信息。
  // 联合作品若没有保存ID，则根据合作标签解析，避免显示错误曲师。
  if(p.composerLabel&&!p.collabComposerIds?.length){
    let owner=state.composers.find(x=>p.composerLabel.includes(x.name));
    if(owner)primaryComposerId=owner.id;
  }
  let s=createSongFromPortfolio(p,c);
  s.composerLabel=p.composerLabel||c.name;
  s.composerIds=(p.collabComposerIds&&p.collabComposerIds.length)?[...p.collabComposerIds]:[primaryComposerId];
  s.composer=primaryComposerId;
  // 作品集歌曲实际数据：关注与讨论使用作品集填写值的4倍。
  // 进入曲库后保持与购买前一致，不受运营年份缩放影响。
  s.attention=p.attention*4;s.originalAttention=s.attention;
  s.discussion=p.discussion*4;s.originalDiscussion=s.discussion;
  s.good=p.good;
  s.chartProgress=0;
  s.artProgress=100;
  s.alpha=false;
  s.installed=false;
  // No playableQuality yet: chart + art must both be complete.
  // No play yet: it is created only when the song is formally released.
  state.library.push(s);
  log(`已购买作品集歌曲《${p.name}》：已进入曲库。`);
  onSongAddedToLibrary(s);
  render()
}
function incomingOfferQuality(c,style){
  let q=qualityRoll(c,"商业",style);
  if(state.designConceptConfirmed&&state.designStyle==="传统"&&q===5&&chance(.10))q=4;
  return q
}
function createIncomingOffer(c,options={}){
  if((state.incomingOffers||[]).length>=1)return false;
  if(!c||composerHasActiveCommission(c.id))return false;
  if(state.incomingOffers.some(o=>o.composerId===c.id))return false;

  let style=options.style||STYLE[Math.floor(Math.random()*STYLE.length)];
  let q=Number(options.q)||incomingOfferQuality(c,style);
  let normDiscussion=state.players>0?state.discussion/state.players*100:0;
  let close=Math.abs(normDiscussion-state.rating)<5;
  let free=options.free!==undefined?!!options.free:(close&&chance(clamp(.002+(100-c.mental)/50000-c.popularity/100000,0,.01)));
  let title=options.title||pickCommissionTitle(style);
  let offer={
    id:nextId(),
    composerId:c.id,
    title,
    style,
    q,
    price:free?0:c.prices["商业"]*.70,
    free,
    origin:options.origin||"monthly"
  };
  if(!state.lastIncomingOfferDayByComposer)state.lastIncomingOfferDayByComposer={};
  state.lastIncomingOfferDayByComposer[c.id]=state.day;
  state.incomingOffers.push(offer);
  log(`${c.name} 主动来稿《${title}》${free?"，并提出免费提供这首曲子":""}。`,"green");
  return true
}
function maybeImmediateIncomingAfterCommission(c,x){
  if(!c||!x||x.suppressImmediateIncoming)return;
  if(c.collabs<3)return;
  if((c.styles[x.style]||0)<80)return;
  if(!chance(.20))return;
  createIncomingOffer(c,{style:x.style,origin:"commission-followup"})
}
function composerMonthly(){
  state.composers.forEach(c=>{
    if(state.day>=c.sickUntil&&chance(.03))c.sickUntil=state.day+30;
    if(state.day>=c.depressedUntil&&state.day>=c.depressionCooldownUntil){
      let p=Math.min(.03,.005+Math.max(0,50-c.mental)/2000);
      if(chance(p)){c.depressedUntil=state.day+180;c.depressionCooldownUntil=c.depressedUntil+730;c.comfortCount=0}
    }

    // 正在制作任何委托时，不会主动来稿。
    if(composerHasActiveCommission(c.id))return;

    let incoming=.0008*(1+reputationSignal()/5000)*(1-c.popularity/150);
    if(state.temporaryPlayerEffects.some(e=>e.type==="主线"&&state.day<=e.discussUntil))incoming*=6;
    else if(state.temporaryPlayerEffects.some(e=>e.type==="大更新"&&state.day<=e.discussUntil))incoming*=3;
    let ss=styleState();if(ss.dominant&&c.styles[ss.dominant]>=80)incoming*=ss.name.includes("专一")?1.8:1.3;
    c.bond.forEach(id=>{let b=getComposer(id);if(b&&b.collabs>0)incoming*=1.08});
    if((state.incomingOffers||[]).length===0&&state.day-(state.lastIncomingOfferDayByComposer[c.id]||-9999)>=90&&chance(incoming))createIncomingOffer(c,{origin:"monthly"})
  })
}
function acceptIncomingOffer(id){
  let o=state.incomingOffers.find(x=>x.id===id),c=o?getComposer(o.composerId):null;if(!o||!c)return;
  if(composerHasActiveCommission(c.id)){
    log(`${c.name} 当前已经在制作委托，无法同时接受这份主动来稿。`);
    return
  }
  if(!canSpendMoney(o.price))return;
  state.money-=o.price;

  let days=rollCommissionDays(c.efficiency,"商业");
  if(c.styles[o.style]>=80)days*=.85;
  if(year()>=3&&state.artPursuit>90)days*=1.10;
  let q=o.q;
  if(c.mental<50){days*=rnd(1,2);if(chance((50-c.mental)/100))q=Math.max(1,q-1)}
  let deliverDay=state.day+Math.max(1,Math.round(days));

  c.lastExpediteDay=state.day;
  state.commissions.push({
    id:nextId(),
    composerId:c.id,
    style:o.style,
    nature:"商业",
    q,
    startDay:state.day,
    deliverDay,
    title:o.title,
    displayName:`《${o.title}》`,
    notified:{20:false,50:false,80:false},
    incomingOffer:true,
    incomingOfferOrigin:o.origin||"monthly",
    suppressImmediateIncoming:true
  });
  state.incomingOffers=state.incomingOffers.filter(x=>x.id!==id);
  log(`已接受 ${c.name} 的主动来稿《${o.title}》，曲师开始制作。`,"green");
  render()
}
function declineIncomingOffer(id){state.incomingOffers=state.incomingOffers.filter(x=>x.id!==id);render()}
function comfortComposer(id){
  let c=getComposer(id);if(!c||state.day>=c.depressedUntil||c.affection<80)return;
  c.comfortCount=c.comfortCount||0;
  if(c.comfortCount>=5){log("该曲师本次抑郁期间已陪伴5次。");return}
  c.comfortCount++;
  c.depressedUntil=Math.max(state.day,c.depressedUntil-15);
  log(`陪伴 ${c.name}：接下来3天将直接跳过，抑郁持续时间减少15天。`);
  for(let i=0;i<3;i++)endDay();
}
function createPackage(){let type=packageType.value;state.packages.push({id:nextId(),name:`${type} #${state.packages.length+1}`,type,songIds:[],storyWordsAssigned:0,storyExpectationMultiplier:1,status:"整理中",betaRemaining:0,betaTotal:0,betaReduction:0,betaExtraDays:0,scoreTrackerFailureReduction:0,leaked:false,releaseDay:null,reviewDelay:0,reviewEventChecked:false,reviewCheckDay:null,announcementFanBonus:0,announcementDiscussionBonus:0,announcementBeforeReview:false,createdDay:state.day});render()}
function packageSupportsStory(p){return !!p&&["主线包","支线包","补充包"].includes(p.type)}
function packageStoryWordCapacity(p){return GAME_RULES.packageStoryCapacity((p?.songIds||[]).length)}
function addStoryToPackage(pid){
  let p=getPackage(pid);if(!p||p.status!=="整理中"||!packageSupportsStory(p))return;
  let step=GAME_RULES.copywriterRules.packageStoryStep;
  let capacity=packageStoryWordCapacity(p);
  if((p.storyWordsAssigned||0)+step>capacity)return log("这个曲包目前没有更多剧情容量；每增加一首歌曲可多容纳2000字，最高20000字。");
  if(state.storyWords<step)return log("可分配剧情字数不足1000字。");
  let allocation=GAME_RULES.applyStoryAllocation({availableWords:state.storyWords,wordCap:state.storyWordCap},step);
  state.storyWords=allocation.availableWords;
  state.storyWordCap=allocation.wordCap;
  p.storyWordsAssigned=(p.storyWordsAssigned||0)+step;
  p.storyExpectationMultiplier=(p.storyExpectationMultiplier||1)*GAME_RULES.copywriterRules.packageExpectationMultiplier;
  state.expectation*=GAME_RULES.copywriterRules.packageExpectationMultiplier;
  log(`已为《${p.name}》增加1000字剧情；玩家开始重新揣测这次更新的规模。`,"green");
  render()
}
function refundPackageStory(p){
  let amount=Math.max(0,Number(p?.storyWordsAssigned)||0);
  if(amount<=0)return 0;
  p.storyWordsAssigned=0;
  let refund=GAME_RULES.refundStoryAllocation({availableWords:state.storyWords,wordCap:state.storyWordCap},amount);
  state.storyWords=refund.availableWords;
  state.storyWordCap=refund.wordCap;
  return amount
}
function cancelPackageBuilding(pid){
  let p=getPackage(pid);if(!p||p.status!=="整理中"||p.collab)return;
  let refunded=refundPackageStory(p);
  for(const id of p.songIds||[]){let s=getSong(id);if(s)s.packageId=null}
  state.packages=state.packages.filter(item=>item.id!==pid);
  log(`已取消建包《${p.name}》${refunded?`，归还${fmt(refunded)}字可分配剧情`:""}。`);
  render()
}
function addSongToPackage(pid,sid,pos){let p=getPackage(pid),s=getSong(sid);if(!p||!s||s.installed)return;if(p.songIds.includes(sid)){let nextCapacity=GAME_RULES.packageStoryCapacity(p.songIds.length-1);if((p.storyWordsAssigned||0)>nextCapacity)return log("当前已加入的剧情超过移除歌曲后的容量，无法移除这首歌。");p.songIds=p.songIds.filter(x=>x!==sid);s.packageId=null;render();return}if(s.chartProgress<100){log("只有已经完成谱面的歌曲才能提前整理进曲包。");return}if(s.packageId&&s.packageId!==pid)return log("该曲被其他未完成曲包占用。");p.songIds.push(sid);s.packageId=pid;s.position=pos;render()}
function alphaDurationForSong(s){
  finalizePlayableQuality(s);
  if(typeof s.playableQuality!=="number")return null;
  // 默认15天；可玩质量越低耗时越长，越高越短，最终限制1~30天。
  // 程序必需映射：可玩质量70对应15天，每偏离2点约变化1天。
  let base=15+(70-s.playableQuality)*0.5;
  // 4级及以上谱师越多越快；通过此方式最多减少10天。
  let seniorCharts=state.members.filter(m=>m.role==="chart"&&m.rarity>=4).length;
  let chartReduction=Math.min(10,seniorCharts*2);
  return Math.round(clamp(base-chartReduction,1,30));
}
function alphaSong(sid){
  let s=getSong(sid);if(!s||s.installed)return;
  finalizePlayableQuality(s);
  if(typeof s.playableQuality!=="number"){log("谱面和美术都完成后才能进行 Alpha 测试。");return}
  if(s.alphaStatus==="running"){log(`《${s.name}》正在进行 Alpha 测试，剩余 ${s.alphaRemaining} 天。`);return}
  if(s.alphaStatus==="completed"||s.alpha){log(`《${s.name}》已经完成过 Alpha 测试，每首曲子只能进行一次。`);return}
  let days=alphaDurationForSong(s);
  s.alphaStatus="running";s.alphaRemaining=days;s.alphaTotal=days;
  log(`《${s.name}》开始 Alpha 测试，预计需要 ${days} 天。`);
  render()
}
function alphaDaily(){
  for(const s of state.library){
    if(s.alphaStatus!=="running")continue;
    s.alphaRemaining=Math.max(0,s.alphaRemaining-1);
    if(s.alphaRemaining<=0){
      s.alphaStatus="completed";s.alpha=true;
      if(!s.alphaBonusApplied){
        let beforeAlpha=s.playableQuality;
        s.playableQuality=clamp(s.playableQuality+2,0,100);
        if(beforeAlpha<50&&s.playableQuality<50)s.playableQuality=50;
        s.alphaBonusApplied=true;
      }
      log(`Alpha 测试完成：《${s.name}》可玩质量略微提升。`,"green-strong");
    }
  }
}
function packageRules(p){
  let s=p.songIds.map(getSong).filter(Boolean);
  if(p.type==="单曲")return{ok:s.length===1,msg:"单曲必须正好1首。"};
  if(s.length<3)return{ok:false,msg:"曲包至少3首。"};
  let n=s.filter(x=>x.position==="普通曲").length,b=s.filter(x=>x.position==="魔王曲").length,h=s.filter(x=>x.position==="隐藏曲").length;
  if(h>b)return{ok:false,msg:"隐藏曲最多与魔王曲一样多。"};
  if(b>0&&n<b*3)return{ok:false,msg:"普通曲必须至少是魔王曲3倍。"};
  return{ok:true,msg:""}
}
function betaReductionByVeterans(){
  // 只有2级及以上且入组至少1年的成员参与。
  let eligible=state.members.filter(m=>m.rarity>=2&&(state.day-m.joinDay)>=365);
  if(!eligible.length)return 0;
  // 待得越久，贡献越高；程序必需映射：每位成员满1年后贡献0.5天，
  // 此后每多1年额外+0.25天，所有成员合计最多减5天。
  let reduction=0;
  for(const m of eligible){
    let years=Math.floor((state.day-m.joinDay)/365);
    reduction+=0.5+Math.max(0,years-1)*0.25;
  }
  return Math.min(5,reduction);
}
function startBeta(pid){
  let p=getPackage(pid);if(!p||p.status!=="整理中")return;
  if(!state.hasReleasedUpdate&&p.type!=="主线包")return log("游戏的第一次更新必须是主线包。");
  let r=packageRules(p);if(!r.ok)return log(r.msg);
  let s=p.songIds.map(getSong);
  if(!state.hasReleasedUpdate&&state.gameCoreProgress<100)return log("第一次Beta测试前，必须先将“游戏本体制作进度”完成到100%。");
  if(s.some(x=>x.chartProgress<100||x.artProgress<100))return log("Beta要求全部歌曲完成谱面与封面。");
  // Alpha 不再是 Beta 前置条件；但已经主动开始的 Alpha 必须结束后才能送测。
  if(s.some(x=>x.alphaStatus==="running"))return log("曲包中有歌曲正在进行 Alpha 测试，请等待该测试完成后再开始 Beta。");
  if(p.type==="补充包"&&((year()<3&&state.consecutiveSupplement>=1)||(year()>=3&&state.consecutiveSupplement>=3)))return log("补充包连续次数达到限制。");
  let reduce=betaReductionByVeterans();
  let baseDays=Math.max(10,Math.round(15-reduce));
  let leakDelay=0;
  if((state.pendingLeakBetaDelay||0)>0&&p.id!==state.pendingLeakSourcePackageId){
    leakDelay=state.pendingLeakBetaDelay;
    state.pendingLeakBetaDelay=0;
    state.pendingLeakSourcePackageId=null
  }
  let days=baseDays+leakDelay;
  p.status="Beta测试";p.betaRemaining=days;p.betaTotal=days;p.betaReduction=15-baseDays;p.betaExtraDays=leakDelay;p.scoreTrackerFailureReduction=0;p.leaked=false;
  p.releaseDay=null;p.reviewDelay=0;p.reviewEventChecked=false;p.reviewCheckDay=null;
  p.announcementFanBonus=0;p.announcementDiscussionBonus=0;p.announcementBeforeReview=false;
  log(`${p.name} 开始 Beta 测试：基础15天${p.betaReduction>0?`，资深成员使其减少 ${p.betaReduction} 天`:""}${leakDelay>0?`，受上次泄密影响增加 ${leakDelay} 天`:""}。`);
  render()
}
function cancelBeta(pid){
  let p=getPackage(pid);if(!p||p.status!=="Beta测试")return;
  p.status="整理中";
  p.betaRemaining=0;p.betaTotal=0;p.betaReduction=0;p.betaExtraDays=0;p.scoreTrackerFailureReduction=0;p.leaked=false;
  p.releaseDay=null;p.reviewDelay=0;p.reviewEventChecked=false;p.reviewCheckDay=null;
  p.announcementFanBonus=0;p.announcementDiscussionBonus=0;p.announcementBeforeReview=false;
  log(`${p.name} 的 Beta 测试已取消，测试进度归零。`);
  render()
}
function activeLeakers(){
  return state.members.filter(m=>m.leaker&&!m.confessedLeak&&!memberOccupied(m)&&m.status!=="事务占用")
}
function betaLeakDaily(){
  if(state.day-(state.lastBetaLeakDay||-9999)<GAME_RULES.betaLeakRules.cooldownDays)return;
  let leakerCount=activeLeakers().length;
  for(const p of state.packages.filter(x=>x.status==="Beta测试"&&!x.leaked)){
    let songs=p.songIds.map(getSong).filter(Boolean);
    if(!songs.length)continue;
    if(!chance(GAME_RULES.betaLeakChance(p.type,leakerCount)))continue;
    let leakedSong=songs[Math.floor(Math.random()*songs.length)];
    p.leaked=true;
    p.leakedDay=state.day;
    state.lastBetaLeakDay=state.day;
    state.leakDiscussionUntil=Math.max(state.leakDiscussionUntil||0,state.day+GAME_RULES.betaLeakRules.discussionBuffDays);
    state.pendingLeakBetaDelay=GAME_RULES.randomIntegerInclusive(
      GAME_RULES.betaLeakRules.nextBetaDelayMin,
      GAME_RULES.betaLeakRules.nextBetaDelayMax
    );
    state.pendingLeakSourcePackageId=p.id;
    applyRandomMemberAffection(m=>m.affection<50,3,-1);
    log(`警告：我们未来将要更新的《${leakedSong.name}》被组里的某人泄露了！`,"red");
    break
  }
}
function betaDaily(){
  betaLeakDaily();
  for(const p of state.packages.filter(x=>x.status==="Beta测试")){
    p.betaRemaining--;
    if(p.betaRemaining<=0){
      p.status="等待上架";
      p.betaRemaining=0;
      p.reviewDelay=0;
      p.reviewEventChecked=false;
      p.reviewCheckDay=state.day+1;
      p.releaseDay=state.day+3;
      p.announcementFanBonus=p.announcementFanBonus||0;
      p.announcementDiscussionBonus=p.announcementDiscussionBonus||0;
      p.announcementBeforeReview=false;
      log(`${p.name} Beta 测试完成，将在3天后上架。`);
    }
  }

  for(const p of state.packages.filter(x=>x.status==="等待上架")){
    if(!p.reviewEventChecked&&p.reviewCheckDay!==null&&state.day>=p.reviewCheckDay){
      p.reviewEventChecked=true;
      let extra=chance(.20)?Math.floor(rnd(1,6)):0;
      p.reviewDelay=extra;
      if(extra>0){
        p.releaseDay+=extra;
        if(p.announcementBeforeReview){
          p.announcementDiscussionBonus=Math.max(p.announcementDiscussionBonus||0,.05);
          let reviewCommunityText=chance(.5)
            ?"玩家没有等来约定好的游戏更新，社区内开始讨论应用商店在抢歌曲首杀的可能性。"
            :"公告标注的更新日期到了，但玩家并没有见到更新。大家都在疑惑为什么音乐游戏老是被卡审核。";
          log(reviewCommunityText,"blue");
        }
        log(`特殊事件“更新卡审核”：${p.name} 上架时间额外延长 ${extra} 天。`);
      }
    }
    if(state.day>=p.releaseDay)publishPackage(p.id)
  }
}
function expectedForPackage(p){let e=state.expectation;if(p.type==="主线包")e*=1.5;if(p.type==="补充包")e*=.1;if(p.type==="主线包"){let s=p.songIds.map(getSong),o=s.filter(x=>x.source==="commission").length/Math.max(1,s.length);if(o>.8)e*=1.12}return e}
function packageQuality(p){let s=p.songIds.map(getSong);if(!s.length)return 0;s.forEach(finalizePlayableQuality);let q=s.reduce((a,x)=>a+x.quality*20+x.playableQuality,0)/(s.length*2);if(s.length<4)q*=.9;return q+state.programQualityBoost}
function publishPackage(pid){
let p=getPackage(pid);if(!p||p.status!=="等待上架")return;
let isFirstFormalRelease=!state.hasReleasedUpdate;
if(isFirstFormalRelease&&p.type!=="主线包"){
  p.status="整理中";p.betaRemaining=0;p.betaTotal=0;p.betaReduction=0;p.releaseDay=null;p.reviewDelay=0;p.reviewEventChecked=false;p.reviewCheckDay=null;
  log("游戏的第一次更新必须是主线包。该曲包已返回整理状态。");
  render();
  return
}for(const s of p.songIds.map(getSong).filter(Boolean)){if(year()>=3&&state.artPursuit>99&&s.quality<=2){s.packageId=null;p.songIds=p.songIds.filter(x=>x!==s.id)}else if(year()>=3&&state.artPursuit>90&&s.quality===1){s.packageId=null;p.songIds=p.songIds.filter(x=>x!==s.id)}}let live=p.songIds.map(getSong).filter(Boolean);if(!live.length){refundPackageStory(p);p.status="取消";render();return}let expected=expectedForPackage(p),actual=packageQuality(p),expectationOutcome=GAME_RULES.expectationReleaseOutcome({actual,expected}),total=live.length;for(const s of live){finalizePlayableQuality(s);let att=s.attention,pl=generatePlayOnRelease(s),gd=s.good;
    if(s.composerId){
      let c=getComposer(s.composerId),count=installedSongs().filter(x=>x.composerId===s.composerId||(Array.isArray(x.composerIds)&&x.composerIds.includes(s.composerId))).length+1;
      if(count>5&&c){c.popularity+=.5;c.affection+=.2}
      if(count>10){
        let n=count-10,pen=Math.pow(.92,n);
        if(state.artPursuit>99)pen=1;else if(state.artPursuit>90)pen=1-(1-pen)/2;
        s.playableQuality*=pen
      }
    }if(s.position==="魔王曲"){
      att*=2*(1+state.rating/500+state.players/100000);
      if(s.composerId){let cc=getComposer(s.composerId);if(cc)cc.affection+=1+state.rating/100+state.players/10000}
      if(s.quality<=2){state.metaDiscussion+=20;state.metaRating-=4}
    }else if(s.position==="隐藏曲"){att*=2.3;pl*=1.3;gd=70+(gd-70)*.6;state.pendingHiddenBugBonus=Math.max(state.pendingHiddenBugBonus,20);if(s.quality<=3){state.metaDiscussion+=25;state.metaRating-=5}if(s.playableQuality>=85)s.hiddenArtPendingUntil=state.day+30}att*=Math.max(.45,1-(total-4)*.05);s.attention=att;s.originalAttention=att;s.play=pl;s.originalPlay=pl;s.good=gd;s.installed=true;s.installedDay=state.day;s.packageId=null}
if((p.type==="主线包"||p.type==="支线包")&&rumorActive())endRumorByUpdate();if(p.type==="主线包"){let o=live.filter(s=>s.source==="commission").length/live.length;if(o<.4)live.forEach(s=>s.attention*=.6);if(o>.8){state.stickiness+=3;live.forEach(s=>s.attention*=1.12)}}
let releaseMultipliers=expectationOutcome.releaseMultipliers;
live.forEach(s=>{s.attention*=releaseMultipliers.attention;s.play*=releaseMultipliers.play;s.good*=releaseMultipliers.good;s.discussion*=releaseMultipliers.discussion});
if(expectationOutcome.discussionDecayDays)state.pendingDiscussionDrops.push({day:state.day+expectationOutcome.discussionDecayDays,factor:expectationOutcome.discussionDecayFactor});
if(expectationOutcome.tier==="met")state.stickiness+=(1+state.expectation/100)*artMods().stick*styleState().stickyMul;
state.expectation*=expectationOutcome.expectationMultiplier;
if(p.type==="支线包"){let sideScale=1+clamp(state.rating,0,100)/100;state.metaRating+=2*sideScale*artMods().ratingGrowth;state.expectation+=2*sideScale}if(p.type==="补充包")state.expectation+=.5;if(p.type==="单曲")live.forEach(s=>s.attention*=.2);
if((p.announcementFanBonus||0)>0)live.forEach(s=>s.attention*=1+p.announcementFanBonus);
if((p.announcementDiscussionBonus||0)>0)live.forEach(s=>s.discussion*=1+p.announcementDiscussionBonus);
let dgRelease=designGrowthMultipliers();
live.forEach(s=>{
  s.attention*=dgRelease.fan;s.originalAttention*=dgRelease.fan;
  s.discussion*=dgRelease.discussion;s.originalDiscussion*=dgRelease.discussion;
  if(typeof s.play==="number"){s.play*=dgRelease.player;s.originalPlay*=dgRelease.player}
});
if(p.leaked){
  live.forEach(s=>{
    s.discussion*=GAME_RULES.betaLeakRules.releaseDiscussionMultiplier;
    s.originalDiscussion*=GAME_RULES.betaLeakRules.releaseDiscussionMultiplier
  })
}
state.hasReleasedUpdate=true;
if(!state.ruthlessWarBusEventDone&&live.some(s=>String(s.name||"").trim().toLowerCase()==="ruthless war")){
  state.ruthlessWarBusEventDone=true;
  log(`伟大的《ruthless war》作为音乐游戏界的”公交车歌曲“，这回停在了《${gameName()}》这款非商业音乐游戏！玩家们兴奋地将《${gameName()}》也加入了“公交车停靠站列表”。`,"green")
}
if(isFirstFormalRelease&&state.gameCoreProgress>=100){
  state.chartEditorUnlocked=true;
  state.chartEditorProgress=clamp(state.chartEditorProgress,0,100);
  firstReleaseEvaluation(actual);
}
recalcPublic();
scheduleScoreTrackerFailure(p);
addUpdateStreamerWindow(p.type);let pre=Math.max(1,state.players);if(p.type==="主线包"){state.temporaryPlayerEffects.push({discussUntil:state.day+15,discussMul:1.5,extraPlayers:pre*.20,playerHoldUntil:state.day+30,fadeUntil:state.day+60,type:"主线"});state.lastMainlineDay=state.day;state.consecutiveSupplement=0;state.consecutiveSingles=0}else if(p.type==="支线包"||p.type==="补充包"){state.temporaryPlayerEffects.push({discussUntil:state.day+15,discussMul:1.2,extraPlayers:pre*.10,playerHoldUntil:state.day+15,fadeUntil:state.day+45,type:"大更新"});state.consecutiveSupplement=p.type==="补充包"?state.consecutiveSupplement+1:0;state.consecutiveSingles=0}else{state.temporaryPlayerEffects.push({discussUntil:state.day+7,discussMul:1.1,extraPlayers:pre*.05,playerHoldUntil:state.day+7,fadeUntil:state.day+37,type:"小更新"});state.consecutiveSingles++;state.consecutiveSupplement=0}
let refreshInterval=!(p.type==="单曲"&&state.consecutiveSingles>5);
if(!state.updateClockStarted){state.updateClockStarted=true;state.updateClockStartDay=state.day}
if(refreshInterval)state.lastUpdateDay=state.day;
state.hiatusTriggered=false;p.status="已上线";state.programQualityBoost=0;recalcArt();recalcPublic();bugOnRelease();
state.bugChance=clamp(BASE_BUG+state.pendingHiddenBugBonus,0,100);state.pendingHiddenBugBonus=0;
render()}
function songDaily(){for(const s of installedSongs()){let sp=s.quality===5?.6:s.quality===4?.8:1,ad=Math.exp(Math.log(.01)/(730/sp)),pd=Math.exp(Math.log(.01)/(1095/sp));s.attention=Math.max(s.originalAttention*.01,s.attention*ad);s.discussion=Math.max(s.originalDiscussion*.01,s.discussion*ad);if(typeof s.play==="number")s.play=Math.max(s.originalPlay*.01,s.play*pd);if(s.hiddenArtPendingUntil&&state.day>=s.hiddenArtPendingUntil){let currentWithoutEvent=state.artPursuit,room=Math.max(0,95-currentWithoutEvent);state.artEventBonus+=Math.min(10,room);s.hiddenArtPendingUntil=null}}for(const e of [...state.pendingDiscussionDrops])if(state.day>=e.day){installedSongs().forEach(s=>s.discussion*=e.factor);state.pendingDiscussionDrops=state.pendingDiscussionDrops.filter(x=>x!==e)}}
function hiatusCheck(){
  if(!state.updateClockStarted){
    if(state.day<=240)return;
    state.updateClockStarted=true;state.updateClockStartDay=240;state.lastUpdateDay=240;
  }
  let gap=state.day-(state.lastUpdateDay||state.updateClockStartDay);
  if(year()<3){
    if(gap>=90&&gap%30===0&&state.members.length){
      let eligible=state.members.filter(m=>!memberOccupied(m)&&!GAME_RULES.memberProtectedFromInactivityDeparture({currentDay:state.day,actualJoinDay:m.actualJoinDay??m.joinDay}));
      if(eligible.length){
        let leave=eligible[Math.floor(Math.random()*eligible.length)];
        removeMember(leave.id,`由于连续3个月都没进行有意义的更新，${leave.name}决定离开制作组。`,"red")
      }
    }
    if(gap>=180&&!state.hiatusTriggered)triggerHiatus()
  }else{
    if(gap>=150&&gap%30===0)state.metaFans-=Math.max(20,state.fans*.3);
    if(gap>=240&&!state.hiatusTriggered)triggerHiatus()
  }
}
function triggerHiatus(){
installedSongs().forEach(s=>{s.attention*=.01;s.discussion*=.01;s.play*=.10});state.metaFans*=.01;state.metaDiscussion*=.01;state.metaPlayers*=.10;state.stickiness*=.10;state.hiatusTriggered=true;log("游戏已经很久没更新了，玩家已经注意到我们的长期断更。","red")}
function mainlineGapCheck(){
  let base=state.lastMainlineDay===null?1:state.lastMainlineDay;
  let g=state.day-base;
  if(g===365){state.metaDiscussion+=Math.max(10,state.discussion*.15);state.metaRating-=Math.max(1,state.rating*.05);state.expectation*=1.08}
  if(g===730){state.metaDiscussion-=Math.max(10,state.discussion*.45);state.expectation*=.95}
}
function bugOnRelease(){
  if(!chance(state.bugChance/100))return;
  if(chance(.20)){state.severeBugUntil=state.day+3;state.metaRating-=Math.max(5,state.rating*.10);state.metaDiscussion+=Math.max(10,state.discussion*.20);log("出现严重Bug：游玩人数3天内变为原先10%。")}
  else{state.metaRating-=Math.max(2,state.rating*.05);state.metaDiscussion+=Math.max(5,state.discussion*.10);log("出现普通Bug：好评下降、讨论增加。")}
}
function createCollabOffer(){
  if(state.currentCollabOffer)return false;
  state.currentCollabOffer={id:nextId(),day:state.day,...GAME_RULES.rollCollabOffer(state.day)};
  state.collabFailStack=0;
  state.collabsThisYear++;
  state.collabRequestEverTriggered=true;
  log(`《${state.currentCollabOffer.gameName}》向我们的游戏发送了联动邀请！他们提议授权我们${state.currentCollabOffer.songCount}首歌曲。`,"green");
  return true
}
function collabMonthly(){let yearlyMax=state.artPursuit>99?2:4;if(!GAME_RULES.collabAvailableFromYear(year())||state.currentCollabOffer||state.collabsThisYear>=yearlyMax||state.day<(state.collabOpinionBlockedUntil||0))return;let b=Math.min(.50,.05+Math.max(0,year()-1)*.03+state.collabFailStack*.08);if(state.artPursuit>99)b*=.3;if(chance(b))createCollabOffer();else state.collabFailStack++}
function forceCollabOfferDaily(){if(GAME_RULES.shouldForceCollabOffer({day:state.day,everTriggered:state.collabRequestEverTriggered}))createCollabOffer()}
function acceptCollab(){if(!state.currentCollabOffer||!spendAP(6))return;let offer=state.currentCollabOffer,ids=[],count=offer.songCount;for(let i=0;i<count;i++){let q=weighted([[3,.6],[4,.3],[5,.1]]);if(year()>=7&&!state.firstYear7CollabDone)q=Math.max(4,q);let style=STYLE[i%3],title=GAME_RULES.formatCollabSongTitle(offer.gameName,pickCommissionTitle(style));let s=makeSong(title,q,style,0,null,"collab");s.artProgress=100;state.library.push(s);onSongAddedToLibrary(s);ids.push(s.id)}state.firstYear7CollabDone=state.firstYear7CollabDone||year()>=7;let p={id:nextId(),name:`与《${offer.gameName}》联动曲包 #${state.collabs.length+1}`,type:"支线包",songIds:ids,storyWordsAssigned:0,storyExpectationMultiplier:1,status:"整理中",betaRemaining:0,betaTotal:0,betaReduction:0,betaExtraDays:0,scoreTrackerFailureReduction:0,leaked:false,releaseDay:null,createdDay:state.day,collab:true};state.packages.push(p);state.collabs.push({id:nextId(),packageId:p.id,gameName:offer.gameName,songCount:count,acceptedDay:state.day,cancelDeadline:state.day+90,forcedDeadline:offer.forcedDeadline,active:true});state.collabPenaltyDays=7;state.currentCollabOffer=null;render()}
function declineCollab(){state.currentCollabOffer=null;render()}function cancelCollab(id){let c=state.collabs.find(x=>x.id===id&&x.active);if(!c||state.day>c.cancelDeadline||!spendAP(6))return;let p=getPackage(c.packageId);if(p&&p.status!=="已上线"){refundPackageStory(p);p.songIds.forEach(id=>state.library=state.library.filter(s=>s.id!==id));p.status="取消"}c.active=false;state.collabPenaltyDays=7;render()}
function collabDeadlineCheck(){for(const c of state.collabs.filter(x=>x.active)){let p=getPackage(c.packageId);if(p?.status==="已上线"){c.active=false;continue}if(state.day>=c.forcedDeadline){let ss=p?p.songIds.map(getSong).filter(Boolean):[],sum=ss.reduce((a,s)=>a+s.quality,0);if(chance(.5))state.money-=800*sum;else{state.players=state.playerFloor;state.rating=state.ratingFloor}if(p){refundPackageStory(p);p.status="取消";p.songIds.forEach(id=>state.library=state.library.filter(s=>s.id!==id))}c.active=false}}}
function yearlySpecials(){if(year()>=2&&!state.firstYear2EventDone){state.firstYear2EventDone=true;let threshold=1000;state.members.forEach(m=>{if(memberOccupied(m))return;if(state.players>threshold&&m.status!=="疑虑")setMemberMotivated(m);else if(state.players<=threshold&&m.status!=="干劲满满"&&GAME_RULES.memberCanEnterDoubt(m.affection))m.status="疑虑"})}}

function rumorActive(){return state.day < (state.rumorActiveUntil||0)}
function endRumorByUpdate(){
  if(!rumorActive())return;
  state.rumorActiveUntil=0;
  state.rumorMinGapDays=180;
  log("主线包/支线包上线，直接结束“被竞争对手企划带节奏”状态；下一次造谣事件最短间隔延长为6个月。");
}
function rumorDaily(){
  if(rumorActive()){
    if(state.day>=state.rumorActiveUntil){
      state.rumorActiveUntil=0;
      log("“被竞争对手企划带节奏”状态已自然结束。");
    }
    return;
  }
  if(state.fans<=3000||state.rating<30||state.rating>90)return;
  if(state.rumorTriggersThisYear>=2)return;
  if(state.day-state.rumorLastTriggerDay<state.rumorMinGapDays)return;
  if(chance(.01)){
    state.rumorTriggersThisYear++;
    state.rumorLastTriggerDay=state.day;
    state.rumorActiveUntil=state.day+30;
    state.metaFans=Math.max(-999999,(state.metaFans||0)-30);
    log(`最近，竞争对手企划开始带《${gameName()}》的负面节奏！我们的游戏社区似乎被煽动了，或许一个月内都会受到影响……`,"red");
  }
}

function growthSpeedMultiplier(){
  return state.day<=(state.badLaunchUntil||0)?.70:1;
}
function firstReleaseEvaluation(actual){
  if(state.firstReleaseEvaluated)return;
  state.firstReleaseEvaluated=true;
  state.firstReleaseTier=GAME_RULES.firstReleaseTier(actual);
  if(state.firstReleaseTier==="bad"){
    state.badLaunchUntil=state.day+60;
    log("第一次更新收获了很多的反馈与批评。社区里还有一些骂声说“怎么又有新的不知名音游出现了”。但没有关系，这只是一切的开始，我们的努力将克服后续的所有困难。一起加油吧！");
  }else if(state.firstReleaseTier==="normal"){
    log("第一次游戏更新成功！玩家反响平平。但这只是一切的开始，我们还有很长的路要走，大家一起加油吧！");
  }else{
    state.perfectLaunchUntil=state.day+60;
    state.streamerWindows.push({
      id:nextId(),kind:"perfect",startDay:state.day,endChanceDay:state.day+60,expireDay:state.day+60,
      maxStreams:3,used:[],contentLabel:"入坑"
    });
    log("我们圆满迎来了第一次游戏更新！从此之后，一款崭新的音游诞生了。玩家们非常看好我们制作的音游，纷纷表示很期待后续内容！");
  }
}
function addUpdateStreamerWindow(packageType){
  if(state.fans<=5000)return;
  if(!["主线包","支线包","补充包"].includes(packageType))return;
  let label=packageType==="主线包"?"主线内容":packageType==="支线包"?"支线内容":"补充内容";
  state.streamerWindows.push({
    id:nextId(),kind:"update",startDay:state.day,endChanceDay:state.day+30,expireDay:state.day+60,
    maxStreams:5,used:[],contentLabel:label
  });
}
function streamerWindowAvailable(w){
  return state.day>w.startDay&&state.day<=w.endChanceDay&&w.used.length<w.maxStreams;
}
function tryStartStreamerAtDayStart(){
  if(state.activeStreamer)return;
  state.streamerWindows=state.streamerWindows.filter(w=>state.day<=w.expireDay);
  let windows=state.streamerWindows.filter(streamerWindowAvailable);
  if(!windows.length)return;
  // 每个有效窗口每天独立有5%概率；若同一天多个窗口命中，只启动一个直播。
  let hit=windows.find(w=>chance(.05));
  if(!hit)return;
  let candidates=state.streamers.filter(n=>!hit.used.includes(n));
  if(!candidates.length)return;
  let name=candidates[Math.floor(Math.random()*candidates.length)];
  hit.used.push(name);
  let msg=hit.kind==="perfect"
    ?`${name}正在直播《${gameName()}》的入坑实况！`
    :`${name}正在直播《${gameName()}》的${hit.contentLabel}实况！`;
  state.activeStreamer={
    name,windowId:hit.id,startDay:state.day,resolveDay:state.day+1,
    baselineFans:state.fans,baselinePlayers:state.players
  };
  log(msg,"gold");
}
function resolveStreamerAtDayEnd(){
  let a=state.activeStreamer;
  if(!a||state.day<a.resolveDay)return;
  recalcPublic();
  let fanGain=Math.max(0,state.fans-a.baselineFans);
  let playerGain=Math.max(0,state.players-a.baselinePlayers);
  let mult=chance(.01)?30:chance(.05)?10:3;
  state.metaFans+=(mult-1)*fanGain;
  state.metaPlayers+=(mult-1)*playerGain;
  if(fanGain>0||playerGain>0)log(`${a.name}的直播结束：本日新增关注与游玩增长按 ${mult} 倍结算。`,"green");
  state.activeStreamer=null;
}
function reduceScoreTrackerFailureChanceDuringBeta(){
  for(const p of state.packages.filter(p=>p.status==="Beta测试"&&(p.type==="主线包"||p.type==="支线包"))){
    p.scoreTrackerFailureReduction=GAME_RULES.nextScoreTrackerFailureReduction(p.scoreTrackerFailureReduction)
  }
}
function scheduleScoreTrackerFailure(p){
  if(!state.hasScoreTracker||state.scoreTrackerBroken||!p||!(p.type==="主线包"||p.type==="支线包"))return;
  if(!chance(GAME_RULES.scoreTrackerFailureChance(p.scoreTrackerFailureReduction)))return;
  let dueDay=state.day+GAME_RULES.rollScoreTrackerFailureDelay();
  if(!state.scoreTrackerFailureDays.includes(dueDay))state.scoreTrackerFailureDays.push(dueDay);
  state.scoreTrackerFailureDays.sort((a,b)=>a-b)
}
function scoreTrackerDaily(){
  if(!state.hasScoreTracker||state.scoreTrackerBroken)return;
  if(!state.scoreTrackerFailureDays.some(d=>d<=state.day))return;
  state.scoreTrackerBroken=true;
  state.scoreTrackerRepairProgress=0;
  state.scoreTrackerFailureDays=[];
  log(`社区的《${gameName()}》查分器似乎失效了。你并不清楚自己该不该为此做点什么。`,"blue")
}
function advanceScoreTrackerRepair(){
  if(!state.hasScoreTracker||!state.scoreTrackerBroken)return;
  state.scoreTrackerRepairProgress=clamp(state.scoreTrackerRepairProgress+GAME_RULES.scoreTrackerRepairGain(state.tech),0,100);
  if(state.scoreTrackerRepairProgress<100)return;
  state.scoreTrackerBroken=false;
  state.scoreTrackerRepairProgress=100;
  log(`社区的《${gameName()}》查分器又能运作了。`,"blue")
}
function naturalPlayerGrowth(){let y=year()+dayOfYear()/365,f=y<=3?.3+.7*(y/3):y<=7?1-(y-3)/4*.9:.1;f*=styleState().playerMul*growthSpeedMultiplier()*designGrowthMultipliers().player;f*=GAME_RULES.scoreTrackerGrowthMultiplier({hasScoreTracker:state.hasScoreTracker,isBroken:state.scoreTrackerBroken});if(state.stickiness>=70)f*=1.15;state.metaPlayers+=Math.max(0,state.players*.00005*f);state.expectation+=.002*(1+y/7)*artMods().expect}
function saveReminder60Daily(){
  if(state.saveReminder60Done||state.day<60)return;
  state.saveReminder60Done=true;
  log("别忘记你可以对游戏进行存档！存档保存于当前浏览器本地，无法在设备或不同浏览器间互通。如果你想要导出存档，不妨试试“删除存档”右边箭头从方框向外的按钮。","gold")
}
function feedbackEmailMilestoneDaily(){
  if(state.feedbackEmailEventDone||state.day<100)return;
  state.feedbackEmailEventDone=true;
  log('反馈与提议：邮箱 <a href="mailto:yukidare2766@gmail.com" style="color:inherit;text-decoration:underline">yukidare2766@gmail.com</a><br>记得在信中留下你的ID，说不定你会被写进通关Credits里！',"purple")
}

function praiseMonthlyLockDaily(){
  if(!state.monthlyPraiseLocks)state.monthlyPraiseLocks=[];
  if(state.day%30===0){
    state.monthlyPraiseLocks.push(state.praise||0);
    if(state.monthlyPraiseLocks.length>12)state.monthlyPraiseLocks.shift();
  }
}
function applyDocumentExplosionDecay(){
  if(state.documentExplosionPenalty>0){
    state.documentExplosionPenalty*=0.98;
    if(state.documentExplosionPenalty<0.1)state.documentExplosionPenalty=0;
  }
}
function protectedArtScore(value){
  if(value<50){
    return 50-(50-value)*0.35;
  }
  return Math.min(100,value);
}
function applyLeakerSpiritRecovery(){
  let queue=state.leakerSpiritRecoveryQueue||[];
  let due=queue.filter(item=>state.day>=item.day);
  if(due.length){
    let recovery=due.reduce((sum,item)=>sum+(Number(item.amount)||0),0);
    state.fatigue=Math.max(0,state.fatigue-recovery)
  }
  state.leakerSpiritRecoveryQueue=queue.filter(item=>state.day<item.day)
}

function endDay(){state.day++;resetTakeoutForNewDay();ensureCopyFanMonth();praiseMonthlyLockDaily();applyDocumentExplosionDecay();cleanupDepartedRecoverables();updateDesignYearState();logDayEntry();applyLeakerSpiritRecovery();saveReminder60Daily();feedbackEmailMilestoneDaily();computerDaily();processMilestoneDailyRewards();scoreTrackerDaily();state.dailySpent=0;state.studyActionsToday=0;state.programWritesToday=0;state.freeMemberEventsToday=0;state.playedRhythmToday=false;state.takeoutProgramDiscount=false;state.takeoutRecruitBuff=false;tryStartStreamerAtDayStart();applyJobDay();memberAffectionDaily();processLewdImageFollowups();serviceMonthlyCost();sponsorship();state.ap=Math.min(apCap(),state.ap+todayAPGain());if(state.collabPenaltyDays>0)state.collabPenaltyDays--;memberOccupationDaily();productionDaily();copywriterDaily();commissionDaily();songDaily();alphaDaily();betaDaily();formerMemberOpinionDaily();memberDailyEvents();lewdImageDaily();coordinationDailyEvents();remindDoubtingMembers();specialRecruitmentEvents();recommendationCommissionDaily();mysteryDonationDaily();naturalPlayerGrowth();rumorDaily();
recalcPublic();
if(state.players>0&&state.fans>state.players*2)state.expectation+=.01*(state.fans/state.players-2);
if(state.players>0&&state.discussion/state.players*100>state.rating*1.5)state.metaRating-=.01;
updateFloors();hiatusCheck();mainlineGapCheck();collabDeadlineCheck();yearlySpecials();forceCollabOfferDaily();if(isMonthStart()){state.monthlyHighCoordEvents=0;state.monthlyLowCoordEvents=0;composerMonthly();collabMonthly()}if(isYearStart()){state.collabsThisYear=0;state.rumorTriggersThisYear=0;}recalcArt();recalcPublic();resolveStreamerAtDayEnd();recalcPublic();bankruptcyCheck();render()}

const SAVE_KEY="noncommercial_music_game_simulator_single_save_v1";

function saveMetaText(data){
  if(!data||!data.state)return "未检测到存档";
  let d=data.state.day||1;
  let y=Math.floor((d-1)/365)+1,dy=((d-1)%365)+1;
  let t=data.savedAt?new Date(data.savedAt).toLocaleString("zh-CN"):"";
  return `已有存档｜第${y}年 第${dy}天${t?`｜${t}`:""}`;
}

function refreshSaveStatus(){
  let el=document.getElementById("saveStatus");if(!el)return;
  try{
    let raw=localStorage.getItem(SAVE_KEY);
    if(!raw){el.textContent="未检测到存档";el.className="sub";return}
    el.textContent=saveMetaText(JSON.parse(raw));
    el.className="sub ok";
  }catch(e){
    el.textContent="浏览器本地存储不可用";
    el.className="sub badtext";
  }
}

function buildSavePayload(){
  return {
    version:"Beta49",
    savedAt:Date.now(),
    uid:uid,
    state:JSON.parse(JSON.stringify(state)),
    eventLog:document.getElementById("log").innerHTML
  }
}

function applySavePayload(payload){
  if(!payload||!payload.state)throw new Error("INVALID_SAVE");
  for(const k of Object.keys(state))delete state[k];
  Object.assign(state,payload.state);
  if(Number.isFinite(payload.uid))uid=payload.uid;
  ensureNewStateDefaults();
  syncComposerMasterData();
  document.getElementById("log").innerHTML=payload.eventLog||"";
  render();
  refreshSaveStatus()
}

function saveGame(){
  try{
    let payload=buildSavePayload();
    localStorage.setItem(SAVE_KEY,JSON.stringify(payload));
    refreshSaveStatus();
  }catch(e){
    alert("保存失败：当前浏览器可能禁止本地存储。");
  }
}

function loadGame(){
  try{
    let raw=localStorage.getItem(SAVE_KEY);
    if(!raw){alert("目前没有存档。");return}
    let payload=JSON.parse(raw);
    applySavePayload(payload)
  }catch(e){
    alert("读取存档失败：存档可能损坏，或浏览器阻止了本地存储。");
  }
}

const PORTABLE_SAVE_PREFIX="NCRGOS_SAVE_V1:";
const PORTABLE_SAVE_SECRET="non-commercial-rhythm-game-operation-simulator::portable-save::v1";

function bytesToBase64(bytes){
  let binary="";
  const chunk=0x8000;
  for(let i=0;i<bytes.length;i+=chunk){
    binary+=String.fromCharCode(...bytes.subarray(i,i+chunk))
  }
  return btoa(binary)
}
function base64ToBytes(s){
  let binary=atob(s),out=new Uint8Array(binary.length);
  for(let i=0;i<binary.length;i++)out[i]=binary.charCodeAt(i);
  return out
}
async function portableSaveKey(){
  if(!window.crypto?.subtle)throw new Error("NO_WEBCRYPTO");
  let raw=new TextEncoder().encode(PORTABLE_SAVE_SECRET);
  let digest=await crypto.subtle.digest("SHA-256",raw);
  return crypto.subtle.importKey("raw",digest,{name:"AES-GCM"},false,["encrypt","decrypt"])
}
async function encryptPortableSave(payload){
  let key=await portableSaveKey();
  let iv=crypto.getRandomValues(new Uint8Array(12));
  let plain=new TextEncoder().encode(JSON.stringify(payload));
  let encrypted=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv},key,plain));
  let packed=new Uint8Array(iv.length+encrypted.length);
  packed.set(iv,0);packed.set(encrypted,iv.length);
  return PORTABLE_SAVE_PREFIX+bytesToBase64(packed)
}
async function decryptPortableSave(raw){
  raw=String(raw||"").trim();
  if(!raw.startsWith(PORTABLE_SAVE_PREFIX))throw new Error("BAD_FORMAT");
  let packed=base64ToBytes(raw.slice(PORTABLE_SAVE_PREFIX.length));
  if(packed.length<29)throw new Error("BAD_FORMAT");
  let iv=packed.slice(0,12),cipher=packed.slice(12);
  let key=await portableSaveKey();
  let plain=await crypto.subtle.decrypt({name:"AES-GCM",iv},key,cipher);
  let payload=JSON.parse(new TextDecoder().decode(plain));
  if(!payload||!payload.state)throw new Error("BAD_PAYLOAD");
  return payload
}
function portableSaveFileName(){
  let d=new Date(),pad=n=>String(n).padStart(2,"0");
  return `non_commercial_rhythm_game_save_${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.txt`
}
async function exportSaveTxt(){
  try{
    let payload=buildSavePayload();
    let encrypted=await encryptPortableSave(payload);
    let blob=new Blob([encrypted],{type:"text/plain;charset=utf-8"});
    let url=URL.createObjectURL(blob);
    let a=document.createElement("a");
    a.href=url;
    a.download=portableSaveFileName();
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
    log("已导出加密存档 TXT。","green")
  }catch(e){
    console.error(e);
    alert("导出存档失败：当前浏览器可能不支持所需的加密功能。")
  }
}
async function importSaveTxt(file){
  if(!file)return;
  try{
    let raw=await file.text();
    let payload=await decryptPortableSave(raw);
    let d=payload.state?.day||1;
    let y=Math.floor((d-1)/365)+1,dy=((d-1)%365)+1;
    if(!confirm(`确定导入这个存档吗？\n\n存档进度：第${y}年 第${dy}天\n\n导入后会覆盖当前浏览器的唯一存档，并立即读取。`))return;
    localStorage.setItem(SAVE_KEY,JSON.stringify(payload));
    applySavePayload(payload);
    log("加密 TXT 存档导入成功。","green");
    // 让刚刚写入的“导入成功”事件同步进入本地槽。
    localStorage.setItem(SAVE_KEY,JSON.stringify(buildSavePayload()));
    refreshSaveStatus()
  }catch(e){
    console.error(e);
    alert("导入失败：文件不是有效的本游戏加密存档，或内容已损坏。")
  }
}

function deleteSave(){
  try{
    if(!localStorage.getItem(SAVE_KEY)){refreshSaveStatus();return}
    if(!confirm("确定删除唯一存档吗？删除后无法恢复。\\n\\n当前页面正在运行的进度不会立即清空；刷新页面后将无法再读取这个存档。"))return;
    localStorage.removeItem(SAVE_KEY);
    refreshSaveStatus();
  }catch(e){
    alert("删除存档失败：当前浏览器可能禁止本地存储。");
  }
}

function progressBarBlock(title,value,subtitle=""){
  return `<div class="barbox"><div class="barhead"><b>${title}</b><span>${value.toFixed(1)}%</span></div><div class="bar"><div class="fill" style="width:${clamp(value,0,100)}%"></div></div>${subtitle?`<div class="sub">${subtitle}</div>`:""}</div>`;
}
function renderDevelopmentBars(){
  ensureNewStateDefaults();
  let html="";
  if(!state.hasReleasedUpdate){
    html+=progressBarBlock("游戏本体制作进度",state.gameCoreProgress,"达到100%后才能进行第一次Beta测试");
  }else if(state.chartEditorUnlocked&&!state.chartEditorComplete){
    html+=progressBarBlock("游戏制谱器制作进度",state.chartEditorProgress,"完成后强化2级及以上谱师的每日写谱进度");
  }else if(state.chartEditorV2Unlocked&&!state.chartEditorV2Complete){
    html+=progressBarBlock("游戏制谱器V2制作进度",state.chartEditorV2Progress,"完成后为2级及以上谱师追加另一层每日写谱加成");
  }
  if(state.artStudyStarted&&GAME_RULES.shouldShowArtLearningProgress(state.artStudyProgress)){
    let artHint=state.artStudyProgress<50?"50%后解锁亲自画图":state.artStudyProgress<100?"已可亲自画图；100%前亲自画图会使成品可玩质量下降":"已彻底学会美术";
    html+=progressBarBlock("学习美术进度",state.artStudyProgress,artHint);
  }
  document.getElementById("developmentBars").innerHTML=html;
}
function showTab(b){document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));document.getElementById(b.dataset.view).classList.add("active")}function toggleDebug(){debugPanel.classList.toggle("open")}

function getManualDeviceMode(){
  return localStorage.getItem("manualDeviceMode")||"auto";
}
function toggleDeviceMode(){
  let current=getManualDeviceMode();
  let next=current==="auto"?"pc":current==="pc"?"mobile":"auto";
  localStorage.setItem("manualDeviceMode",next);
  applyDeviceMode();
}
function detectMobileDevice(){
  return (
    (window.matchMedia&&window.matchMedia("(pointer:coarse)").matches) ||
    /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent||"") ||
    (window.innerWidth||9999)<=900 ||
    Math.min(screen.width||9999,screen.height||9999)<=900
  );
}
function getEffectiveMobileMode(){
  let manual=getManualDeviceMode();
  if(manual==="mobile")return true;
  if(manual==="pc")return false;
  return detectMobileDevice();
}
function applyDeviceMode(){
  let manual=getManualDeviceMode();
  let mobile=getEffectiveMobileMode();
  document.documentElement.classList.toggle("mobile-ui",mobile);
  document.documentElement.classList.toggle("manual-mobile",manual==="mobile");
  document.documentElement.classList.toggle("manual-pc",manual==="pc");
  document.body.classList.toggle("force-mobile",manual==="mobile");
  document.body.classList.toggle("force-pc",manual==="pc");
  let b=document.getElementById("deviceSwitchButton");
  if(b){
    b.textContent=manual==="pc"?"🖥":manual==="mobile"?"📱":"↔";
    b.title=manual==="pc"?"当前强制电脑端，点击切换":manual==="mobile"?"当前强制手机端，点击切换":"当前自动检测，点击切换";
    b.setAttribute("aria-label",b.title);
  }
  if(typeof renderMobileLayout==="function")renderMobileLayout();
  if(typeof updateResponsiveLayout==="function")updateResponsiveLayout();
}
function render(){ensureNewStateDefaults();memberLeakConfessionDaily();updateDesignYearState();updateCopyRecruitmentUnlock();renderDesignConcept();
let simulatorTitle=document.getElementById("gameSimulatorTitle");
if(simulatorTitle)simulatorTitle.textContent=state.designConceptConfirmed&&state.gameName?`非商业音乐游戏《${state.gameName}》运营模拟器 · Beta 49`:"非商业音乐游戏运营模拟器 · Beta 49";
state.fatigue=clamp(state.fatigue,0,200);recalcArt();recalcPublic();timeMain.textContent=`第 ${year()+1} 年 · 第 ${dayOfYear()} 天`;dateSub.textContent=`第${monthOfYear()}月 / 本月第${dayOfMonth()}天`;let j={home:"家里蹲",easy:"短期零工",normal:"中期工作",hard:"长期合同"};jobName.textContent=j[state.job];jobSelect.value=state.job;jobLockText.textContent=state.day<(state.jobLockedUntil||1)?`主业锁定至第 ${state.jobLockedUntil} 天`:"可修改主业";money.textContent=fmt(state.money);apText.textContent=`${state.ap.toFixed(0)} / ${apCap()}`;apBar.style.width=`${Math.min(100,state.ap/apCap()*100)}%`;let spirit=clamp(200-state.fatigue,0,200);fatigueText.textContent=`${Math.round(spirit)} / 200`;fatigueBar.style.width=`${Math.min(100,spirit/200*100)}%`;
eventActionPoints.textContent=state.ap.toFixed(0);
eventSpirit.textContent=Math.round(spirit);
eventBalance.textContent=fmt(state.money);
let computerDown=computerBroken();
writeProgramBtn.disabled=computerDown;
studyProgramBtn.disabled=computerDown;
if(document.getElementById("studyProgramBtn"))studyProgramBtn.style.display=((state.programStudyCount||0)>=600)?"none":"";
studyArtBtn.disabled=computerDown;
if(document.getElementById("studyArtBtn"))document.getElementById("studyArtBtn").style.display=(state.artStudyProgress>=100)?"none":"";
if(document.getElementById("createDerivativeBtn"))document.getElementById("createDerivativeBtn").style.display=(state.artStudyProgress>=100)?"":"none";
let announcementPackage=pendingAnnouncementPackage(),announcementLeft=announcementCooldownLeft();
writeCopyLabel.textContent=announcementPackage?"发公告":"写动态";
let derivativeAnnouncementBtn=document.getElementById("derivativeAnnouncementBtn");
if(derivativeAnnouncementBtn)derivativeAnnouncementBtn.style.display=(announcementPackage&&(state.derivativeCount||0)>0)?"":"none";
writeCopyBtn.disabled=!!announcementPackage&&announcementLeft>0;
let copyActionCost=2+Math.min(10,Math.max(0,year())),copySpiritCost=GAME_RULES.copyWritingSpiritCost(year());
writeCopyCostHint.textContent=announcementPackage?(announcementLeft>0?`还需等待${announcementLeft}天`:`${effectiveActionCost(2)}行动点 / -5精神`):`${effectiveActionCost(copyActionCost)}行动点 / -${copySpiritCost}精神`;
programCostHint.textContent=state.designConceptConfirmed?`${effectiveActionCost(programActionBaseCost())} 行动点 / -${state.takeoutProgramDiscount?30:20}精神`:"需先确定游戏设计理念";
let studyFatigueHalf=(state.studyActionsToday||0)>=2;
studyProgramCostHint.textContent=`${effectiveActionCost(state.services.course?3:5)}行动点 / -${studyFatigueHalf?15:30}精神`;
studyArtCostHint.textContent=`${effectiveActionCost(state.services.course?7:10)}行动点 / -${studyFatigueHalf?25:50}精神`;
rhythmCostHint.textContent=`${effectiveActionCost(2)}行动点 / +40精神`;
takeoutCostHint.textContent=`${effectiveActionCost(1)}行动点 / +25精神`;
sideGigCostHint.textContent=`${effectiveActionCost(8)}行动点 / -40精神`;
  recruitChartBtn.disabled=!state.designConceptConfirmed;
  recruitArtBtn.disabled=!state.designConceptConfirmed;
  let recruitCopyBtn=document.getElementById("recruitCopyBtn");
  if(recruitCopyBtn){recruitCopyBtn.style.display=state.copyRecruitUnlocked?"":"none";recruitCopyBtn.disabled=!state.designConceptConfirmed}
  let recruitTools=document.getElementById("recruitTools");
  if(recruitTools)recruitTools.classList.toggle("copy-unlocked",state.copyRecruitUnlocked);
  recruitChartCostHint.textContent=state.designConceptConfirmed?`${effectiveActionCost(1)} 行动点`:"需先确定游戏设计理念";
  recruitArtCostHint.textContent=state.designConceptConfirmed?`${effectiveActionCost(1)} 行动点`:"需先确定游戏设计理念";
  let recruitCopyCostHint=document.getElementById("recruitCopyCostHint");
  if(recruitCopyCostHint)recruitCopyCostHint.textContent=state.designConceptConfirmed?`${effectiveActionCost(1)} 行动点`:"需先确定游戏设计理念";
  let fatigueDanger=state.fatigue>100;
  fatigueText.classList.toggle("fatigue-danger",fatigueDanger);
  fatigueBar.classList.toggle("fatigue-danger",fatigueDanger);
  document.getElementById("fatigueWarning").classList.toggle("show",fatigueDanger);renderDevelopmentBars();doubleCostText.textContent=state.dailySpent>apCap()*.6?"今日行动量超过累计上限60%，后续行动消耗双倍行动点。":"";takeoutBtn.style.display=state.services.takeout?"block":"none";
fans.textContent=formatLargeCount(state.fans);discussion.textContent=formatLargeCount(state.discussion);players.textContent=formatLargeCount(state.players);rating.textContent=state.rating.toFixed(1);artPursuit.textContent=state.artPursuit.toFixed(1)+"%";styleBuff.textContent=`风格状态：${styleState().name}`;sponsor.textContent="¥"+fmt(state.sponsorIncome);sponsorInfo.textContent=state.services.sponsor?"赞助平台已开启":"赞助平台未开启";expectation.textContent=state.expectation.toFixed(1);stickiness.textContent=state.stickiness.toFixed(1);bugChance.textContent=state.bugChance.toFixed(1)+"%";tech.textContent=state.tech.toFixed(1);debugMore.textContent=`累计上限 ${apCap()}；今日已消耗 ${state.dailySpent}；程序对下次更新综合质量加成 ${state.programQualityBoost.toFixed(2)}；设计=${state.designConceptConfirmed?state.designStyle+" / PC端"+(state.designPC?"是":"否"):"未确定"}；前组员待判定=${(state.formerMemberOpinionCandidates||[]).length}；声誉危机=${state.day<=(state.exMemberScandalClusterUntil||0)?"是":"否"}；争吵影响=${state.day<=(state.teamArgumentUntil||0)?"是":"否"}；电脑=${computerBroken()?"损坏":"正常"}；破产=${state.bankrupt?"是":"否"}`;coord.textContent=coordValue().toFixed(0);coordCapDisplay.textContent=coordCap().toFixed(0);let storyWordsEl=document.getElementById("storyWords"),storyWordCapEl=document.getElementById("storyWordCap"),storyWordLine=document.getElementById("storyWordLine");if(storyWordsEl)storyWordsEl.textContent=fmt(state.storyWords);if(storyWordCapEl)storyWordCapEl.textContent=fmt(state.storyWordCap);if(storyWordLine)storyWordLine.style.display=state.hasHadCopywriter?"":"none";document.getElementById("derivativeCount").textContent=state.derivativeCount||0;if(document.getElementById("derivativeCountLine"))document.getElementById("derivativeCountLine").style.display=state.artStudyProgress>=100?"":"none";teamCapText.textContent=`人数 ${state.members.length}/${teamCap()}`;if(document.getElementById("memberSortSelect"))memberSortSelect.value=state.memberSortMode;renderComposerDebug();renderServices();renderMembers();renderCandidate();renderComposers();renderLibrary();renderPackages();renderCollabs();renderEconomy();refreshSaveStatus()}
function renderComposerDebug(){
  let el=document.getElementById("composerDebug");if(!el)return;
  el.innerHTML=`<h3>曲师隐藏数据（测试）</h3>`+composerDisplayOrder().map(c=>{
    let success=(commissionSuccess(c)*100).toFixed(1);
    let probs=n=>c.qualityProbs[n].map(x=>(x*100).toFixed(0)+"%").join(" / ");
    return `<div class="item"><b>${c.name}</b><div class="sub">平均抽象度 ${c.abstract}｜心理 ${c.mental}｜好感 ${c.affection.toFixed(1)}｜好感增长难度 ${c.affDifficulty}｜当前约稿成功率 ${success}%</div>
    <div class="sub">非商质量1~5：${probs("非商")}</div><div class="sub">商业质量1~5：${probs("商业")}</div><div class="sub">正式邀请质量1~5：${probs("正式邀请")}</div>${c.note?`<div class="sub">备注：${c.note}</div>`:""}</div>`
  }).join("")
}
function renderServices(){
  const definitions={
    vpn:{name:"VPN",cost:50,description:"允许你主动联系国外的曲师"},
    translation:{name:"翻译软件会员",cost:100,description:"增加与国外曲师合作的成功率"},
    takeout:{name:"外卖平台会员",cost:200,description:"让你能点外卖吃"},
    sponsor:{name:"赞助平台",cost:50,description:"让你每个月可能收到玩家赞助"},
    course:{name:"报名专门课程",cost:3000,description:"降低学技能消耗的行动点"},
    workspace:{name:"工作空间",cost:1000,description:"增加每天的初始行动点"}
  };
  services.innerHTML=Object.entries(definitions).map(([key,item])=>`<button class="service ${state.services[key]?"on":""}" onclick="toggleService('${key}')" title="${item.description}" aria-describedby="service-tip-${key}"><span class="service-copy"><b>${item.name}</b><small>每月 ¥${fmt(item.cost)}</small></span><span class="service-state">${state.services[key]?"取消":"购买"}</span><span class="service-tooltip" id="service-tip-${key}" role="tooltip">${item.description}</span></button>`).join("")
}
function renderCandidate(){
  let html=state.candidate?`<div class="candidate"><span class="candidate-kind">候选</span><b>${state.candidate.name||"未命名"}</b><span class="tag">${state.candidate.rarity}级${memberRoleName(state.candidate.role)}</span><span class="tag age-tag">${state.candidate.isMinor?"未成年":"成人"}</span><div class="candidate-actions"><button class="good" onclick="acceptCandidate()">录用</button><button onclick="rejectCandidate()">不录用</button></div></div>`:"";
  html+=(state.applications||[]).map(a=>`<div class="candidate"><span class="candidate-kind">申请</span><b>${a.name}</b><span class="tag">${a.rarity}级${memberRoleName(a.role)}</span><span class="tag age-tag">${a.isMinor?"未成年":"成人"}</span><div class="candidate-actions"><button class="good" ${state.members.length>=teamCap()?"disabled":""} onclick="acceptApplication(${a.id})">同意</button><button onclick="rejectApplication(${a.id})">拒绝</button></div></div>`).join("");
  candidateBox.innerHTML=html
}
function memberName(m){return `${m.name||"未命名"}｜${m.rarity}级${memberRoleName(m.role)}`}
function compactMemberLabel(m){return `${m?.name||"未命名"}（${m?.rarity||"?"}）`}function renderMembers(){
  let shown=sortedMembers();
  let activeHtml=shown.map(m=>{
    let occupied=memberOccupied(m);
    let isCopy=m.role==="copy";
    let a=occupied||isCopy?[]:state.library.filter(s=>!s.installed&&(m.role==="chart"?s.chartProgress<100:s.artProgress<100));
    let assigned=m.assignedSongIds.map(id=>getSong(id)?.name).filter(Boolean);
    let remaining=occupied?Math.max(1,(m.occupiedUntil||0)-state.day):0;
    let copyWorking=isCopy&&!occupied&&remainingStoryWritingCapacity()>0;
    let visibleStatus=occupied?"事务占用":m.status;
    let copyRange=isCopy?GAME_RULES.copywriterDailyWordRange(copywriterProductionOptions(m)):null;
    let fireButton=occupied
      ?`<button class="bad" disabled>开除</button>`
      :`<button class="bad" onclick="openFireMemberDialog(${m.id})">开除</button>`;
    let workInfo=isCopy
      ?`<div class="copywriter-workline"><span>日产能 ${copyRange[0]}–${copyRange[1]} 字</span><span>累计创作 ${fmt(m.copyWordsWritten||0)} 字</span>${m.status==="疑虑"?`<span>解除疑虑 ${Math.floor(m.doubtWritingProgress||0)} / ${GAME_RULES.copywriterRules.doubtRecoveryWords} 字</span>`:`<span>${copyWorking?"正在自动补充剧情":"剧情库存已达上限"}</span>`}</div>`
      :`<div class="row"><select id="assign-${m.id}" ${occupied?"disabled":""}>${a.map(s=>`<option value="${s.id}">${s.name}</option>`).join("")}</select><button ${a.length&&!occupied?"":"disabled"} onclick="assignMember(${m.id},Number(document.getElementById('assign-${m.id}').value))">分配任务</button></div>`;
    let taskTag=isCopy
      ?`<span class="tag ${copyWorking?"ok":"muted"}">${occupied?"无法工作":copyWorking?"自主工作":"空闲"}</span>`
      :assigned.length?`<span class="tag ok">任务中：${assigned.join("、")}</span>`:`<span class="tag muted">${occupied?"无法工作":"空闲"}</span>`;
    let outputTag=isCopy?`<span class="tag">累计 ${fmt(m.copyWordsWritten||0)} 字</span>`:`<span class="tag">作品 ${m.works.toFixed(1)}</span>`;
    return `<div class="item ${isCopy?"copywriter-item":""}"><div class="between"><div><b>${memberName(m)}</b><br><span class="tag age-tag">${m.isMinor?"未成年":"成人"}</span><span class="tag">${GAME_RULES.memberAffectionLabel(m.affection)}</span><span class="tag">${visibleStatus}</span>${occupied?`<span class="tag">剩余 ${remaining} 天</span>`:""}${outputTag}${taskTag}</div>${fireButton}</div>${workInfo}</div>`
  }).join("");

  let departedHtml=(state.departedRecoverables||[]).map(r=>{
    let m=r.member;
    let lockLeft=Math.max(0,30-(state.day-r.departedDay));
    let recoverBtn=lockLeft>0
      ?`<button class="good" disabled>找回（${lockLeft}天后）</button>`
      :`<button class="good" onclick="recoverMemberAttempt(${r.id})">找回（${effectiveActionCost(10)}行动点）</button>`;
    let abandon=r.abandonAt
      ?`<button onclick="toggleAbandonRecoverable(${r.id})">取消放弃（剩余${Math.max(1,r.abandonAt-state.day)}天）</button>`
      :`<button class="bad" onclick="toggleAbandonRecoverable(${r.id})">放弃</button>`;
    return `<div class="item"><div class="between"><div><b>${m.name}</b><br><span class="tag">已离组</span><span class="tag">${GAME_RULES.memberAffectionLabel(m.affection)}</span><span class="tag">${m.rarity}级${memberRoleName(m.role)}</span><span class="tag">作品 ${Number(m.works||0).toFixed(1)}</span></div></div><div class="row">${recoverBtn}${abandon}</div></div>`
  }).join("");

  members.innerHTML=(activeHtml+departedHtml)||`<div class="item muted">暂无成员。</div>`
}
function renderComposers(){
  let offers=state.incomingOffers.map(o=>{let c=getComposer(o.composerId);return `<div class="candidate composer-offer"><span class="candidate-kind">主动来稿</span><b>${c?.name||"曲师"} ·《${o.title||"未命名"}》</b><span class="tag">${o.style}</span><span class="tag">质量 ${o.q}</span><span class="tag">${o.free?"免费":`¥${Math.round(o.price)}`}</span><div class="candidate-actions"><button class="good" onclick="acceptIncomingOffer(${o.id})">接受</button><button onclick="declineIncomingOffer(${o.id})">拒绝</button></div></div>`}).join("");
  composers.innerHTML=offers+composerDisplayOrder().map(c=>{
    let st=state.day<c.depressedUntil?"抑郁":state.day<c.sickUntil?"感冒":"可联系";
    let availablePortfolios=c.portfolio.filter(p=>!p.bought);
    let pf=availablePortfolios.map(p=>`<article class="portfolio-card">
      <div class="portfolio-title-row">
        <div class="portfolio-title-block"><div class="portfolio-kicker"><span class="style-dot style-${p.style}"></span>${p.style}</div><b>${p.name}</b>${p.composerLabel&&p.composerLabel!==c.name?`<span class="portfolio-credit">合作：${p.composerLabel}</span>`:""}</div>
        <div class="portfolio-buy"><span class="portfolio-price"><small>收录价格</small><b>¥${fmt(p.price)}</b></span><button onclick="buyPortfolio(${c.id},${p.id})">购买</button></div>
      </div>
      <div class="portfolio-metrics"><span><small>关注</small><b>${p.attention}</b></span><span><small>讨论</small><b>${p.discussion}</b></span><span><small>好评</small><b>${p.good}</b></span></div>
    </article>`).join("");
    let comfort=state.day<c.depressedUntil&&c.affection>=80?`<button onclick="comfortComposer(${c.id})">陪伴创作者</button>`:"";
    let sel=composerSelection(c.id);
    let busy=composerHasActiveCommission(c.id),reachable=composerReachable(c);
    let commission=activeCommissionForComposer(c.id);
    let price=currentCommissionPrice(c,sel.nature),fundsOk=spendAllowed(price);
    let canContact=state.designConceptConfirmed&&reachable&&!busy&&fundsOk&&state.ap+1e-9>=effectiveActionCost(1);
    let expediteEff=clamp(Math.round(Number(c.efficiency)||1),1,5);
    let expediteWait=busy&&state.day-(c.lastExpediteDay||-9999)<7?7-(state.day-(c.lastExpediteDay||-9999)):0;
    let expediteBlocked=busy&&state.day<(c.expediteBlockedUntil||0)?(c.expediteBlockedUntil-state.day):0;
    let mainText=busy?"催稿":!state.designConceptConfirmed?"需先确定设计理念":!reachable?(c.country!=="中国"&&!state.services.vpn?"需要VPN":"当前无法联系"):!fundsOk?"资金不足":state.ap+1e-9<effectiveActionCost(1)?"行动点不足":"约稿";
    let metaText=busy?(c.country!=="中国"&&!state.services.vpn?"需要VPN":expediteEff>=5?"效率已足够快":expediteBlocked?`心态爆炸冷却 ${expediteBlocked}天`:expediteWait?`还需等待 ${expediteWait}天`:`成功率 ${Math.round(expediteSuccessRate(expediteEff)*100)}%`):!reachable?"":`${effectiveActionCost(1)}行动点 · ¥${fmt(price)}`;
    let natureOptions=["非商","商业","正式邀请"].map(n=>`<option value="${n}" ${sel.nature===n?"selected":""}>${n} · ¥${fmt(currentCommissionPrice(c,n))}</option>`).join("");
    let styleOptions=["灼热","抒情","冷冽"].map(s=>`<option value="${s}" ${sel.style===s?"selected":""}>${s}</option>`).join("");
    let styleEntries=[["灼热",c.styles.灼热],["抒情",c.styles.抒情],["冷冽",c.styles.冷冽]];
    return `<article class="item composer-card">
      <header class="composer-header">
        <div class="composer-title-block"><div class="composer-name-row"><b class="composer-name">${c.name}</b><span class="tag">${c.country}</span></div><span class="composer-status status-${st}"><i></i>${st}</span></div>
        <div class="composer-stat-row"><span class="composer-stat"><small>人气</small><b>${c.popularity}</b></span><span class="composer-stat"><small>技术</small><b>${c.avgQuality}</b></span><span class="composer-stat"><small>效率</small><b>${c.efficiency}</b></span></div>
      </header>
      <section class="commission-section"><div class="composer-section-label">委托设置</div><div class="commission-controls">
        <select ${busy?"disabled":""} onchange="setComposerSelection(${c.id},'nature',this.value)">${natureOptions}</select>
        <select ${busy?"disabled":""} onchange="setComposerSelection(${c.id},'style',this.value)">${styleOptions}</select>
        <button class="commission-btn" ${busy?"":(canContact?"":"disabled")} onclick="${busy?`expediteCommission(${c.id})`:`commissionComposer(${c.id})`}"><span class="main">${mainText}</span>${metaText?`<span class="meta">${metaText}</span>`:""}</button>
      </div></section>
      <section class="style-mastery"><div class="composer-section-label">风格驾驭能力</div><div class="style-mastery-grid">${styleEntries.map(([name,value])=>`<div class="style-meter"><div><span>${name}</span><b>${value}</b></div><i><em style="width:${clamp(value,0,100)}%"></em></i></div>`).join("")}</div></section>
      ${comfort}<details class="portfolio-section" ${availablePortfolios.length?"open":""}><summary><span>作品集</span><b>${availablePortfolios.length}</b></summary><div class="portfolio-list">${pf||'<div class="portfolio-empty">暂无可购买作品</div>'}</div></details>
    </article>`
  }).join("")
}
function toggleInstalledSongsVisibility(){state.hideInstalledSongs=!state.hideInstalledSongs;renderLibrary()}
function renderLibrary(){
  let toggleButton=document.getElementById("toggleInstalledSongsButton");
  if(toggleButton){toggleButton.textContent=state.hideInstalledSongs?"显示已上架":"隐藏已上架";toggleButton.setAttribute("aria-pressed",state.hideInstalledSongs?"true":"false")}
  let visibleSongs=state.hideInstalledSongs?state.library.filter(s=>!s.installed):state.library;
  library.innerHTML=visibleSongs.length?visibleSongs.map(s=>{
  let creator=s.composerLabel||getComposer(s.composerId)?.name||"未知曲师";
  let selectedChart=s.chartMemberIds?.[0]??null;
  let selectedArt=s.artMemberId??null;
  let co=state.members.filter(m=>m.role==="chart"&&!memberOccupied(m)).map(m=>`<option value="${m.id}" ${m.id===selectedChart?"selected":""}>${compactMemberLabel(m)}</option>`).join("");
  let ao=state.members.filter(m=>m.role==="art"&&!memberOccupied(m)).map(m=>`<option value="${m.id}" ${m.id===selectedArt?"selected":""}>${compactMemberLabel(m)}</option>`).join("");
  let assignedCharts=s.chartMemberIds.map(id=>getMember(id)).filter(Boolean).map(compactMemberLabel);
  let assignedArt=s.artMemberId?getMember(s.artMemberId):null;
  let alphaText=s.alphaStatus==="running"?`进行中（剩余${s.alphaRemaining}天）`:s.alphaStatus==="completed"||s.alpha?"已完成":"未进行";
  let alphaDisabled=s.installed||s.alphaStatus==="running"||s.alphaStatus==="completed"||s.alpha?"disabled":"";
  let chartControls=s.chartProgress<100?`<select id="chart-${s.id}">${co}</select><button ${co?"":"disabled"} onclick="assignMember(Number(document.getElementById('chart-${s.id}').value),${s.id})">分配谱师</button><button ${computerBroken()?"disabled":""} onclick="personallyChart(${s.id})">亲自写谱</button>`:"";
  let artControls=s.artProgress<100?`<select id="art-${s.id}">${ao}</select><button ${ao?"":"disabled"} onclick="assignMember(Number(document.getElementById('art-${s.id}').value),${s.id})">分配美术</button>${state.artStudyProgress>=50?`<button ${computerBroken()?"disabled":""} onclick="personallyDraw(${s.id})">亲自画图</button>`:""}`:"";
  let chartDisplay=assignedCharts.length?assignedCharts.join("、"):s.chartProgress>=100?"已完成":"未分配";
  let artDisplay=assignedArt?compactMemberLabel(assignedArt):s.artProgress>=100?"已完成":"未分配";
  return `<div class="item"><div class="between"><div><b>${s.name}</b> <span class="tag">${s.installed?"已实装":"未实装"}</span><span class="tag">${s.style}</span><span class="tag">${s.position}</span><div class="sub">曲师：${creator}</div></div><b>质量 ${s.quality}</b></div><div class="sub">关注 ${fmt(s.attention)}｜讨论 ${fmt(s.discussion)}｜${s.installed?`游玩 ${fmt(s.play)}｜`:""}好评 ${s.good.toFixed(1)}｜${typeof s.playableQuality==="number"?`可玩质量 ${s.playableQuality.toFixed(1)}｜`:""}艺术 ${s.artPercent.toFixed(1)}%</div><div class="sub">谱面 ${s.chartProgress.toFixed(0)}%｜封面 ${s.artProgress.toFixed(0)}%｜Alpha ${alphaText}${s.source==="portfolio"&&!s.installed?"｜作品集购买曲：未上架":""}</div><div class="sub">谱师：${chartDisplay}</div><div class="sub">美术：${artDisplay}</div>${!s.installed?`<div class="row">${chartControls}${artControls}<button ${alphaDisabled} onclick="alphaSong(${s.id})">Alpha测试</button></div>`:""}</div>`
}).join(""):`<div class="item muted">${state.hideInstalledSongs?"已隐藏全部上架歌曲，当前没有其他曲目。":"曲库暂无歌曲。"}</div>`
}
function renderPackages(){
  packages.innerHTML=state.packages.length?state.packages.map(p=>{
    let s=state.library.filter(x=>!x.installed&&x.chartProgress>=100&&(!x.packageId||x.packageId===p.id));
    let supportsStory=packageSupportsStory(p),storyCapacity=packageStoryWordCapacity(p),storyAssigned=Math.max(0,p.storyWordsAssigned||0);
    let statusExtra=p.status==="Beta测试"
      ?`｜剩余 ${p.betaRemaining} 天${p.betaReduction?`（已缩短${p.betaReduction}天）`:""}${p.betaExtraDays?`（泄密影响 +${p.betaExtraDays}天）`:""}`
      :p.status==="等待上架"
        ?`｜预计第 ${p.releaseDay} 天上架${p.reviewEventChecked&&p.reviewDelay?`（卡审核 +${p.reviewDelay}天）`:!p.reviewEventChecked?"（等待审核判定）":""}`
        :"";
    let storyRow=supportsStory&&state.hasHadCopywriter?`<div class="package-story-row"><span class="package-story-summary"><span>已分配剧情</span><b>${fmt(storyAssigned)} / ${fmt(storyCapacity)} 字</b></span>${p.status==="整理中"?`<button class="story-button" ${storyAssigned+GAME_RULES.copywriterRules.packageStoryStep<=storyCapacity&&state.storyWords>=GAME_RULES.copywriterRules.packageStoryStep?"":"disabled"} onclick="addStoryToPackage(${p.id})"><span>增加剧情</span><small>消耗 1,000 字</small></button>`:""}</div>`:"";
    let organizeControls=p.status==="整理中"?`<div class="package-control-grid"><select id="song-${p.id}">${s.map(x=>`<option value="${x.id}">${x.name}</option>`).join("")}</select><select id="pos-${p.id}"><option>普通曲</option><option>魔王曲</option><option>隐藏曲</option></select><button ${s.length?"":"disabled"} onclick="addSongToPackage(${p.id},Number(document.getElementById('song-${p.id}').value),document.getElementById('pos-${p.id}').value)">添加/移除</button><button class="primary" onclick="startBeta(${p.id})">发放 Beta 测试</button>${p.collab?"":`<button class="bad package-cancel" onclick="cancelPackageBuilding(${p.id})">取消建包</button>`}</div>`:"";
    return `<article class="panel package-card"><div class="between"><b>${p.name}</b><span class="tag">${p.status}</span></div><div class="sub package-song-list">歌曲：${p.songIds.map(id=>getSong(id)?.name).filter(Boolean).join("、")||"暂无"} ${statusExtra}</div>${storyRow}${organizeControls}${p.status==="Beta测试"?`<div class="row"><button class="bad" onclick="cancelBeta(${p.id})">取消 Beta 测试</button></div>`:""}</article>`
  }).join(""):`<div class="muted">暂无曲包。</div>`
}
function renderCollabs(){let offer=state.currentCollabOffer;let o=offer?`<div class="candidate"><b>《${offer.gameName}》的联动邀请</b><div class="sub">对方授权 ${offer.songCount} 首歌曲，要求在第 ${offer.forcedDeadline} 天前全部上线。</div><div class="candidate-actions"><button class="good" onclick="acceptCollab()">同意（${effectiveActionCost(6)}行动点）</button><button onclick="declineCollab()">拒绝</button></div></div>`:"";collabs.innerHTML=o+(state.collabs.length?state.collabs.map(c=>{let p=getPackage(c.packageId);return `<div class="item"><b>与《${c.gameName}》联动</b><div class="sub">${c.active?"进行中":"结束"}｜对方要求在第 ${c.forcedDeadline} 天前上线 ${c.songCount} 首歌曲｜曲包：${p?.name||"无"}</div>${c.active&&state.day<=c.cancelDeadline?`<button onclick="cancelCollab(${c.id})">取消联动（${effectiveActionCost(6)}行动点）</button>`:""}</div>`}).join(""):`<div class="item muted">暂无联动。</div>`)}
function renderEconomy(){
  let status=state.bankrupt?"破产":(state.money<0?"紧缺":"正常");
  let cls=state.bankrupt||state.money<0?"badtext":"ok";
  economyText.innerHTML=`状态：<b class="${cls}">${status}</b><br><span class="sub">${state.bankrupt?"将存款积累到20000解除破产状态。":""}</span>`
}

async function loadExternalComposerData(){
  try{
    let composersSource,portfolios;
    if(window.__NCRYOS_DATA__){
      // Vite 单文件构建会在启动前注入这两个 JSON；复制后再交给可变的游戏状态。
      composersSource=window.__NCRYOS_DATA__.composers;
      portfolios=window.__NCRYOS_DATA__.portfolios;
    }else{
      const composerResponse=await fetch("./composers.json");
      const portfolioResponse=await fetch("./portfolios.json");
      if(!composerResponse.ok||!portfolioResponse.ok)throw new Error("外部数据读取失败");
      composersSource=await composerResponse.json();
      portfolios=await portfolioResponse.json();
    }
    COMPOSER_MASTER=JSON.parse(JSON.stringify(composersSource));
    portfolios=JSON.parse(JSON.stringify(portfolios));

    // 外置数据兼容旧逻辑：补齐原内置对象一定存在的字段。
    COMPOSER_MASTER.forEach(c=>{
      c.bond=c.bond||[];
      c.prices=c.prices||{"非商":0,"商业":0,"正式邀请":0};
      c.styles=c.styles||{};
      c.collabs=Number(c.collabs)||0;
      c.affection=Number(c.affection)||0;
      c.mental=Number.isFinite(c.mental)?c.mental:100;
      c.portfolio=c.portfolio||[];
    });
    COMPOSER_MASTER.forEach(c=>{
      c.portfolio=portfolios
        .filter(p=>{
          // ownerComposerName 支持多个曲师，例如：
          // "PICKUPNEAR,纵连大师"
          // 程序会自动解析并挂载到对应曲师作品集。
          if(p.ownerComposerName){
            const names=String(p.ownerComposerName)
              .split(/[,，、|]/)
              .map(x=>x.trim())
              .filter(Boolean);
            return names.includes(c.name);
          }
          return Number(p.ownerComposerId)===Number(c.id);
        })
        .map(p=>{
          const copy={...p};
          delete copy.ownerComposerId;
          delete copy.ownerComposerName;
          return copy;
        });
    });
  }catch(e){
    console.error("曲师/作品集数据加载失败，使用内置备份数据。",e);
    // 保证 GitHub Pages 或临时离线打开失败时不会导致空曲库。
    if(!COMPOSER_MASTER.length&&typeof BUILTIN_COMPOSER_MASTER!=="undefined"){
      COMPOSER_MASTER=BUILTIN_COMPOSER_MASTER;
    }
  }
}

async function startGame(){await loadExternalComposerData();seed();ensureNewStateDefaults();render();}
startGame().then(()=>{
  window.__NCRYOS_READY__=true;
  window.dispatchEvent(new CustomEvent("ncryos:ready"));
});

setTimeout(()=>{
  applyDeviceMode();
},0);

let responsiveModeFrame=0;
window.addEventListener("resize",()=>{
  if(getManualDeviceMode()!=="auto")return;
  cancelAnimationFrame(responsiveModeFrame);
  responsiveModeFrame=requestAnimationFrame(applyDeviceMode);
},{passive:true});
